// v1 split file generated from original monolithic app.js
// 注意：此文件为保持行为稳定的第一刀拆分，允许存在少量跨层函数。

var canvas = document.getElementById('game');
var ctx = canvas.getContext('2d');
var ui = {
  tabWorld: document.getElementById('tabWorld'),
  tabWorldPage: document.getElementById('tabWorldPage'),
  worldResolution: document.getElementById('worldResolution'),
  applyWorld: document.getElementById('applyWorld'),
  worldInspectorSummary: document.getElementById('worldInspectorSummary'),
  worldInspectorDetails: document.getElementById('worldInspectorDetails'),
  gridW: document.getElementById('gridW'),
  gridH: document.getElementById('gridH'),
  tileScale: document.getElementById('tileScale'),
  playerHeightCells: document.getElementById('playerHeightCells'),
  playerProxyW: document.getElementById('playerProxyW'),
  playerProxyD: document.getElementById('playerProxyD'),
  applyPlayerSettings: document.getElementById('applyPlayerSettings'),
  resetPlayerButton: document.getElementById('resetPlayerButton'),
  modeView: document.getElementById('modeView'),
  modePlace: document.getElementById('modePlace'),
  modeDelete: document.getElementById('modeDelete'),
  prefabSelect: document.getElementById('prefabSelect'),
  prefabHint: document.getElementById('prefabHint'),
  assetScanStatus: document.getElementById('assetScanStatus'),
  assetScanDetails: document.getElementById('assetScanDetails'),
  importPrefabJson: document.getElementById('importPrefabJson'),
  importHabboSwf: document.getElementById('importHabboSwf'),
  importHabboDemo: document.getElementById('importHabboDemo'),
  setHabboAssetRoot: document.getElementById('setHabboAssetRoot'),
  scanHabboAssetRoot: document.getElementById('scanHabboAssetRoot'),
  openHabboLibrary: document.getElementById('openHabboLibrary'),
  refreshHabboLibrary: document.getElementById('refreshHabboLibrary'),
  habboSampleSelect: document.getElementById('habboSampleSelect'),
  habboSwfFileInput: document.getElementById('habboSwfFileInput'),
  habboImportStatus: document.getElementById('habboImportStatus'),
  habboRootStatus: document.getElementById('habboRootStatus'),
  habboLibraryModal: document.getElementById('habboLibraryModal'),
  habboLibraryBackdrop: document.getElementById('habboLibraryBackdrop'),
  habboLibraryClose: document.getElementById('habboLibraryClose'),
  habboLibraryRefresh: document.getElementById('habboLibraryRefresh'),
  habboLibrarySearch: document.getElementById('habboLibrarySearch'),
  habboLibraryTypeRoom: document.getElementById('habboLibraryTypeRoom'),
  habboLibraryTypeWall: document.getElementById('habboLibraryTypeWall'),
  habboLibraryStatus: document.getElementById('habboLibraryStatus'),
  habboLibraryDiagnostics: document.getElementById('habboLibraryDiagnostics'),
  habboLibraryRootLabel: document.getElementById('habboLibraryRootLabel'),
  habboLibraryCategoryList: document.getElementById('habboLibraryCategoryList'),
  habboLibrarySummary: document.getElementById('habboLibrarySummary'),
  habboLibraryGrid: document.getElementById('habboLibraryGrid'),
  habboLibraryPreviewThumb: document.getElementById('habboLibraryPreviewThumb'),
  habboLibraryPreviewMeta: document.getElementById('habboLibraryPreviewMeta'),
  habboLibraryPlace: document.getElementById('habboLibraryPlace'),
  rescanAssetPrefabs: document.getElementById('rescanAssetPrefabs'),
  openEditor: document.getElementById('openEditor'),
  prefabFileInput: document.getElementById('prefabFileInput'),
  tabItems: document.getElementById('tabItems'),
  tabLights: document.getElementById('tabLights'),
  tabPlayer: document.getElementById('tabPlayer'),
  tabItemsPage: document.getElementById('tabItemsPage'),
  tabLightsPage: document.getElementById('tabLightsPage'),
  tabPlayerPage: document.getElementById('tabPlayerPage'),
  itemInspectorEmpty: document.getElementById('itemInspectorEmpty'),
  itemInspectorSummary: document.getElementById('itemInspectorSummary'),
  itemInspectorPanel: document.getElementById('itemInspectorPanel'),
  itemInspectorInstance: document.getElementById('itemInspectorInstance'),
  itemInspectorPrefab: document.getElementById('itemInspectorPrefab'),
  playerInspectorSummary: document.getElementById('playerInspectorSummary'),
  playerInspectorDetails: document.getElementById('playerInspectorDetails'),
  xrayFaces: document.getElementById('xrayFaces'),
  showDebugBox: document.getElementById('showDebugBox'),
  showFrontLines: document.getElementById('showFrontLines'),
  verboseLog: document.getElementById('verboseLog'),
  clearLog: document.getElementById('clearLog'),
  downloadLog: document.getElementById('downloadLog'),
  downloadHabboDebug: document.getElementById('downloadHabboDebug'),
  showHabboDebugOverlay: document.getElementById('showHabboDebugOverlay'),
  dumpScene: document.getElementById('dumpScene'),
  dumpCandidate: document.getElementById('dumpCandidate'),
  saveScene: document.getElementById('saveScene'),
  loadScene: document.getElementById('loadScene'),
  saveSceneFile: document.getElementById('saveSceneFile'),
  openDefaultSceneFile: document.getElementById('openDefaultSceneFile'),
  importSceneFile: document.getElementById('importSceneFile'),
  sceneImportFileInput: document.getElementById('sceneImportFileInput'),
  sceneFileStatus: document.getElementById('sceneFileStatus'),
  resetScene: document.getElementById('resetScene'),
  debugLog: document.getElementById('debugLog'),
  addLight: document.getElementById('addLight'),
  deleteLight: document.getElementById('deleteLight'),
  toggleLightAxes: document.getElementById('toggleLightAxes'),
  lightList: document.getElementById('lightList'),
  lightName: document.getElementById('lightName'),
  lightType: document.getElementById('lightType'),
  lightColor: document.getElementById('lightColor'),
  lightIntensity: document.getElementById('lightIntensity'),
  lightIntensityValue: document.getElementById('lightIntensityValue'),
  lightRadius: document.getElementById('lightRadius'),
  lightRadiusValue: document.getElementById('lightRadiusValue'),
  lightAngle: document.getElementById('lightAngle'),
  lightAngleValue: document.getElementById('lightAngleValue'),
  lightPitch: document.getElementById('lightPitch'),
  lightPitchValue: document.getElementById('lightPitchValue'),
  lightSpread: document.getElementById('lightSpread'),
  lightSpreadValue: document.getElementById('lightSpreadValue'),
  lightSoftness: document.getElementById('lightSoftness'),
  lightSoftnessValue: document.getElementById('lightSoftnessValue'),
  lightSize: document.getElementById('lightSize'),
  lightSizeValue: document.getElementById('lightSizeValue'),
  ambientStrength: document.getElementById('ambientStrength'),
  ambientValue: document.getElementById('ambientValue'),
  lightTypeHint: document.getElementById('lightTypeHint'),
  presetAllOn: document.getElementById('presetAllOn'),
  presetWarmHome: document.getElementById('presetWarmHome'),
  presetCoolShowroom: document.getElementById('presetCoolShowroom'),
  presetMoonNight: document.getElementById('presetMoonNight'),
  lightXText: document.getElementById('lightXText'),
  lightYText: document.getElementById('lightYText'),
  lightZText: document.getElementById('lightZText'),
  lightXInput: document.getElementById('lightXInput'),
  lightYInput: document.getElementById('lightYInput'),
  lightZInput: document.getElementById('lightZInput'),
  showLightShadows: document.getElementById('showLightShadows'),
  showLightGlow: document.getElementById('showLightGlow'),
  shadowHighContrast: document.getElementById('shadowHighContrast'),
  shadowDebugColor: document.getElementById('shadowDebugColor'),
  shadowAlpha: document.getElementById('shadowAlpha'),
  shadowAlphaValue: document.getElementById('shadowAlphaValue'),
  shadowOpacity: document.getElementById('shadowOpacity'),
  shadowOpacityValue: document.getElementById('shadowOpacityValue'),
};

function detectAppEntryInfo() {
  var explicit = (typeof window !== 'undefined' && window.__APP_ENTRY_INFO && typeof window.__APP_ENTRY_INFO === 'object') ? window.__APP_ENTRY_INFO : null;
  var pathname = '';
  try { pathname = String((typeof location !== 'undefined' && location.pathname) || ''); } catch (err) { pathname = ''; }
  var file = pathname.split('/').pop() || 'unknown';
  var inferredKind = explicit && explicit.kind ? String(explicit.kind) : (/START_V\d+_ONLY\.html$/i.test(file) ? 'editor' : (/index\.html$/i.test(file) ? 'main' : 'other'));
  var inferredLabel = explicit && explicit.label ? String(explicit.label) : (inferredKind === 'main' ? '主程序' : (inferredKind === 'editor' ? '编辑器' : '其它入口'));
  var launcher = explicit && explicit.launcherHint ? String(explicit.launcherHint) : (inferredKind === 'main' ? 'start.bat' : (inferredKind === 'editor' ? 'start_editor.bat' : 'unknown'));
  var href = '';
  try { href = String((typeof location !== 'undefined' && location.href) || ''); } catch (err) { href = ''; }
  return {
    kind: inferredKind,
    label: inferredLabel,
    entryFile: explicit && explicit.entryFile ? String(explicit.entryFile) : file,
    launcherHint: launcher,
    title: (typeof document !== 'undefined' && document.title) ? String(document.title) : '',
    href: href,
    build: explicit && explicit.build ? String(explicit.build) : '',
    source: explicit ? 'html-global' : 'pathname-inferred'
  };
}

var APP_ENTRY_INFO = detectAppEntryInfo();
if (typeof window !== 'undefined') window.__APP_ENTRY_INFO_RESOLVED = APP_ENTRY_INFO;

var startupIssues = [];
var bootBuffer = [];
var logSeq = 0;
var logs = [];
var logSystemReady = false;
var LOG_UI_FLUSH_MS = 250;
var MAX_LOG_LINES = 5000;
var LOG_UI_PREVIEW_LINES = 300;
var logFlushScheduled = false;
var lastLogUiFlushAt = 0;
var VIEW_W = 1180;
var VIEW_H = 780;
var dpr = Math.max(1, Math.min(window.devicePixelRatio || 1, 1.5));
var WORLD_SIZE_MIN = 6;
var WORLD_SIZE_MAX = 128;
var ASSET_PREFAB_INDEX_URL = "/api/prefabs/index";
function ensureAssetPrefabScanState() {
  if (!window.__assetPrefabScanState) {
    window.__assetPrefabScanState = {
      inFlight: false,
      lastAt: 0,
      lastError: '',
      lastSummary: '',
      lastItems: [],
      ids: new Set(),
      totalFiles: 0,
      importedCount: 0,
    };
  }
  if (!(window.__assetPrefabScanState.ids instanceof Set)) {
    window.__assetPrefabScanState.ids = new Set(Array.isArray(window.__assetPrefabScanState.ids) ? window.__assetPrefabScanState.ids : []);
  }
  return window.__assetPrefabScanState;
}
var assetPrefabScanInFlight = false;
var lastAssetPrefabScanAt = 0;
var assetManagedPrefabIds = ensureAssetPrefabScanState().ids;
function getAssetPrefabScanSnapshot() {
  var st = ensureAssetPrefabScanState();
  return {
    inFlight: !!st.inFlight,
    lastAt: st.lastAt || 0,
    lastError: st.lastError || '',
    lastSummary: st.lastSummary || '',
    totalFiles: st.totalFiles || 0,
    importedCount: st.importedCount || 0,
    ids: Array.from(st.ids || []),
    lastItems: Array.isArray(st.lastItems) ? st.lastItems.slice(0, 20) : [],
    serverMode: isServerMode(),
  };
}
function isServerMode() {
  return /^https?:$/i.test(window.location.protocol);
}
function getCanvasViewportSize() {
  var wrap = canvas ? canvas.parentElement : null;
  var cssW = wrap ? Math.max(640, Math.floor(wrap.clientWidth || 0)) : 1180;
  var cssH = wrap ? Math.max(520, Math.floor(wrap.clientHeight || 0)) : 780;
  return { w: cssW, h: cssH };
}
function configureCanvasForDisplay() {
  if (!canvas) return;
  dpr = Math.max(1, Math.min(window.devicePixelRatio || 1, 1.5));
  var viewport = getCanvasViewportSize();
  VIEW_W = viewport.w;
  VIEW_H = viewport.h;
  canvas.style.width = `${VIEW_W}px`;
  canvas.style.height = `${VIEW_H}px`;
  canvas.width = Math.round(VIEW_W * dpr);
  canvas.height = Math.round(VIEW_H * dpr);
  if (ctx) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
  }
  detailLog(`canvas-config: css=${VIEW_W}x${VIEW_H} dpr=${dpr.toFixed(2)} backing=${canvas.width}x${canvas.height}`);
}
var debugState = {
  bootSeq: 0,
  phase: 'boot',
  frame: 0,
  updateStep: 'n/a',
  renderStep: 'n/a',
  lastRenderable: 'n/a',
  lastEvent: 'n/a',
  firstFrameAt: null,
};
var perfStats = {
  sampleFrames: 0,
  loopMs: 0,
  updateMs: 0,
  renderMs: 0,
  playerSpriteHits: 0,
  playerSpriteMisses: 0,
  floorRebuilds: 0,
  staticShadowRebuilds: 0,
  staticBoxRebuilds: 0,
};
function perfNow() {
  return (typeof performance !== 'undefined' && typeof performance.now === 'function') ? performance.now() : Date.now();
}
function notePlayerSpriteCache(hit, meta = '') {
  if (hit) perfStats.playerSpriteHits += 1;
  else perfStats.playerSpriteMisses += 1;
  if (!hit && (verboseLog || debugState.frame <= 10)) detailLog(`perf:player-sprite-cache miss ${meta}`);
}
function noteLayerRebuild(kind, meta = '') {
  if (kind === 'floor') perfStats.floorRebuilds += 1;
  if (kind === 'static-shadow') perfStats.staticShadowRebuilds += 1;
  if (kind === 'static-box') perfStats.staticBoxRebuilds += 1;
  if (verboseLog || debugState.frame <= 10 || kind === 'static-box' || kind === 'floor' || kind === 'static-shadow') detailLog(`perf:${kind}-rebuild ${meta}`);
}
function recordPerfSample(loopMs, updateMs, renderMs) {
  perfStats.sampleFrames += 1;
  perfStats.loopMs += loopMs;
  perfStats.updateMs += updateMs;
  perfStats.renderMs += renderMs;
  if (loopMs >= 18 || renderMs >= 14) {
    detailLog(`perf:slow-frame frame=${debugState.frame} loopMs=${loopMs.toFixed(2)} updateMs=${updateMs.toFixed(2)} renderMs=${renderMs.toFixed(2)} step=${debugState.renderStep} interactive=${isInteractiveRenderPressure ? isInteractiveRenderPressure() : false}`);
  }
}
function flushPerfSummary(force = false) {
  if (!perfStats.sampleFrames) return;
  if (!force && perfStats.sampleFrames < 30) return;
  var frames = perfStats.sampleFrames;
  detailLog(
    `perf-summary frames=${frames} avgLoopMs=${(perfStats.loopMs / frames).toFixed(2)} avgUpdateMs=${(perfStats.updateMs / frames).toFixed(2)} avgRenderMs=${(perfStats.renderMs / frames).toFixed(2)} playerSpriteCache=${perfStats.playerSpriteHits}H/${perfStats.playerSpriteMisses}M floorRebuilds=${perfStats.floorRebuilds} staticBoxRebuilds=${perfStats.staticBoxRebuilds} staticShadowRebuilds=${perfStats.staticShadowRebuilds} interactive=${isInteractiveRenderPressure ? isInteractiveRenderPressure() : false}`
  );
  perfStats.sampleFrames = 0;
  perfStats.loopMs = 0;
  perfStats.updateMs = 0;
  perfStats.renderMs = 0;
  perfStats.playerSpriteHits = 0;
  perfStats.playerSpriteMisses = 0;
  perfStats.floorRebuilds = 0;
  perfStats.staticShadowRebuilds = 0;
  perfStats.staticBoxRebuilds = 0;
}
function rawBootLog(msg, kind = 'error') {
  const line = `[boot-${String(++debugState.bootSeq).padStart(4, '0')}] ${msg}`;
  console[kind === 'error' ? 'error' : 'log'](line);
  const el = ui.debugLog;
  if (el) {
    el.value += (el.value ? '\n' : '') + line;
    el.scrollTop = el.scrollHeight;
  }
}
function noteStartupIssue(msg) {
  startupIssues.push(msg);
  rawBootLog(`[startup-issue] ${msg}`, 'error');
}
function detailLog(msg) {
  if (!logSystemReady) {
    rawBootLog(msg, 'log');
    return;
  }
  if (!verboseLog) return;
  if (typeof pushLog === 'function') pushLog(msg);
}

function habboTrace(msg) {
  detailLog('[habbo-trace] ' + msg);
}

var habboDebugFrames = [];
var habboDebugSeq = 0;
var habboDebugMax = 800;

function summarizeHabboDebugPayload(event, payload) {
  var safe = payload ? cloneJsonSafe(payload) : null;
  if (!safe || typeof safe !== 'object') return safe;
  if (event === 'prefab-built' && safe.habboMeta) {
    var layerDirs = safe.habboMeta.layersByDirection || {};
    var layerSummary = Object.keys(layerDirs).reduce(function (acc, key) {
      acc[key] = Array.isArray(layerDirs[key]) ? layerDirs[key].length : 0;
      return acc;
    }, {});
    safe.habboMeta = {
      sourceKind: safe.habboMeta.sourceKind || '',
      sourceName: safe.habboMeta.sourceName || '',
      type: safe.habboMeta.type || '',
      dimensions: safe.habboMeta.dimensions || null,
      proxyDims: safe.habboMeta.proxyDims || null,
      logicDirections: safe.habboMeta.logicDirections || [],
      visualDirections: safe.habboMeta.visualDirections || [],
      visualization: safe.habboMeta.visualization || '',
      logic: safe.habboMeta.logic || '',
      scutiReference: safe.habboMeta.scutiReference || null,
      layerDirCounts: layerSummary,
      usesFlattenedFrame: !!safe.habboMeta.usesFlattenedFrame,
    };
  }
  return safe;
}

function pushHabboDebug(event, payload) {
  var safePayload = summarizeHabboDebugPayload(String(event || 'unknown'), payload);
  var entry = {
    seq: ++habboDebugSeq,
    ts: Date.now(),
    event: String(event || 'unknown'),
    payload: safePayload,
  };
  habboDebugFrames.push(entry);
  if (habboDebugFrames.length > habboDebugMax) habboDebugFrames.shift();
  try {
    var text = JSON.stringify(entry.payload || {});
    if (text && text.length > 3200) text = text.slice(0, 3200) + '…[truncated]';
    detailLog('[habbo-debug] ' + entry.event + ' ' + text);
  } catch (err) {
    detailLog('[habbo-debug] ' + entry.event + ' [payload stringify failed]');
  }
  return entry;
}

function exportHabboDebug() {
  pushHabboDebug('export', { entries: habboDebugFrames.length });
  var blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), entries: habboDebugFrames }, null, 2)], { type: 'application/json;charset=utf-8' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'habbo-debug-' + Date.now() + '.json';
  a.click();
  URL.revokeObjectURL(url);
}
function buildLogExportHeader() {
  var parts = [];
  parts.push('# isometric debug log');
  parts.push('# exportedAt=' + new Date().toISOString());
  parts.push('# entryKind=' + String(APP_ENTRY_INFO.kind || 'unknown'));
  parts.push('# entryLabel=' + String(APP_ENTRY_INFO.label || 'unknown'));
  parts.push('# entryFile=' + String(APP_ENTRY_INFO.entryFile || 'unknown'));
  parts.push('# launcher=' + String(APP_ENTRY_INFO.launcherHint || 'unknown'));
  parts.push('# entrySource=' + String(APP_ENTRY_INFO.source || 'unknown'));
  if (APP_ENTRY_INFO.build) parts.push('# build=' + APP_ENTRY_INFO.build);
  if (APP_ENTRY_INFO.title) parts.push('# title=' + APP_ENTRY_INFO.title);
  if (APP_ENTRY_INFO.href) parts.push('# href=' + APP_ENTRY_INFO.href);
  if (typeof window !== 'undefined' && window.__FUNCTION_TRACE_INFO) parts.push('# functionTrace=' + JSON.stringify(window.__FUNCTION_TRACE_INFO));
  try {
    var selectedPrefab = (typeof currentProto === 'function' && currentProto()) ? currentProto().id : 'n/a';
    var mode = (typeof editor !== 'undefined' && editor && editor.mode) ? editor.mode : 'n/a';
    parts.push('# editorMode=' + mode);
    parts.push('# currentPrefab=' + selectedPrefab);
  } catch (err) {}
  parts.push('');
  return parts.join('\n');
}

function logResolvedEntryInfo() {
  detailLog('entry-info: kind=' + String(APP_ENTRY_INFO.kind || 'unknown') + ' label=' + String(APP_ENTRY_INFO.label || 'unknown') + ' entry=' + String(APP_ENTRY_INFO.entryFile || 'unknown') + ' launcher=' + String(APP_ENTRY_INFO.launcherHint || 'unknown') + ' source=' + String(APP_ENTRY_INFO.source || 'unknown'));
  if (APP_ENTRY_INFO.build) detailLog('entry-info: build=' + APP_ENTRY_INFO.build);
  if (APP_ENTRY_INFO.href) detailLog('entry-info: href=' + APP_ENTRY_INFO.href);
}

function placeTrace(msg) {
  detailLog('[place-trace] ' + msg);
}
function setPhase(phase, step = '') {
  debugState.phase = phase;
  if (phase === 'update') debugState.updateStep = step || debugState.updateStep;
  if (phase === 'render') debugState.renderStep = step || debugState.renderStep;
}
function errorBanner(msg) {
  let banner = document.querySelector('.startupBanner');
  if (!banner) {
    banner = document.createElement('div');
    banner.className = 'startupBanner';
    document.body.appendChild(banner);
  }
  banner.textContent = msg;
}
function formatErrorDetails(message, source, lineno, colno, error) {
  const preview = editor && editor.preview ? {
    valid: editor.preview.valid ?? null,
    reason: editor.preview.reason ?? '',
    prefabId: editor.preview.prefabId ?? '',
    hasBox: !!editor.preview.box,
    box: editor.preview.box ? { x: editor.preview.box.x, y: editor.preview.box.y, z: editor.preview.box.z, w: editor.preview.box.w, d: editor.preview.box.d, h: editor.preview.box.h, name: editor.preview.box.name } : null,
    origin: editor.preview.origin ? { x: editor.preview.origin.x, y: editor.preview.origin.y, z: editor.preview.origin.z } : null,
    boxes: editor.preview.boxes ? editor.preview.boxes.length : 0,
  } : null;
  const parts = [
    `message=${message || 'n/a'}`,
    `source=${source || 'n/a'}`,
    `line=${lineno ?? 'n/a'}`,
    `col=${colno ?? 'n/a'}`,
    `phase=${debugState.phase}`,
    `frame=${debugState.frame}`,
    `updateStep=${debugState.updateStep}`,
    `renderStep=${debugState.renderStep}`,
    `lastRenderable=${debugState.lastRenderable}`,
    `lastEvent=${debugState.lastEvent}`,
    `instances=${typeof instances !== 'undefined' ? instances.length : 'n/a'}`,
    `boxes=${typeof boxes !== 'undefined' ? boxes.length : 'n/a'}`,
    `currentPrefab=${typeof currentPrefab === 'function' && currentPrefab() ? currentPrefab().id : 'n/a'}`,
    `editorMode=${editor?.mode ?? 'n/a'}`,
    `preview=${preview ? JSON.stringify(preview) : 'null'}`,
  ];
  if (error && error.stack) parts.push(`stack=${error.stack}`);
  return parts.join(' | ');
}
function safeListen(el, event, handler, label = '') {
  if (!el) return false;
  el.addEventListener(event, (ev) => {
    const tag = label || `${el.id || el.tagName || 'node'}:${event}`;
    debugState.lastEvent = tag;
    const valueBits = [];
    if (ev && 'clientX' in ev) valueBits.push(`client=(${Number(ev.clientX||0).toFixed(1)},${Number(ev.clientY||0).toFixed(1)})`);
    if (ev && 'button' in ev) valueBits.push(`button=${ev.button}`);
    if (ev && 'key' in ev) valueBits.push(`key=${ev.key}`);
    if (el && 'value' in el && typeof el.value !== 'undefined') valueBits.push(`value=${JSON.stringify(el.value)}`);
    detailLog(`[event-start] ${tag}${valueBits.length ? ' | ' + valueBits.join(' | ') : ''}`);
    try {
      const out = handler(ev);
      detailLog(`[event-done] ${tag}`);
      return out;
    } catch (err) {
      const detail = formatErrorDetails(err?.message || `event-handler failed: ${tag}`, 'event-handler', 0, 0, err);
      detailLog(`[event-error] ${detail}`);
      errorBanner(`事件处理错误：
${detail}`);
      throw err;
    }
  });
  return true;
}
function setElValue(el, value) { if (el) el.value = value; }
function setElText(el, value) { if (el) el.textContent = value; }
var missingUiKeys = Object.entries(ui).filter(([, v]) => !v).map(([k]) => k);
rawBootLog(`[env] href=${location.href} userAgent=${navigator.userAgent}`, 'log');
rawBootLog(`[dom] canvas=${!!canvas} ctx=${!!ctx} uiCount=${Object.keys(ui).length}`, 'log');
if (missingUiKeys.length) noteStartupIssue(`缺失 UI 节点: ${missingUiKeys.join(', ')}`);
window.onerror = function(message, source, lineno, colno, error) {
  const detail = formatErrorDetails(message, source, lineno, colno, error);
  rawBootLog(`[runtime-error] ${detail}`, 'error');
  errorBanner(`运行时错误：
${detail}`);
  return false;
};
window.addEventListener('error', (event) => {
  const target = event?.target;
  if (target && target !== window) {
    const tag = target.tagName || 'unknown-target';
    const src = target.src || target.href || target.currentSrc || 'n/a';
    rawBootLog(`[resource-error] tag=${tag} src=${src}`, 'error');
    errorBanner(`资源加载错误：
${tag} ${src}`);
    return;
  }
  const detail = formatErrorDetails(event?.message, event?.filename, event?.lineno, event?.colno, event?.error);
  rawBootLog(`[runtime-error-event] ${detail}`, 'error');
}, true);
window.addEventListener('unhandledrejection', (event) => {
  const reason = event?.reason;
  const msg = reason?.stack || String(reason || 'Unhandled rejection');
  rawBootLog(`[promise-error] phase=${debugState.phase} frame=${debugState.frame} reason=${msg}`, 'error');
  errorBanner(`Promise 错误：
${msg}`);
});

configureCanvasForDisplay();
window.addEventListener('resize', () => {
  debugState.lastEvent = 'window:resize';
  configureCanvasForDisplay();
  applySettings();
});

var BASE_TILE_W = 80;
var BASE_TILE_H = 40;
var EPS = 1e-5;
var keys = new Set();
var mouse = { x: 0, y: 0, inside: false, draggingView: false, panStartX: 0, panStartY: 0, cameraStartX: 0, cameraStartY: 0 };
var camera = { x: 0, y: 0 };
var time = 0;
var assetsReady = false;
var showDebug = false;
var showFrontLines = false;
var xrayFaces = false;
var verboseLog = false;
var LAB_MODE = false;
var SHOW_PLAYER = true;
var lastRenderLogSecond = -1;
var lastPreviewSignature = '';

var spriteSliceBuffer = document.createElement('canvas');
var spriteSliceCtx = spriteSliceBuffer.getContext('2d');
var playerSpriteFrameBuffer = document.createElement('canvas');
var playerSpriteFrameCtx = playerSpriteFrameBuffer.getContext('2d');
var playerSpriteFrameCache = {
  key: '',
  frame: 0,
  row: 0,
  xLeft: 0,
  yTop: 0,
  visibleHeight: 0,
  totalH: 1.72,
  brightness: 1,
  tint: { r: 255, g: 255, b: 255 },
  weight: 0,
};

var LIGHT_TYPE_LABELS = {
point: '点光',
directional: '方向',
spot: '聚光',
area: '面积',
};

var LOCAL_SCENE_STORAGE_KEY = 'isometric-room-scene-v1';
var LOCAL_PREFAB_STORAGE_KEY = 'isometric-room-prefabs-v1';
var LOCAL_SCENE_CURRENT_FILE_KEY = 'isometric-room-scene-current-file-v1';
var SCENE_API_SAVE_URL = '/api/scenes/save';
var SCENE_API_LOAD_URL = '/api/scenes/load';
var SCENE_API_DEFAULT_URL = '/api/scenes/default';
var HABBO_CONFIG_API_URL = '/api/habbo/config';
var HABBO_INDEX_API_URL = '/api/habbo/index';
var HABBO_FILE_API_URL = '/api/habbo/file';
var HABBO_LIBRARY_INDEX_API_URL = '/api/habbo/library/index';
var HABBO_LIBRARY_SUMMARY_API_URL = '/api/habbo/library/summary';
var HABBO_LIBRARY_PAGE_API_URL = '/api/habbo/library/page';
var HABBO_LIBRARY_ICON_API_URL = '/api/habbo/library/icon';
var currentSceneServerFile = '';


function normalizeLight(light) {
light.type = light.type || 'point';
if (light.x == null) light.x = 5;
if (light.y == null) light.y = 3;
if (light.z == null) light.z = 3;
if (light.radius == null) light.radius = 240;
if (light.intensity == null) light.intensity = 1;
if (!light.color) light.color = '#ffe59b';
if (light.angle == null) light.angle = 45;
if (light.pitch == null) light.pitch = 55;
if (light.spread == null) light.spread = 34;
if (light.softness == null) light.softness = 0.45;
if (light.size == null) light.size = 1.2;
return light;
}

function makeLightingPreset(name) {
if (name === 'warmHome') {
  return {
    ambient: 0.18,
    lights: [
      normalizeLight({ id: 1, type: 'point', name: '主暖灯', x: 5.5, y: 3.4, z: 3.8, radius: 300, intensity: 1.12, color: '#ffd792' }),
      normalizeLight({ id: 2, type: 'area', name: '窗边柔光', x: 2.0, y: 1.1, z: 3.1, radius: 260, intensity: 0.52, color: '#fff0d6', size: 1.8, softness: 0.72 }),
      normalizeLight({ id: 3, type: 'spot', name: '床头射灯', x: 8.2, y: 2.0, z: 3.0, radius: 220, intensity: 0.72, color: '#ffc07a', angle: 125, pitch: 68, spread: 28, softness: 0.38 }),
    ],
  };
}
if (name === 'coolShowroom') {
  return {
    ambient: 0.12,
    lights: [
      normalizeLight({ id: 1, type: 'directional', name: '冷色顶光', x: 3.0, y: 1.0, z: 4.2, radius: 620, intensity: 0.82, color: '#dff3ff', angle: -30, pitch: 63 }),
      normalizeLight({ id: 2, type: 'spot', name: '轨道射灯 A', x: 4.2, y: 2.0, z: 4.0, radius: 260, intensity: 0.92, color: '#f2fbff', angle: 45, pitch: 74, spread: 22, softness: 0.22 }),
      normalizeLight({ id: 3, type: 'spot', name: '轨道射灯 B', x: 7.8, y: 4.0, z: 4.0, radius: 250, intensity: 0.86, color: '#d9ebff', angle: 20, pitch: 72, spread: 24, softness: 0.22 }),
      normalizeLight({ id: 4, type: 'area', name: '发光面板', x: 9.0, y: 1.5, z: 3.3, radius: 220, intensity: 0.46, color: '#c8e6ff', size: 1.6, softness: 0.82 }),
    ],
  };
}
if (name === 'moonNight') {
  return {
    ambient: 0.06,
    lights: [
      normalizeLight({ id: 1, type: 'directional', name: '月光', x: 1.2, y: 0.9, z: 4.2, radius: 640, intensity: 0.72, color: '#a8d7ff', angle: -145, pitch: 42 }),
      normalizeLight({ id: 2, type: 'point', name: '夜灯', x: 7.9, y: 2.2, z: 2.4, radius: 170, intensity: 0.68, color: '#ffb36a' }),
      normalizeLight({ id: 3, type: 'area', name: '窗缝补光', x: 1.8, y: 0.9, z: 2.8, radius: 180, intensity: 0.22, color: '#d8efff', size: 1.2, softness: 0.9 }),
    ],
  };
}
return {
  ambient: 0.22,
  lights: [
    normalizeLight({ id: 1, type: 'point', name: '主灯', x: 5.5, y: 3.4, z: 3.7, radius: 310, intensity: 1.1, color: '#ffe59b' }),
    normalizeLight({ id: 2, type: 'point', name: '角落灯', x: 8.4, y: 2.4, z: 2.8, radius: 210, intensity: 0.58, color: '#a9d8ff' }),
    normalizeLight({ id: 3, type: 'directional', name: '天光', x: 2.0, y: 0.7, z: 4.2, radius: 620, intensity: 0.36, color: '#e7f3ff', angle: -60, pitch: 60 }),
    normalizeLight({ id: 4, type: 'spot', name: '射灯', x: 6.2, y: 5.2, z: 3.8, radius: 235, intensity: 0.72, color: '#fff4d2', angle: -35, pitch: 72, spread: 24, softness: 0.18 }),
    normalizeLight({ id: 5, type: 'area', name: '面板灯', x: 2.4, y: 1.4, z: 3.2, radius: 240, intensity: 0.42, color: '#f8f8ff', size: 1.7, softness: 0.84 }),
  ],
};
}

function applyLightingPreset(name) {
var preset = makeLightingPreset(name);
settings.ambient = preset.ambient;
lights.splice(0, lights.length, ...preset.lights.map(l => normalizeLight({ ...l })));
nextLightId = lights.reduce((m, l) => Math.max(m, l.id || 0), 0) + 1;
activeLightId = lights[0]?.id ?? 1;
syncLightUI();
pushLog(`lighting-preset: ${name}`);
}

var nextLightId = 6;
var lights = makeLightingPreset('allOn').lights.map(l => normalizeLight({ ...l }));
var activeLightId = lights[0].id;
var lightState = {
showAxes: true,
showShadows: true,
showGlow: true,
highContrastShadow: false,
shadowDebugColor: '#ff2a6d',
shadowAlpha: 0.24,
shadowOpacityScale: 1,
dragAxis: null,
hoverAxis: null,
dragStartMouse: null,
dragStartLight: null,
};

function activeLight() {
return lights.find(l => l.id === activeLightId) || lights[0];
}

function shouldUseFastShadowSampling() {
return !!(mouse.draggingView || lightState.dragAxis || player.moving || editor.mode === 'drag');
}

function shouldUseMediumAreaSampling() {
return lights.length >= 4 && !shouldUseFastShadowSampling();
}


function describeBox(b) {
  return `#${b.id ?? 'preview'} ${b.name ?? 'Box'} @(${b.x},${b.y},${b.z}) ${b.w}x${b.d}x${b.h}`;
}

function prettyJson(value) {
  try {
    return JSON.stringify(value, null, 2);
  } catch (err) {
    return String(value);
  }
}


var habboAssetRootState = {
  configured: false,
  root: '',
  exists: false,
  itemCount: 0,
  lastError: '',
  fetchedAt: 0,
};

var habboLibraryState = {
  loaded: false,
  loading: false,
  loadError: '',
  items: [],
  activeType: 'room',
  activeCategory: 'all',
  search: '',
  selectedAssetId: '',
  lastAt: 0,
  libraryMode: '',
  page: 1,
  pageSize: 15,
};

function habboRootSupported() {
  return isServerMode() && typeof fetch === 'function';
}

function normalizeHabboRelativePathClient(value) {
  return String(value || '').replace(/\\/g, '/').replace(/^\/+/, '').trim();
}

function basenameFromPath(value) {
  var normalized = normalizeHabboRelativePathClient(value);
  if (!normalized) return '';
  var parts = normalized.split('/');
  return parts[parts.length - 1] || '';
}

function stemFromPath(value) {
  return basenameFromPath(value).replace(/\.swf$/i, '');
}

function hashHabboPath(value) {
  var text = String(value || '');
  var hash = 2166136261 >>> 0;
  for (var i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  return hash.toString(36);
}

function makeHabboPrefabIdFromRelativePath(relativePath) {
  var normalized = normalizeHabboRelativePathClient(relativePath);
  var stem = normalized.replace(/\.swf$/i, '').replace(/[^a-zA-Z0-9_\-]+/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '') || 'item';
  return 'habbo_' + stem + '_' + hashHabboPath(normalized);
}

function makeHabboDisplayNameFromRelativePath(relativePath) {
  return 'Habbo ' + (stemFromPath(relativePath) || 'item');
}


function prettyHabboLibraryTypeLabel(type) {
  return String(type || '') === 'wall' ? '墙面' : '物品';
}

function prettyHabboLibraryCategoryLabel(category) {
  var raw = String(category || 'other').trim();
  if (!raw) raw = 'other';
  return raw.replace(/[_\-]+/g, ' ').replace(/\w/g, function (m) { return m.toUpperCase(); });
}

function makeHabboLibraryIconUrl(relativePath) {
  var rel = normalizeHabboRelativePathClient(relativePath);
  return rel ? (HABBO_LIBRARY_ICON_API_URL + '?path=' + encodeURIComponent(rel) + '&t=' + (habboLibraryState.lastAt || Date.now())) : '';
}

function getHabboLibraryCategoriesForType(type) {
  var map = new Map();
  (habboLibraryState.items || []).forEach(function (item) {
    if ((item.type || 'room') !== type) return;
    var key = String(item.category || 'other');
    map.set(key, (map.get(key) || 0) + 1);
  });
  return Array.from(map.entries()).sort(function (a, b) { return a[0].localeCompare(b[0]); }).map(function (entry) {
    return { key: entry[0], count: entry[1], label: prettyHabboLibraryCategoryLabel(entry[0]) };
  });
}

function getHabboLibraryFilteredItems() {
  var type = habboLibraryState.activeType || 'room';
  var category = habboLibraryState.activeCategory || 'all';
  var search = String(habboLibraryState.search || '').trim().toLowerCase();
  return (habboLibraryState.items || []).filter(function (item) {
    if ((item.type || 'room') !== type) return false;
    if (category !== 'all' && String(item.category || 'other') !== category) return false;
    if (!search) return true;
    var hay = [item.displayName, item.classname, item.category, item.furniLine].concat(Array.isArray(item.tags) ? item.tags : []).join(' ').toLowerCase();
    return hay.indexOf(search) >= 0;
  });
}

function getSelectedHabboLibraryItem() {
  var selectedId = String(habboLibraryState.selectedAssetId || '');
  var list = habboLibraryState.items || [];
  for (var i = 0; i < list.length; i++) if (String(list[i].assetId) === selectedId) return list[i];
  var filtered = getHabboLibraryFilteredItems();
  return filtered.length ? filtered[0] : null;
}

function ensureHabboLibrarySelection() {
  var filtered = getHabboLibraryFilteredItems();
  if (!filtered.length) {
    habboLibraryState.selectedAssetId = '';
    return null;
  }
  var current = getSelectedHabboLibraryItem();
  if (!current || filtered.findIndex(function (item) { return String(item.assetId) === String(current.assetId); }) < 0) {
    habboLibraryState.selectedAssetId = String(filtered[0].assetId);
    return filtered[0];
  }
  return current;
}

async function fetchHabboLibraryIndex(force) {
  if (!habboRootSupported()) {
    habboLibraryState.loaded = false;
    habboLibraryState.loadError = '当前不是本地 server 模式，无法读取外部 Habbo 资源库。';
    return habboLibraryState;
  }
  if (habboLibraryState.loading) return habboLibraryState;
  if (habboLibraryState.loaded && !force) return habboLibraryState;
  habboLibraryState.loading = true;
  try {
    var res = await fetch(HABBO_LIBRARY_INDEX_API_URL + '?t=' + Date.now(), { cache: 'no-store' });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    var items = Array.isArray(data.items) ? data.items.map(function (item) {
      var swfRel = normalizeHabboRelativePathClient(item.swfRelativePath || item.relativePath || '');
      var iconRel = normalizeHabboRelativePathClient(item.iconRelativePath || '');
      return {
        assetId: String(item.assetId || swfRel || Math.random()),
        prefabId: String(item.prefabId || makeHabboPrefabIdFromRelativePath(swfRel)),
        displayName: String(item.displayName || item.name || stemFromPath(swfRel) || 'Habbo item'),
        classname: String(item.classname || stemFromPath(swfRel) || ''),
        type: String(item.type || 'room').toLowerCase(),
        category: String(item.category || 'other').toLowerCase(),
        furniLine: String(item.furniLine || item.furni_line || 'other').toLowerCase(),
        swfRelativePath: swfRel,
        iconRelativePath: iconRel,
        hasIcon: !!(item.hasIcon || iconRel),
        tags: Array.isArray(item.tags) ? item.tags : [],
      };
    }).filter(function (item) { return !!item.swfRelativePath; }) : [];
    habboLibraryState.loaded = true;
    habboLibraryState.loadError = '';
    habboLibraryState.items = items;
    habboLibraryState.libraryMode = String(data.libraryMode || '');
    habboLibraryState.lastAt = Date.now();
    habboLibraryState.activeType = items.some(function (item) { return item.type === habboLibraryState.activeType; }) ? habboLibraryState.activeType : (items.some(function (item) { return item.type === 'room'; }) ? 'room' : (items[0] ? items[0].type : 'room'));
    var categories = getHabboLibraryCategoriesForType(habboLibraryState.activeType);
    if (habboLibraryState.activeCategory !== 'all' && !categories.some(function (x) { return x.key === habboLibraryState.activeCategory; })) habboLibraryState.activeCategory = 'all';
    habboLibraryState.page = 1;
    ensureHabboLibrarySelection();
  } catch (err) {
    habboLibraryState.loaded = false;
    habboLibraryState.loadError = String(err && err.message ? err.message : err);
    habboLibraryState.items = [];
  } finally {
    habboLibraryState.loading = false;
  }
  return habboLibraryState;
}

async function loadHabboLibraryItemToPlacement(item) {
  var target = item || getSelectedHabboLibraryItem();
  if (!target) throw new Error('当前没有可加载的 Habbo 资源');
  var prefabId = String(target.prefabId || makeHabboPrefabIdFromRelativePath(target.swfRelativePath));
  var existing = findPrefabByIdExact(prefabId);
  if (existing && !existing.missingPrefab) {
    prepareImportedPrefabForPlacement(existing);
    if (ui && ui.habboImportStatus) ui.habboImportStatus.textContent = '已从资源库选择：' + (existing.name || target.displayName) + '，已切换到放置模式。';
    return { prefab: existing, reused: true };
  }
  var buffer = await fetchHabboAssetFileBuffer(target.swfRelativePath);
  var result = await importHabboSwfToSceneFromBuffer(buffer, {
    assetName: basenameFromPath(target.swfRelativePath),
    relativePath: target.swfRelativePath,
    displayName: String(target.displayName || target.classname || makeHabboDisplayNameFromRelativePath(target.swfRelativePath)),
    prefabId: prefabId,
    select: true,
    prepareForPlacement: true,
    sourceKind: 'habbo-root',
  });
  if (ui && ui.habboImportStatus) ui.habboImportStatus.textContent = '资源库已加载：' + (result.prefab && result.prefab.name ? result.prefab.name : target.displayName) + '，现在可以直接在场景中点击放置。';
  return result;
}

function findPrefabByIdExact(id) {
  return prototypes.find(function (p) { return p.id === id; }) || null;
}

function ensureMissingPrefabRegistered(rawId) {
  var id = String(rawId || '').trim();
  if (!id) return prototypes[0];
  var existing = findPrefabByIdExact(id);
  if (existing) return existing;
  var placeholder = normalizePrefab({
    id: id,
    name: 'Missing Prefab · ' + id,
    kind: 'missing_prefab',
    base: '#d96b6b',
    voxels: [{ x: 0, y: 0, z: 0 }],
    custom: true,
  });
  placeholder.custom = true;
  placeholder.externalManaged = true;
  placeholder.missingPrefab = true;
  prototypes.push(placeholder);
  return placeholder;
}

function getHabboSceneRefForPrefab(prefab) {
  if (!prefab || prefab.kind !== 'habbo_import' || !prefab.habboMeta) return null;
  var relativePath = normalizeHabboRelativePathClient(prefab.habboMeta.relativePath || prefab.habboMeta.sourceName || prefab.asset || '');
  if (!relativePath || !/\.swf$/i.test(relativePath)) return null;
  return {
    prefabId: String(prefab.id || makeHabboPrefabIdFromRelativePath(relativePath)),
    sourceKind: 'habbo_swf',
    relativePath: relativePath,
    displayName: String(prefab.name || makeHabboDisplayNameFromRelativePath(relativePath)),
    assetName: basenameFromPath(relativePath) || String(prefab.asset || ''),
    type: String(prefab.habboMeta.type || ''),
  };
}

function collectSceneHabboRefs(instanceList) {
  var seen = new Set();
  var out = [];
  (instanceList || []).forEach(function (inst) {
    var prefab = findPrefabByIdExact(inst && inst.prefabId);
    var ref = getHabboSceneRefForPrefab(prefab);
    if (!ref) return;
    var key = ref.prefabId + '|' + ref.relativePath;
    if (seen.has(key)) return;
    seen.add(key);
    out.push(ref);
  });
  return out;
}

async function fetchHabboAssetRootConfig(options) {
  options = options || {};
  if (!habboRootSupported()) {
    habboAssetRootState = { configured: false, root: '', exists: false, itemCount: 0, lastError: 'server-mode-unavailable', fetchedAt: Date.now() };
    updateHabboRootStatus();
    return habboAssetRootState;
  }
  try {
    var res = await fetch(HABBO_CONFIG_API_URL + '?t=' + Date.now(), { cache: 'no-store' });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    habboAssetRootState = {
      configured: !!data.configured,
      root: String(data.root || ''),
      exists: !!data.exists,
      itemCount: Number.isFinite(Number(data.itemCount)) ? Number(data.itemCount) : 0,
      lastError: '',
      fetchedAt: Date.now(),
    };
  } catch (err) {
    habboAssetRootState = {
      configured: false,
      root: '',
      exists: false,
      itemCount: 0,
      lastError: String(err && err.message ? err.message : err),
      fetchedAt: Date.now(),
    };
  }
  if (!options.silent) updateHabboRootStatus();
  return habboAssetRootState;
}

function updateHabboRootStatus(message) {
  if (!ui || !ui.habboRootStatus) return;
  if (message) {
    ui.habboRootStatus.textContent = String(message);
    return;
  }
  if (!habboRootSupported()) {
    ui.habboRootStatus.textContent = 'Habbo 根目录：当前不是本地服务器模式，无法配置固定素材目录。';
    return;
  }
  if (habboAssetRootState.lastError) {
    ui.habboRootStatus.textContent = 'Habbo 根目录：' + habboAssetRootState.lastError;
    return;
  }
  if (!habboAssetRootState.configured) {
    ui.habboRootStatus.textContent = 'Habbo 根目录：未配置。请把它设为“分类后的 Habbo 素材库根目录”；之后资源选择器会直接读 index.json、icon 和 swf。';
    return;
  }
  ui.habboRootStatus.textContent = 'Habbo 根目录：' + habboAssetRootState.root + (habboAssetRootState.exists ? (' · 已检测到 ' + habboAssetRootState.itemCount + ' 个 SWF') : ' · 路径不存在');
}

async function setHabboAssetRootConfig(rootPath) {
  if (!habboRootSupported()) {
    updateHabboRootStatus();
    return false;
  }
  try {
    var res = await fetch(HABBO_CONFIG_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({ root: String(rootPath || '') })
    });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    habboAssetRootState = {
      configured: !!data.configured,
      root: String(data.root || ''),
      exists: !!data.exists,
      itemCount: Number.isFinite(Number(data.itemCount)) ? Number(data.itemCount) : 0,
      lastError: '',
      fetchedAt: Date.now(),
    };
    updateHabboRootStatus('Habbo 根目录已设置为：' + habboAssetRootState.root + (habboAssetRootState.exists ? (' · 当前检测到 ' + habboAssetRootState.itemCount + ' 个 SWF') : ' · 但路径暂不存在'));
    pushLog('habbo-root:set root=' + habboAssetRootState.root + ' exists=' + habboAssetRootState.exists + ' count=' + habboAssetRootState.itemCount);
    return true;
  } catch (err) {
    updateHabboRootStatus('Habbo 根目录设置失败：' + (err && err.message ? err.message : err));
    pushLog('habbo-root:set-error ' + (err && err.message ? err.message : err));
    return false;
  }
}

async function fetchHabboAssetFileBuffer(relativePath) {
  var rel = normalizeHabboRelativePathClient(relativePath);
  if (!rel) throw new Error('缺少 relativePath');
  var res = await fetch(HABBO_FILE_API_URL + '?path=' + encodeURIComponent(rel) + '&t=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) {
    var detail = '';
    try {
      var j = await res.json();
      detail = j && j.error ? j.error : '';
    } catch (err) {
      detail = 'HTTP ' + res.status;
    }
    throw new Error(detail || ('HTTP ' + res.status));
  }
  return await res.arrayBuffer();
}

async function ensureSceneHabboRefsLoaded(snapshot, options) {
  options = options || {};
  var refs = snapshot && Array.isArray(snapshot.habboRefs) ? snapshot.habboRefs : [];
  if (!refs.length) return { ok: true, loaded: 0, skipped: 0, failed: 0 };
  if (!habboRootSupported()) return { ok: false, loaded: 0, skipped: refs.length, failed: refs.length, reason: 'server-mode-unavailable' };
  if (!habboAssetRootState.fetchedAt) await fetchHabboAssetRootConfig({ silent: true });
  var loaded = 0;
  var skipped = 0;
  var failed = 0;
  for (var i = 0; i < refs.length; i++) {
    var ref = refs[i] || {};
    var prefabId = String(ref.prefabId || '').trim();
    var relativePath = normalizeHabboRelativePathClient(ref.relativePath || ref.sourceName || '');
    if (!prefabId || !relativePath) { failed += 1; continue; }
    var existing = findPrefabByIdExact(prefabId);
    if (existing && !existing.missingPrefab) { skipped += 1; continue; }
    try {
      var buffer = await fetchHabboAssetFileBuffer(relativePath);
      await importHabboSwfToSceneFromBuffer(buffer, {
        assetName: basenameFromPath(relativePath),
        relativePath: relativePath,
        displayName: String(ref.displayName || makeHabboDisplayNameFromRelativePath(relativePath)),
        prefabId: prefabId,
        select: false,
        prepareForPlacement: false,
        sourceKind: 'habbo-root',
      });
      loaded += 1;
    } catch (err) {
      ensureMissingPrefabRegistered(prefabId);
      failed += 1;
      pushLog('habbo-scene-ref:error prefab=' + prefabId + ' relativePath=' + relativePath + ' error=' + (err && err.message ? err.message : err));
    }
  }
  if (loaded > 0) refreshPrefabSelectOptions();
  return { ok: failed === 0, loaded: loaded, skipped: skipped, failed: failed };
}

async function applySceneSnapshotWithExternalAssets(snapshot, options) {
  options = options || {};
  await ensureSceneHabboRefsLoaded(snapshot, { source: options.source || 'scene-load' });
  applySceneSnapshot(snapshot, options);
  if (snapshot && Array.isArray(snapshot.habboRefs) && snapshot.habboRefs.length) {
    var summary = collectSceneHabboRefs(snapshot.instances || []).length;
    detailLog('scene-habbo: refs=' + snapshot.habboRefs.length + ' active=' + summary);
  }
  return true;
}

async function scanHabboAssetRoot(force) {
  if (!habboRootSupported()) {
    updateHabboRootStatus();
    pushLog('habbo-root-scan: server mode unavailable');
    return false;
  }
  var currentPrefabId = currentPrefab() ? currentPrefab().id : '';
  var currentMode = editor.mode;
  try {
    var res = await fetch(HABBO_INDEX_API_URL + '?t=' + Date.now(), { cache: 'no-store' });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    var items = Array.isArray(data.items) ? data.items : [];
    if (!items.length) {
      habboAssetRootState.itemCount = 0;
      updateHabboRootStatus('Habbo 根目录已配置，但当前没有找到 SWF 文件。');
      return true;
    }
    updateHabboRootStatus('Habbo 根目录：正在扫描 ' + items.length + ' 个 SWF，请稍候…');
    var imported = 0;
    var failed = 0;
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      try {
        var buffer = await fetchHabboAssetFileBuffer(item.relativePath);
        await importHabboSwfToSceneFromBuffer(buffer, {
          assetName: item.name,
          relativePath: item.relativePath,
          displayName: makeHabboDisplayNameFromRelativePath(item.relativePath),
          prefabId: makeHabboPrefabIdFromRelativePath(item.relativePath),
          select: false,
          prepareForPlacement: false,
          sourceKind: 'habbo-root',
        });
        imported += 1;
      } catch (err) {
        failed += 1;
        pushLog('habbo-root-scan:file-error path=' + item.relativePath + ' error=' + (err && err.message ? err.message : err));
      }
    }
    refreshPrefabSelectOptions();
    if (currentPrefabId) {
      var idx = prototypes.findIndex(function (p) { return p.id === currentPrefabId; });
      if (idx >= 0) {
        editor.prototypeIndex = idx;
        if (ui.prefabSelect) ui.prefabSelect.value = String(idx);
      }
    }
    editor.mode = currentMode;
    updateModeButtons();
    if (editor.mode === 'place' || editor.mode === 'drag') updatePreview();
    habboAssetRootState.itemCount = items.length;
    habboAssetRootState.configured = true;
    habboAssetRootState.exists = true;
    habboAssetRootState.lastError = '';
    habboAssetRootState.fetchedAt = Date.now();
    updateHabboRootStatus('Habbo 根目录扫描完成：共 ' + items.length + ' 个 SWF，成功导入 ' + imported + ' 个，失败 ' + failed + ' 个。');
    pushLog('habbo-root-scan: files=' + items.length + ' imported=' + imported + ' failed=' + failed + ' force=' + (!!force));
    if (ui.prefabHint && currentPrefab()) ui.prefabHint.textContent = `当前模板：${currentPrefab().name}，局部体素 ${currentPrefab().voxels.length} 个，尺寸 ${currentPrefab().w}×${currentPrefab().d}×${currentPrefab().h}。`;
    return true;
  } catch (err) {
    updateHabboRootStatus('Habbo 根目录扫描失败：' + (err && err.message ? err.message : err));
    pushLog('habbo-root-scan:error ' + (err && err.message ? err.message : err));
    return false;
  }
}

function sceneSnapshot() {
  return {
    settings: { ...settings },
    camera: { ...camera },
    player: { x: player.x, y: player.y, dir: player.dir, r: player.r },
    editor: {
      mode: editor.mode,
      prototypeIndex: editor.prototypeIndex,
      rotation: editor.rotation,
      draggingInstance: editor.draggingInstance ? { ...editor.draggingInstance } : null,
      preview: editor.preview ? {
        valid: editor.preview.valid,
        reason: editor.preview.reason ?? '',
        supportZ: editor.preview.supportZ ?? null,
        supportHeights: editor.preview.supportHeights ?? [],
        overlapIds: editor.preview.overlapIds ?? [],
        box: editor.preview.box ? { ...editor.preview.box } : null,
      } : null,
    },
    instances: instances.map(inst => ({ ...inst })),
    boxes: boxes.map(b => ({ ...b })),
    lights: lights.map(l => ({ ...l })),
    activeLightId,
  };
}

function persistentSceneSnapshot() {
  return {
    settings: {
      worldCols: settings.worldCols,
      worldRows: settings.worldRows,
      worldResolution: settings.worldResolution,
      worldDisplayScale: settings.worldDisplayScale,
      gridW: settings.gridW,
      gridH: settings.gridH,
      tileScale: settings.tileScale,
      playerHeightCells: settings.playerHeightCells,
      playerProxyW: settings.playerProxyW,
      playerProxyD: settings.playerProxyD,
      ambient: settings.ambient,
    },
    camera: { x: camera.x, y: camera.y },
    player: { x: player.x, y: player.y, dir: player.dir, r: player.r },
    editor: {
      mode: editor.mode,
      prototypeIndex: editor.prototypeIndex,
      rotation: editor.rotation,
    },
    shadowUi: {
      highContrastShadow: !!lightState.highContrastShadow,
      shadowDebugColor: lightState.shadowDebugColor || '#ff2a6d',
      shadowAlpha: Number.isFinite(Number(lightState.shadowAlpha)) ? Number(lightState.shadowAlpha) : 0.24,
      shadowOpacityScale: Number.isFinite(Number(lightState.shadowOpacityScale)) ? Number(lightState.shadowOpacityScale) : 1,
    },
    instances: instances.map(inst => ({ ...inst })),
    habboRefs: collectSceneHabboRefs(instances),
    boxes: boxes.map(b => ({ ...b })),
    lights: lights.map(l => ({ ...l })),
    activeLightId,
  };
}

function createDefaultSceneData() {
  return {
    settings: {
      worldCols: 11,
      worldRows: 9,
      worldResolution: 1,
      worldDisplayScale: 1,
      gridW: 11,
      gridH: 9,
      tileScale: 1,
      playerHeightCells: 1.7,
      playerProxyW: 0.32,
      playerProxyD: 0.24,
      ambient: 0.22,
    },
    camera: { x: 0, y: 0 },
    player: { x: 1.1, y: 1.1, dir: 'down', r: 0.22 },
    editor: {
      mode: 'view',
      prototypeIndex: 0,
      rotation: 0,
    },
    shadowUi: {
      highContrastShadow: false,
      shadowDebugColor: '#ff2a6d',
      shadowAlpha: 0.24,
      shadowOpacityScale: 1,
    },
    instances: defaultInstances().map(inst => ({ ...inst })),
    boxes: defaultBoxes().map(b => ({ ...b })),
    lights: makeLightingPreset('allOn').lights.map(l => normalizeLight({ ...l })),
    activeLightId: 1,
  };
}

function sceneStorageAvailable() {
  try {
    if (!window.localStorage) return false;
    const probe = '__scene_storage_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    return true;
  } catch (err) {
    detailLog(`scene-storage: unavailable reason=${err?.message || err}`);
    return false;
  }
}

function applySceneSnapshot(snapshot, options = {}) {
  clearSelectedInstance();
  const base = createDefaultSceneData();
  const incoming = snapshot && typeof snapshot === 'object' ? snapshot : {};
  const nextSettings = { ...base.settings, ...(incoming.settings || {}) };
  nextSettings.worldResolution = clamp(parseInt(nextSettings.worldResolution || 1, 10) || 1, 1, 4);
  if (![1, 2, 4].includes(nextSettings.worldResolution)) nextSettings.worldResolution = 1;
  nextSettings.worldCols = clamp(parseInt(nextSettings.worldCols ?? nextSettings.gridW ?? base.settings.worldCols, 10) || base.settings.worldCols, WORLD_SIZE_MIN, WORLD_SIZE_MAX);
  nextSettings.worldRows = clamp(parseInt(nextSettings.worldRows ?? nextSettings.gridH ?? base.settings.worldRows, 10) || base.settings.worldRows, WORLD_SIZE_MIN, WORLD_SIZE_MAX);
  nextSettings.worldDisplayScale = clamp(parseFloat(nextSettings.worldDisplayScale ?? ((nextSettings.tileScale || base.settings.worldDisplayScale) * nextSettings.worldResolution)), 0.5, 2.4);
  setElValue(ui.gridW, String(nextSettings.worldCols));
  setElValue(ui.gridH, String(nextSettings.worldRows));
  setElValue(ui.worldResolution, String(nextSettings.worldResolution));
  setElValue(ui.tileScale, String(nextSettings.worldDisplayScale));
  setElValue(ui.playerHeightCells, String(nextSettings.playerHeightCells));
  setElValue(ui.playerProxyW, String(nextSettings.playerProxyW));
  setElValue(ui.playerProxyD, String(nextSettings.playerProxyD));
  applySettings();
  settings.ambient = clamp(Number(nextSettings.ambient ?? base.settings.ambient), 0, 0.6);
  setElValue(ui.ambientStrength, String(settings.ambient));
  setElText(ui.ambientValue, settings.ambient.toFixed(2));

  var nextInstances = Array.isArray(incoming.instances) && incoming.instances.length ? incoming.instances : null;
  if (!nextInstances && Array.isArray(incoming.boxes) && incoming.boxes.length) nextInstances = legacyBoxesToInstances(incoming.boxes);
  if (!nextInstances || !nextInstances.length) nextInstances = base.instances;
  instances = nextInstances.map(function (inst, idx) {
    return {
      instanceId: typeof inst.instanceId === 'string' && inst.instanceId ? inst.instanceId : 'obj_' + String(idx + 1).padStart(4, '0'),
      prefabId: (findPrefabByIdExact(inst.prefabId || '') || ensureMissingPrefabRegistered(inst.prefabId || '')).id,
      x: Number(inst.x) || 0,
      y: Number(inst.y) || 0,
      z: Number(inst.z) || 0,
      rotation: ((parseInt(inst.rotation || 0, 10) % 2) + 2) % 2,
      name: inst.name || undefined,
    };
  });
  filterInstancesToGrid();
  recomputeNextInstanceSerial();
  rebuildBoxesFromInstances();

  const nextLights = Array.isArray(incoming.lights) && incoming.lights.length ? incoming.lights : base.lights;
  lights = nextLights.map((l, idx) => normalizeLight({ ...l, id: Number.isFinite(Number(l.id)) ? Number(l.id) : idx + 1 }));
  nextLightId = lights.reduce((m, l) => Math.max(m, l.id || 0), 0) + 1;
  activeLightId = lights.some(l => l.id === incoming.activeLightId) ? incoming.activeLightId : (lights[0]?.id ?? 1);

  const nextCamera = { ...base.camera, ...(incoming.camera || {}) };
  camera.x = Number(nextCamera.x) || 0;
  camera.y = Number(nextCamera.y) || 0;

  const nextShadowUi = { ...base.shadowUi, ...(incoming.shadowUi || {}) };
  lightState.highContrastShadow = !!nextShadowUi.highContrastShadow;
  lightState.shadowDebugColor = typeof nextShadowUi.shadowDebugColor === 'string' ? nextShadowUi.shadowDebugColor : base.shadowUi.shadowDebugColor;
  lightState.shadowAlpha = clamp(Number(nextShadowUi.shadowAlpha ?? base.shadowUi.shadowAlpha), 0.1, 1.6);
  lightState.shadowOpacityScale = clamp(Number(nextShadowUi.shadowOpacityScale ?? base.shadowUi.shadowOpacityScale), 0.3, 3);

  const nextPlayer = { ...base.player, ...(incoming.player || {}) };
  player.x = clamp(Number(nextPlayer.x) || base.player.x, player.r + 0.05, settings.gridW - player.r - 0.05);
  player.y = clamp(Number(nextPlayer.y) || base.player.y, player.r + 0.05, settings.gridH - player.r - 0.05);
  player.dir = typeof nextPlayer.dir === 'string' ? nextPlayer.dir : base.player.dir;
  player.r = Math.max(0.05, Number(nextPlayer.r) || base.player.r);
  player.walk = 0;
  player.moving = false;

  const nextEditor = { ...base.editor, ...(incoming.editor || {}) };
  editor.prototypeIndex = clamp(parseInt(nextEditor.prototypeIndex ?? base.editor.prototypeIndex, 10) || 0, 0, prototypes.length - 1);
  refreshPrefabSelectOptions();
  if (ui.prefabSelect) ui.prefabSelect.value = String(editor.prototypeIndex);
  editor.rotation = (parseInt(nextEditor.rotation ?? base.editor.rotation, 10) || 0) % 2;
  editor.draggingInstance = null;
  editor.preview = null;
  editor.hoverDeleteBox = null;
  editor.mode = ['view', 'place', 'delete'].includes(nextEditor.mode) ? nextEditor.mode : base.editor.mode;

  mouse.draggingView = false;
  lightState.dragAxis = null;
  lightState.hoverAxis = null;
  lightState.dragStartMouse = null;
  lightState.dragStartLight = null;

  updateModeButtons();
  if (editor.mode === 'place' || editor.mode === 'drag') updatePreview();
  invalidateShadowGeometryCache(options.reason || 'applySceneSnapshot');
  syncLightUI();
  if (options.log !== false) {
    pushLog(`scene-apply: source=${options.source || 'unknown'} instances=${instances.length} boxes=${boxes.length} lights=${lights.length} grid=${settings.gridW}x${settings.gridH}`);
  }
}

function saveSceneToLocalStorage() {
  if (!sceneStorageAvailable()) {
    pushLog('scene-save: localStorage unavailable');
    return false;
  }
  const snapshot = persistentSceneSnapshot();
  window.localStorage.setItem(LOCAL_SCENE_STORAGE_KEY, JSON.stringify(snapshot));
  pushLog(`scene-save: key=${LOCAL_SCENE_STORAGE_KEY} instances=${snapshot.instances.length} boxes=${snapshot.boxes.length} lights=${snapshot.lights.length}`);
  return true;
}

async function loadSceneFromLocalStorage(options = {}) {
  if (!sceneStorageAvailable()) {
    pushLog('scene-load: localStorage unavailable');
    return false;
  }
  const raw = window.localStorage.getItem(LOCAL_SCENE_STORAGE_KEY);
  if (!raw) {
    if (!options.silent) pushLog('scene-load: no saved scene');
    return false;
  }
  try {
    const snapshot = JSON.parse(raw);
    await applySceneSnapshotWithExternalAssets(snapshot, { source: options.source || 'localStorage', reason: 'loadScene', log: !options.silent });
    scheduleLegacyHabboRepairs('scene-load');
    return true;
  } catch (err) {
    pushLog(`scene-load:error ${err?.message || err}`);
    return false;
  }
}

function clearSavedSceneFromLocalStorage() {
  if (!sceneStorageAvailable()) return false;
  window.localStorage.removeItem(LOCAL_SCENE_STORAGE_KEY);
  pushLog(`scene-clear: key=${LOCAL_SCENE_STORAGE_KEY}`);
  return true;
}

function sanitizeSceneFilenameClient(name, fallback) {
  var base = String(name || '').trim().replace(/[<>:"/\\|?*]+/g, '_').replace(/[\r\n\t]+/g, ' ').replace(/^\.+/, '').replace(/[. ]+$/g, '');
  if (!base) base = String(fallback || 'scene');
  if (!/\.json$/i.test(base)) base += '.json';
  return base;
}

function makeSceneTimestampToken() {
  var now = new Date();
  var y = now.getFullYear();
  var m = String(now.getMonth() + 1).padStart(2, '0');
  var d = String(now.getDate()).padStart(2, '0');
  var hh = String(now.getHours()).padStart(2, '0');
  var mm = String(now.getMinutes()).padStart(2, '0');
  var ss = String(now.getSeconds()).padStart(2, '0');
  return `${y}${m}${d}_${hh}${mm}${ss}`;
}

function suggestSceneFilename(seed) {
  return sanitizeSceneFilenameClient(seed || currentSceneServerFile || `scene_${makeSceneTimestampToken()}` , 'scene');
}

function sceneFilesSupported() {
  return isServerMode() && typeof fetch === 'function';
}

function persistCurrentSceneServerFileName(filename) {
  currentSceneServerFile = filename ? String(filename) : '';
  if (!sceneStorageAvailable()) return currentSceneServerFile;
  try {
    if (currentSceneServerFile) window.localStorage.setItem(LOCAL_SCENE_CURRENT_FILE_KEY, currentSceneServerFile);
    else window.localStorage.removeItem(LOCAL_SCENE_CURRENT_FILE_KEY);
  } catch (err) {
    detailLog(`scene-current-file:error ${err?.message || err}`);
  }
  return currentSceneServerFile;
}

function recallCurrentSceneServerFileName() {
  if (currentSceneServerFile) return currentSceneServerFile;
  if (!sceneStorageAvailable()) return '';
  try {
    currentSceneServerFile = String(window.localStorage.getItem(LOCAL_SCENE_CURRENT_FILE_KEY) || '');
  } catch (err) {
    currentSceneServerFile = '';
  }
  return currentSceneServerFile;
}

function updateSceneFileStatus(message) {
  if (!ui || !ui.sceneFileStatus) return;
  if (message) {
    ui.sceneFileStatus.textContent = String(message);
    return;
  }
  if (!sceneFilesSupported()) {
    ui.sceneFileStatus.textContent = '场景文件：当前不是 http 本地服务器模式；“保存到文件 / 默认打开”不可用，但仍可用导出 JSON 与浏览器存档。';
    return;
  }
  var current = recallCurrentSceneServerFileName();
  ui.sceneFileStatus.textContent = current ? `场景文件：当前默认文件为 ${current}，下次启动会优先打开它。` : '场景文件：还没有默认文件；可先点“保存到文件”。';
}

async function saveSceneToServerFile(filename, options = {}) {
  if (!sceneFilesSupported()) {
    updateSceneFileStatus();
    pushLog('scene-file-save: server mode unavailable');
    return false;
  }
  var nextFilename = suggestSceneFilename(filename);
  try {
    var snapshot = persistentSceneSnapshot();
    var res = await fetch(SCENE_API_SAVE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({ filename: nextFilename, scene: snapshot, setDefault: options.setDefault !== false })
    });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    persistCurrentSceneServerFileName(data.file || nextFilename);
    updateSceneFileStatus(`场景文件：已保存到 ${data.path || ('assets/scenes/' + (data.file || nextFilename))}，并设为默认打开。`);
    pushLog(`scene-file-save: file=${data.file || nextFilename} instances=${snapshot.instances.length} boxes=${snapshot.boxes.length} lights=${snapshot.lights.length} default=${options.setDefault !== false}`);
    return true;
  } catch (err) {
    updateSceneFileStatus(`场景文件保存失败：${err?.message || err}`);
    pushLog(`scene-file-save:error ${err?.message || err}`);
    return false;
  }
}

async function loadSceneFromServerFile(filename, options = {}) {
  if (!sceneFilesSupported()) {
    updateSceneFileStatus();
    pushLog('scene-file-load: server mode unavailable');
    return false;
  }
  var nextFilename = suggestSceneFilename(filename, 'scene');
  try {
    var res = await fetch(`${SCENE_API_LOAD_URL}?file=${encodeURIComponent(nextFilename)}`, { cache: 'no-store' });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    await applySceneSnapshotWithExternalAssets(data.scene, { source: options.source || 'scene-file', reason: options.reason || 'loadSceneFile', log: !options.silent });
    scheduleLegacyHabboRepairs('scene-file-load');
    persistCurrentSceneServerFileName(data.file || nextFilename);
    updateSceneFileStatus(`场景文件：已打开 ${data.file || nextFilename}。`);
    pushLog(`scene-file-load: file=${data.file || nextFilename}`);
    return true;
  } catch (err) {
    updateSceneFileStatus(`场景文件读取失败：${err?.message || err}`);
    pushLog(`scene-file-load:error ${err?.message || err}`);
    return false;
  }
}

async function loadDefaultSceneFromServer(options = {}) {
  if (!sceneFilesSupported()) {
    updateSceneFileStatus();
    return false;
  }
  try {
    var res = await fetch(SCENE_API_DEFAULT_URL, { cache: 'no-store' });
    var data = await res.json();
    if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status));
    if (!data.hasDefault || !data.scene) {
      persistCurrentSceneServerFileName('');
      if (!options.silent) updateSceneFileStatus('场景文件：还没有默认文件；可先点“保存到文件”。');
      return false;
    }
    await applySceneSnapshotWithExternalAssets(data.scene, { source: options.source || 'scene-default', reason: options.reason || 'loadDefaultSceneFile', log: !options.silent });
    scheduleLegacyHabboRepairs('scene-default-load');
    persistCurrentSceneServerFileName(data.file || '');
    updateSceneFileStatus(`场景文件：已自动打开默认文件 ${data.file}。`);
    pushLog(`scene-default-load: file=${data.file}`);
    return true;
  } catch (err) {
    updateSceneFileStatus(`默认场景文件读取失败：${err?.message || err}`);
    pushLog(`scene-default-load:error ${err?.message || err}`);
    return false;
  }
}

async function importSceneJsonFile(file, options = {}) {
  if (!file) return false;
  try {
    var text = await file.text();
    var snapshot = JSON.parse(text);
    await applySceneSnapshotWithExternalAssets(snapshot, { source: options.source || 'scene-import', reason: 'importSceneFile', log: true });
    scheduleLegacyHabboRepairs('scene-import');
    pushLog(`scene-import: name=${file.name} bytes=${file.size || 0}`);
    if (sceneFilesSupported()) {
      var importedFilename = suggestSceneFilename(file.name || 'imported_scene.json');
      await saveSceneToServerFile(importedFilename, { setDefault: options.setDefault !== false });
    } else {
      saveSceneToLocalStorage();
      updateSceneFileStatus('场景文件：已导入到当前场景；当前模式不支持默认文件，已同时写入浏览器存档。');
    }
    return true;
  } catch (err) {
    updateSceneFileStatus(`场景导入失败：${err?.message || err}`);
    pushLog(`scene-import:error ${err?.message || err}`);
    return false;
  }
}

function exportSceneJsonDownload(filename = 'scene.json') {
  try {
    const snapshot = persistentSceneSnapshot();
    const payload = `${JSON.stringify(snapshot, null, 2)}
`;
    const blob = new Blob([payload], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
    pushLog(`scene-export: file=${filename} instances=${snapshot.instances.length} boxes=${snapshot.boxes.length} lights=${snapshot.lights.length}`);
    return true;
  } catch (err) {
    pushLog(`scene-export:error ${err?.message || err}`);
    return false;
  }
}

function createWorldSceneDataFromUi(options) {
  options = options || {};
  var base = createDefaultSceneData();
  var worldCols = clamp(parseInt((ui.gridW && ui.gridW.value) || '11', 10) || 11, WORLD_SIZE_MIN, WORLD_SIZE_MAX);
  var worldRows = clamp(parseInt((ui.gridH && ui.gridH.value) || '9', 10) || 9, WORLD_SIZE_MIN, WORLD_SIZE_MAX);
  var worldResolution = clamp(parseInt((ui.worldResolution && ui.worldResolution.value) || '1', 10) || 1, 1, 4);
  if (![1, 2, 4].includes(worldResolution)) worldResolution = 1;
  var worldDisplayScale = clamp(parseFloat((ui.tileScale && ui.tileScale.value) || '1'), 0.5, 2.4);
  base.settings.worldCols = worldCols;
  base.settings.worldRows = worldRows;
  base.settings.worldResolution = worldResolution;
  base.settings.worldDisplayScale = worldDisplayScale;
  base.settings.gridW = worldCols * worldResolution;
  base.settings.gridH = worldRows * worldResolution;
  base.settings.tileScale = worldDisplayScale / worldResolution;
  base.settings.playerHeightCells = settings.playerHeightCells;
  base.settings.playerProxyW = settings.playerProxyW;
  base.settings.playerProxyD = settings.playerProxyD;
  base.settings.ambient = settings.ambient;
  base.player = { x: 1.1 * worldResolution, y: 1.1 * worldResolution, dir: 'down', r: player.r };
  base.instances = [];
  base.boxes = [];
  if (options.keepLights !== false) {
    base.lights = lights.map(function (l) { return normalizeLight({ ...l }); });
    base.activeLightId = activeLightId;
    base.shadowUi = {
      highContrastShadow: !!lightState.highContrastShadow,
      shadowDebugColor: lightState.shadowDebugColor || '#ff2a6d',
      shadowAlpha: Number.isFinite(Number(lightState.shadowAlpha)) ? Number(lightState.shadowAlpha) : 0.24,
      shadowOpacityScale: Number.isFinite(Number(lightState.shadowOpacityScale)) ? Number(lightState.shadowOpacityScale) : 1,
    };
  }
  base.editor.mode = 'view';
  base.editor.prototypeIndex = editor.prototypeIndex;
  base.editor.rotation = 0;
  return base;
}

function resetSceneToDefault() {
  clearSelectedInstance();
  clearSavedSceneFromLocalStorage();
  applySceneSnapshot(createDefaultSceneData(), { source: 'default', reason: 'resetScene' });
}

function applyWorldToNewScene() {
  clearSelectedInstance();
  var scene = createWorldSceneDataFromUi({ keepLights: true });
  applySceneSnapshot(scene, { source: 'world-ui', reason: 'newWorld' });
  pushLog(`world-apply: cols=${settings.worldCols} rows=${settings.worldRows} resolution=${settings.worldResolution} actualGrid=${settings.gridW}x${settings.gridH} tileScale=${settings.tileScale.toFixed(2)}`);
}

function updateModeButtons() {
  ui.modeView.classList.toggle('active', editor.mode === 'view');
  ui.modePlace.classList.toggle('active', editor.mode === 'place' || editor.mode === 'drag');
  ui.modeDelete.classList.toggle('active', editor.mode === 'delete');
}

function setEditorMode(mode) {
  if (mode === 'view') {
    cancelDrag();
    editor.mode = 'view';
    editor.preview = null;
  } else if (mode === 'place') {
    if (editor.mode === 'drag' && editor.draggingInstance) cancelDrag();
    editor.mode = 'place';
    updatePreview();
  } else if (mode === 'delete') {
    cancelDrag();
    editor.mode = 'delete';
    editor.preview = null;
  }
  pushLog(`mode: ${mode}`);
  updateModeButtons();
}

function flushDebugLogUI(force = false) {
  if (!ui.debugLog) return;
  const now = (typeof performance !== 'undefined' && typeof performance.now === 'function') ? performance.now() : Date.now();
  if (!force && lastLogUiFlushAt && (now - lastLogUiFlushAt) < LOG_UI_FLUSH_MS) return;
  ui.debugLog.value = logs.slice(-LOG_UI_PREVIEW_LINES).join('\n');
  ui.debugLog.scrollTop = ui.debugLog.scrollHeight;
  lastLogUiFlushAt = now;
  logFlushScheduled = false;
}

function scheduleDebugLogUIFlush() {
  if (logFlushScheduled) return;
  logFlushScheduled = true;
  const cb = () => flushDebugLogUI(true);
  if (typeof requestAnimationFrame === 'function') requestAnimationFrame(cb);
  else setTimeout(cb, LOG_UI_FLUSH_MS);
}

function pushLog(msg) {
  const line = `[${String(++logSeq).padStart(5,'0')}] [${new Date().toLocaleTimeString('zh-CN', { hour12:false })}] ${msg}`;
  logs.push(line);
  if (logs.length > MAX_LOG_LINES) logs.shift();
  scheduleDebugLogUIFlush();
}

function exportLogs() {
  pushLog(`log-export:start lines=${logs.length} entry=${APP_ENTRY_INFO.kind || 'unknown'}:${APP_ENTRY_INFO.entryFile || 'unknown'}`);
  flushPerfSummary(true);
  flushDebugLogUI(true);
  const payload = buildLogExportHeader() + logs.join('\n');
  const blob = new Blob([payload], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `isometric-debug-log-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

logSystemReady = true;
if (bootBuffer.length) {
  for (const line of bootBuffer) pushLog(line);
  bootBuffer.length = 0;
}
detailLog('log-system: ready');
logResolvedEntryInfo();

var settings = {
  worldCols: 11,
  worldRows: 9,
  worldResolution: 1,
  worldDisplayScale: 1,
  gridW: 11,
  gridH: 9,
  tileScale: 1,
  playerHeightCells: 1.7,
  playerProxyW: 0.32,
  playerProxyD: 0.24,
  tileW: BASE_TILE_W,
  tileH: BASE_TILE_H,
  originX: VIEW_W * 0.57,
  originY: 150,
  ambient: 0.22,
};

var spriteSheet = new Image();
spriteSheet.onload = () => {
  assetsReady = true;
  detailLog(`asset: sprite loaded ${spriteSheet.naturalWidth}x${spriteSheet.naturalHeight}`);
};
spriteSheet.onerror = () => {
  assetsReady = false;
  detailLog(`asset-error: sprite load failed src=${spriteSheet.src}`);
};
detailLog('asset: start loading assets/chibi_walk.png');
spriteSheet.src = 'assets/chibi_walk.png';
setTimeout(() => {
  if (!assetsReady) detailLog(`asset-wait: sprite not ready after 1200ms src=${spriteSheet.src}`);
}, 1200);

var SPRITE = {
  frameW: 72,
  frameH: 96,
  bottom: 88,
  top: 10,
  rows: { down: 0, left: 2, right: 1, up: 3 },
  frames: 4,
};

var PREFAB_KEY_LIMIT = 7;
var nextInstanceSerial = 1;

function cloneVoxel(v) {
  return { ...v };
}


function normalizedCountText(n) {
  return String(Number(n) || 0) + ' voxels';
}

function makeRectVoxels(w, d, h, base) {
  var voxels = [];
  for (var x = 0; x < w; x++) {
    for (var y = 0; y < d; y++) {
      for (var z = 0; z < h; z++) voxels.push({ x: x, y: y, z: z, solid: true, collidable: true, base: base });
    }
  }
  return voxels;
}


function normalizeSpriteInfo(sprite) {
  if (!sprite || typeof sprite !== 'object' || !sprite.image) return null;
  return {
    image: String(sprite.image || ''),
    fileName: String(sprite.fileName || sprite.name || ''),
    scale: Math.max(0.05, Math.min(16, Number(sprite.scale) || 1)),
    offsetPx: {
      x: Number(sprite.offsetPx && sprite.offsetPx.x) || 0,
      y: Number(sprite.offsetPx && sprite.offsetPx.y) || 0,
    },
    anchorMode: String(sprite.anchorMode || 'bottom-center'),
    sortMode: String(sprite.sortMode || 'box_occlusion'),
    visualSize: Math.max(1, Number(sprite.visualSize) || 64),
  };
}

function normalizeSpriteDirections(map) {
  if (!map || typeof map !== 'object') return null;
  var out = {};
  Object.keys(map).forEach(function (key) {
    var raw = map[key];
    var cfg = normalizeSpriteInfo(raw);
    if (!cfg) return;
    cfg.flipX = !!(raw && raw.flipX);
    out[String(key)] = cfg;
  });
  return Object.keys(out).length ? out : null;
}

function normalizeHabboLayerDirections(map) {
  if (!map || typeof map !== 'object') return null;
  var out = {};
  Object.keys(map).forEach(function (key) {
    var rawList = Array.isArray(map[key]) ? map[key] : [];
    var norm = rawList.map(function (raw, index) {
      if (!raw || !raw.image) return null;
      return {
        image: String(raw.image || ''),
        fileName: String(raw.fileName || ''),
        width: Math.max(1, Number(raw.width) || 1),
        height: Math.max(1, Number(raw.height) || 1),
        visualSize: Math.max(1, Number(raw.visualSize) || 64),
        offsetPx: { x: Number(raw.offsetPx && raw.offsetPx.x) || 0, y: Number(raw.offsetPx && raw.offsetPx.y) || 0 },
        offsetZ: Number(raw.offsetZ) || 0,
        flipX: !!raw.flipX,
        kind: String(raw.kind || 'body'),
        layerId: String(raw.layerId || ''),
        layerIndex: Number(raw.layerIndex) || 0,
        name: String(raw.name || ('layer_' + index)),
        zOrderHint: Number(raw.zOrderHint) || 0,
        alpha: raw.alpha == null ? 1 : Math.max(0, Math.min(1, Number(raw.alpha))),
        blend: String(raw.blend || ''),
        source: String(raw.source || ''),
        frameId: Number(raw.frameId) || 0,
        direction: Number(raw.direction) || 0,
        debug: raw.debug ? cloneJsonSafe(raw.debug) : null,
      };
    }).filter(Boolean);
    if (norm.length) out[String(key)] = norm;
  });
  return Object.keys(out).length ? out : null;
}

function cloneJsonSafe(value) {
  if (value == null) return value;
  try { return JSON.parse(JSON.stringify(value)); }
  catch (err) { return value; }
}


function normalizePrefab(def) {
  var hasExplicitVoxelArray = Array.isArray(def.voxels);
  var explicitVoxelCount = hasExplicitVoxelArray ? def.voxels.length : null;
  var rawVoxels = hasExplicitVoxelArray && def.voxels.length
    ? def.voxels.map(function (v) { return Object.assign({ solid: true, collidable: true, base: def.base || '#c7b0df' }, cloneVoxel(v)); })
    : makeRectVoxels(Math.max(1, def.w || 1), Math.max(1, def.d || 1), Math.max(1, def.h || 1), def.base || '#c7b0df');
  var sprite = normalizeSpriteInfo(def.sprite);
  var spriteDirections = normalizeSpriteDirections(def.spriteDirections);
  var habboLayerDirections = normalizeHabboLayerDirections(def.habboLayerDirections);
  var habboMeta = cloneJsonSafe(def.habboMeta);
  var maxX = 0, maxY = 0, maxZ = 0;
  for (var i = 0; i < rawVoxels.length; i++) {
    var v = rawVoxels[i];
    maxX = Math.max(maxX, v.x || 0);
    maxY = Math.max(maxY, v.y || 0);
    maxZ = Math.max(maxZ, v.z || 0);
  }
  return Object.assign({}, def, {
    id: def.id,
    key: def.key || '',
    name: def.name || def.id || 'Prefab',
    base: def.base || '#c7b0df',
    sprite: sprite,
    spriteDirections: spriteDirections,
    habboLayerDirections: habboLayerDirections,
    habboMeta: habboMeta,
    renderMode: String((sprite || spriteDirections || habboLayerDirections) ? (def.renderMode || 'sprite_proxy') : 'voxel'),
    slices: Array.isArray(def.slices) ? def.slices.slice() : [],
    voxels: rawVoxels,
    explicitVoxelCount: explicitVoxelCount,
    proxyFallbackUsed: !!(hasExplicitVoxelArray && explicitVoxelCount === 0),
    w: maxX + 1,
    d: maxY + 1,
    h: maxZ + 1,
  });
}

var prototypes = [
  normalizePrefab({ key: '1', id: 'cube_1x1', name: 'Cube', base: '#c7b0df', voxels: [{ x: 0, y: 0, z: 0 }] }),
  normalizePrefab({ key: '2', id: 'bench_2x1', name: 'Bench', base: '#d4bb90', voxels: [{ x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }] }),
  normalizePrefab({ key: '3', id: 'sofa_2x1', name: 'Sofa', base: '#9eb6dd', voxels: [{ x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }] }),
  normalizePrefab({ key: '4', id: 'cabinet_1x1x2', name: 'Cabinet', base: '#a8c46d', voxels: [{ x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 1 }] }),
  normalizePrefab({ key: '5', id: 'stair_3step', name: 'Stair', base: '#c99568', voxels: [
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 }, { x: 1, y: 0, z: 1 },
    { x: 2, y: 0, z: 0 }, { x: 2, y: 0, z: 1 }, { x: 2, y: 0, z: 2 }
  ] }),
  normalizePrefab({ key: '6', id: 't_shape', name: 'T Shape', base: '#7fbf9a', voxels: [
    { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }, { x: 2, y: 0, z: 0 }, { x: 1, y: 1, z: 0 }
  ] }),
  normalizePrefab({ key: '7', id: 'table_2x1', name: 'Table', base: '#cfa670', voxels: [{ x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }] })
];

function ensurePrefabRegistered(def) {
  var id = def.id;
  var found = prototypes.find(function (p) { return p.id === id; });
  if (!found) {
    found = normalizePrefab(def);
    prototypes.push(found);
  }
  return found;
}

function getPrefabById(id) {
  return prototypes.find(function (p) { return p.id === id; }) || prototypes[0];
}

function prefabVariant(prefab, rotation) {
  var r = ((rotation || 0) % 2 + 2) % 2;
  if (!prefab._variantCache) prefab._variantCache = new Map();
  if (prefab._variantCache.has(r)) return prefab._variantCache.get(r);
  var voxels;
  if (r === 0) voxels = prefab.voxels.map(function (v) { return Object.assign({}, v); });
  else voxels = prefab.voxels.map(function (v) { return Object.assign({}, v, { x: v.y, y: prefab.w - 1 - v.x }); });
  var maxX = 0, maxY = 0, maxZ = 0;
  var bottomMap = new Map();
  for (var i = 0; i < voxels.length; i++) {
    var vv = voxels[i];
    maxX = Math.max(maxX, vv.x || 0);
    maxY = Math.max(maxY, vv.y || 0);
    maxZ = Math.max(maxZ, vv.z || 0);
    var key = vv.x + ',' + vv.y;
    var prev = bottomMap.get(key);
    if (prev == null || vv.z < prev) bottomMap.set(key, vv.z);
  }
  var supportCells = Array.from(bottomMap.entries()).map(function (entry) {
    var xy = entry[0].split(',').map(Number);
    return { x: xy[0], y: xy[1], localZ: entry[1] };
  });
  var variant = Object.assign({}, prefab, { rotation: r, voxels: voxels, w: maxX + 1, d: maxY + 1, h: maxZ + 1, supportCells: supportCells });
  prefab._variantCache.set(r, variant);
  return variant;
}

function currentPrefab() {
  return prototypes[editor.prototypeIndex] || prototypes[0];
}

function allocInstanceId() {
  return 'obj_' + String(nextInstanceSerial++).padStart(4, '0');
}

function makeInstance(prefabId, x, y, z, rotation, extras) {
  extras = extras || {};
  return {
    instanceId: extras.instanceId || allocInstanceId(),
    prefabId: prefabId,
    x: x,
    y: y,
    z: z || 0,
    rotation: rotation || 0,
    name: extras.name,
  };
}

function recomputeNextInstanceSerial() {
  var maxNum = 0;
  for (var i = 0; i < instances.length; i++) {
    var m = String(instances[i].instanceId || '').match(/(\d+)$/);
    if (m) maxNum = Math.max(maxNum, Number(m[1]));
  }
  nextInstanceSerial = maxNum + 1;
}

function expandInstanceToBoxes(instance, assignIds) {
  if (assignIds === void 0) assignIds = true;
  var prefab = getPrefabById(instance.prefabId);
  var variant = prefabVariant(prefab, instance.rotation || 0);
  var out = [];
  for (var i = 0; i < variant.voxels.length; i++) {
    var v = variant.voxels[i];
    out.push({
      id: assignIds ? nextId++ : i + 1,
      instanceId: instance.instanceId,
      prefabId: prefab.id,
      name: instance.name || prefab.name,
      x: instance.x + v.x,
      y: instance.y + v.y,
      z: instance.z + v.z,
      w: 1,
      d: 1,
      h: 1,
      base: v.base || prefab.base,
      localIndex: i,
    });
  }
  return out;
}

function rebuildBoxesFromInstances() {
  nextId = 1;
  var rebuilt = [];
  for (var i = 0; i < instances.length; i++) rebuilt.push.apply(rebuilt, expandInstanceToBoxes(instances[i], true));
  boxes = rebuilt;
  return boxes;
}

function instanceFitsGrid(instance) {
  var previewBoxes = expandInstanceToBoxes(instance, false);
  return previewBoxes.every(function (b) { return b.x >= 0 && b.y >= 0 && b.x + b.w <= settings.gridW && b.y + b.d <= settings.gridH && b.z >= 0; });
}

function filterInstancesToGrid() {
  instances = instances.filter(instanceFitsGrid);
}

function findInstanceById(instanceId) {
  return instances.find(function (inst) { return inst.instanceId === instanceId; }) || null;
}

function findInstanceForBox(box) {
  return box && box.instanceId ? findInstanceById(box.instanceId) : null;
}

function removeInstanceById(instanceId) {
  instances = instances.filter(function (inst) { return inst.instanceId !== instanceId; });
  if (inspectorState.selectedInstanceId === instanceId) clearSelectedInstance();
  rebuildBoxesFromInstances();
}

function defaultInstances() {
  nextInstanceSerial = 1;
  return [
    makeInstance('bench_2x1', 1, 5, 0, 0),
    makeInstance('table_2x1', 2, 2, 0, 0, { name: 'Table' }),
    makeInstance('sofa_2x1', 4, 5, 0, 0),
    makeInstance('cabinet_1x1x2', 7, 2, 0, 0),
    makeInstance('cube_1x1', 8, 6, 0, 0),
  ];
}

function defaultBoxes() {
  var savedInstances = instances;
  var savedNextId = nextId;
  instances = defaultInstances();
  nextId = 1;
  var result = [];
  for (var i = 0; i < instances.length; i++) result.push.apply(result, expandInstanceToBoxes(instances[i], true));
  instances = savedInstances;
  nextId = savedNextId;
  return result;
}

function legacyPrefabIdForBox(box) {
  return 'legacy_' + (box.w || 1) + 'x' + (box.d || 1) + 'x' + (box.h || 1) + '_' + String(box.base || '#c7b0df').replace('#', '');
}

function ensureLegacyPrefabFromBox(box) {
  var prefabId = legacyPrefabIdForBox(box);
  ensurePrefabRegistered({
    id: prefabId,
    name: box.name || 'Legacy Box',
    base: box.base || '#c7b0df',
    voxels: makeRectVoxels(Math.max(1, box.w || 1), Math.max(1, box.d || 1), Math.max(1, box.h || 1), box.base || '#c7b0df')
  });
  return prefabId;
}

function legacyBoxesToInstances(boxList) {
  var out = [];
  for (var i = 0; i < (boxList || []).length; i++) {
    var box = boxList[i];
    var prefabId = ensureLegacyPrefabFromBox(box);
    out.push(makeInstance(prefabId, Number(box.x) || 0, Number(box.y) || 0, Number(box.z) || 0, 0, { name: box.name || 'Legacy Box' }));
  }
  return out;
}

var instances = defaultInstances();
var nextId = 1;
var boxes = [];
rebuildBoxesFromInstances();
pushLog(`初始化：instances=${instances.length} boxes=${boxes.length}`);
pushLog(`初始化 instances: ${instances.map(function (inst) { return inst.instanceId + ':' + getPrefabById(inst.prefabId).name + '@(' + inst.x + ',' + inst.y + ',' + inst.z + ')'; }).join(' | ')}`);
pushLog(`初始化 boxes: ${boxes.map(function (b) { return describeBox(b); }).join(' | ')}`);
pushLog(`默认人物占高=${settings.playerHeightCells}格`);
pushLog(`lab-mode=${LAB_MODE} showPlayer=${SHOW_PLAYER} focus=merged-room-lighting-player-proxy`);
pushLog(`log-system-ready=${logSystemReady} bufferedBootLines=${bootBuffer.length}`);

function prefabToSerializable(prefab) {
  return {
    id: prefab.id,
    key: prefab.key || '',
    name: prefab.name || prefab.id,
    kind: prefab.kind || prefab.id,
    asset: prefab.asset || '',
    base: prefab.base || '#c7b0df',
    renderMode: prefab.renderMode || 'voxel',
    anchor: prefab.anchor ? { x: Number(prefab.anchor.x) || 0, y: Number(prefab.anchor.y) || 0, z: Number(prefab.anchor.z) || 0 } : { x: 0, y: 0, z: 0 },
    sprite: prefab.sprite ? {
      image: prefab.sprite.image || '',
      fileName: prefab.sprite.fileName || '',
      scale: Number(prefab.sprite.scale) || 1,
      offsetPx: { x: Number(prefab.sprite.offsetPx && prefab.sprite.offsetPx.x) || 0, y: Number(prefab.sprite.offsetPx && prefab.sprite.offsetPx.y) || 0 },
      anchorMode: prefab.sprite.anchorMode || 'bottom-center',
      sortMode: prefab.sprite.sortMode || 'box_occlusion',
    } : null,
    spriteDirections: prefab.spriteDirections ? Object.keys(prefab.spriteDirections).reduce(function (acc, key) {
      var cfg = prefab.spriteDirections[key];
      acc[key] = {
        image: cfg.image || '',
        fileName: cfg.fileName || '',
        scale: Number(cfg.scale) || 1,
        offsetPx: { x: Number(cfg.offsetPx && cfg.offsetPx.x) || 0, y: Number(cfg.offsetPx && cfg.offsetPx.y) || 0 },
        anchorMode: cfg.anchorMode || 'bottom-center',
        sortMode: cfg.sortMode || 'box_occlusion',
        flipX: !!cfg.flipX,
      };
      return acc;
    }, {}) : null,
    habboLayerDirections: prefab.habboLayerDirections ? Object.keys(prefab.habboLayerDirections).reduce(function (acc, key) {
      acc[key] = (prefab.habboLayerDirections[key] || []).map(function (layer) {
        return {
          image: layer.image || '',
          fileName: layer.fileName || '',
          width: Number(layer.width) || 1,
          height: Number(layer.height) || 1,
          visualSize: Number(layer.visualSize) || 64,
          offsetPx: { x: Number(layer.offsetPx && layer.offsetPx.x) || 0, y: Number(layer.offsetPx && layer.offsetPx.y) || 0 },
          offsetZ: Number(layer.offsetZ) || 0,
          flipX: !!layer.flipX,
          kind: layer.kind || 'body',
          layerId: layer.layerId || '',
          layerIndex: Number(layer.layerIndex) || 0,
          name: layer.name || '',
          zOrderHint: Number(layer.zOrderHint) || 0,
          alpha: layer.alpha == null ? 1 : Math.max(0, Math.min(1, Number(layer.alpha))),
          blend: layer.blend || '',
          source: layer.source || '',
          frameId: Number(layer.frameId) || 0,
          direction: Number(layer.direction) || 0,
        };
      });
      return acc;
    }, {}) : null,
    habboMeta: prefab.habboMeta ? cloneJsonSafe(prefab.habboMeta) : null,
    slices: Array.isArray(prefab.slices) ? prefab.slices.slice() : [],
    voxels: (prefab.voxels || []).map(function (v) {
      return {
        x: Number(v.x) || 0,
        y: Number(v.y) || 0,
        z: Number(v.z) || 0,
        solid: v.solid !== false,
        collidable: v.collidable !== false,
        base: v.base || prefab.base || '#c7b0df',
      };
    }),
    custom: !!prefab.custom,
  };
}

function listCustomPrefabs() {
  return prototypes.filter(function (p) { return !!p.custom && !p.assetManaged; }).map(prefabToSerializable);
}

function saveCustomPrefabsToLocalStorage() {
  if (!sceneStorageAvailable()) return false;
  try {
    window.localStorage.setItem(LOCAL_PREFAB_STORAGE_KEY, JSON.stringify(listCustomPrefabs()));
    detailLog('prefab-storage: saved custom prefabs');
    return true;
  } catch (err) {
    pushLog(`prefab-storage:error ${err?.message || err}`);
    return false;
  }
}

function importPrefabDefinition(def, options) {
  options = options || {};
  if (!def || typeof def !== 'object') {
    pushLog('prefab-import: invalid object');
    return null;
  }
  var rawId = String(def.id || '').trim();
  if (!rawId) {
    pushLog('prefab-import: missing id');
    return null;
  }
  var existing = prototypes.find(function (p) { return p.id === rawId; });
  if (existing && !existing.custom && !options.replaceBuiltIn) {
    pushLog(`prefab-import: rejected built-in id=${rawId}`);
    return null;
  }
  var normalized = normalizePrefab(Object.assign({}, def, { id: rawId, key: def.key || '', custom: true }));
  var isAssetManaged = options.sourceKind === 'asset';
  var isExternalManaged = options.sourceKind === 'habbo-root';
  normalized.custom = !(isAssetManaged || isExternalManaged);
  normalized.assetManaged = isAssetManaged;
  normalized.externalManaged = isExternalManaged;
  normalized.missingPrefab = false;
  if (existing && (existing.custom || existing.assetManaged || existing.externalManaged || existing.missingPrefab)) {
    var idx = prototypes.findIndex(function (p) { return p.id === rawId; });
    if (idx >= 0) prototypes[idx] = normalized;
  } else {
    prototypes.push(normalized);
  }
  var importedIndex = prototypes.findIndex(function (p) { return p.id === rawId; });
  if (options.select !== false) editor.prototypeIndex = importedIndex;
  refreshPrefabSelectOptions();
  if (ui.prefabSelect && options.select !== false) ui.prefabSelect.value = String(editor.prototypeIndex);
  if (options.persist !== false) saveCustomPrefabsToLocalStorage();
  if (normalized.assetManaged) { var __st = ensureAssetPrefabScanState(); __st.ids.add(normalized.id); assetManagedPrefabIds = __st.ids; }
  pushLog(`prefab-import: id=${normalized.id} voxels=${normalized.voxels.length} explicit=${normalized.explicitVoxelCount == null ? 'n/a' : normalized.explicitVoxelCount} fallback=${normalized.proxyFallbackUsed ? 1 : 0} source=${options.source || 'unknown'}`);
  if (isLegacyFlatHabboPrefab(normalized)) {
    pushLog('habbo-repair:queued prefab=' + normalized.id + ' source=' + String(options.source || 'unknown') + ' reason=legacy-flat-prefab');
    queueLegacyHabboPrefabRepair(normalized.id, 'import:' + String(options.source || 'unknown'));
  }
  return normalized;
}


function bytesToLatin1Text(bytes) {
  return new TextDecoder('latin1').decode(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes));
}

async function inflateZlibBytes(input) {
  var bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  if (typeof DecompressionStream !== 'function') throw new Error('当前浏览器不支持 DecompressionStream，无法解压 SWF / bitmap 数据');
  var ds = new DecompressionStream('deflate');
  var decompressed = await new Response(new Blob([bytes]).stream().pipeThrough(ds)).arrayBuffer();
  return new Uint8Array(decompressed);
}

async function inflateSwfBytes(arrayBuffer) {
  var bytes = arrayBuffer instanceof Uint8Array ? arrayBuffer : new Uint8Array(arrayBuffer);
  if (bytes.length < 8) throw new Error('SWF 文件过小');
  var sig = String.fromCharCode(bytes[0], bytes[1], bytes[2]);
  if (sig === 'FWS') return bytes;
  if (sig !== 'CWS') throw new Error('当前只支持 FWS/CWS 的 SWF');
  var header = bytes.slice(0, 8);
  var body = bytes.slice(8);
  var decompressed = await inflateZlibBytes(body);
  var out = new Uint8Array(8 + decompressed.byteLength);
  out.set(header, 0);
  out.set(decompressed, 8);
  out[0] = 70; out[1] = 87; out[2] = 83;
  return out;
}

function parseXmlAttributes(fragment) {
  var attrs = {};
  String(fragment || '').replace(/(\w+)="([^"]*)"/g, function (_, key, value) {
    attrs[key] = value;
    return _;
  });
  return attrs;
}

function extractHabboXmlFragment(text, tagName) {
  var re = new RegExp('<' + tagName + '\\b[\\s\\S]*?<\\/' + tagName + '>', 'i');
  var m = String(text || '').match(re);
  return m ? m[0] : '';
}

function readSwfBits(bytes, bitIndex, count) {
  var value = 0;
  for (var i = 0; i < count; i++) {
    var byteIndex = bitIndex >> 3;
    var bitOffset = 7 - (bitIndex & 7);
    value = (value << 1) | ((bytes[byteIndex] >> bitOffset) & 1);
    bitIndex += 1;
  }
  return { value: value, bitIndex: bitIndex };
}

function readSwfSignedBits(bytes, bitIndex, count) {
  var out = readSwfBits(bytes, bitIndex, count);
  var value = out.value;
  if (count > 0 && (value & (1 << (count - 1)))) value -= (1 << count);
  return { value: value, bitIndex: out.bitIndex };
}

function getSwfTagStreamOffset(bytes) {
  var bitIndex = 8 * 8;
  var head = readSwfBits(bytes, bitIndex, 5);
  var nbits = head.value;
  bitIndex = head.bitIndex;
  for (var i = 0; i < 4; i++) {
    var signed = readSwfSignedBits(bytes, bitIndex, nbits);
    bitIndex = signed.bitIndex;
  }
  return Math.ceil(bitIndex / 8) + 4;
}

function parseSwfTags(bytes) {
  var out = [];
  var pos = getSwfTagStreamOffset(bytes);
  habboTrace('parseSwfTags:start bytes=' + bytes.length + ' tagStreamOffset=' + pos);
  while (pos + 2 <= bytes.length) {
    var header = bytes[pos] | (bytes[pos + 1] << 8);
    pos += 2;
    var code = header >> 6;
    var length = header & 0x3f;
    if (length === 0x3f) {
      if (pos + 4 > bytes.length) break;
      length = (bytes[pos]) | (bytes[pos + 1] << 8) | (bytes[pos + 2] << 16) | (bytes[pos + 3] << 24);
      pos += 4;
    }
    var body = bytes.slice(pos, pos + length);
    pos += length;
    out.push({ code: code, length: length, body: body });
    if (code === 0) break;
  }
  habboTrace('parseSwfTags:done tags=' + out.length + ' codes=' + out.slice(0, 24).map(function (t) { return t.code + ':' + t.length; }).join(','));
  return out;
}

function parseSwfSymbolClassMap(tags) {
  var map = {};
  for (var i = 0; i < tags.length; i++) {
    var tag = tags[i];
    if (!tag || tag.code !== 76) continue;
    var body = tag.body;
    var pos = 0;
    if (body.length < 2) continue;
    var count = body[pos] | (body[pos + 1] << 8);
    pos += 2;
    for (var j = 0; j < count; j++) {
      if (pos + 2 > body.length) break;
      var characterId = body[pos] | (body[pos + 1] << 8);
      pos += 2;
      var start = pos;
      while (pos < body.length && body[pos] !== 0) pos += 1;
      var name = bytesToLatin1Text(body.slice(start, pos));
      pos += 1;
      map[characterId] = name;
    }
  }
  habboTrace('symbolClassMap:count=' + Object.keys(map).length + ' sample=' + Object.keys(map).slice(0, 16).map(function (k) { return k + '=>' + map[k]; }).join(' | '));
  return map;
}

function getHabboAssetNameFromSymbolClass(className, type) {
  var raw = String(className || '');
  var prefix = String(type || '');
  if (prefix && raw.indexOf(prefix + '_') === 0) return raw.slice(prefix.length + 1);
  return raw;
}

function collectHabboXmlTextsFromTags(tags) {
  var out = {
    objectDataXml: '',
    assetsXml: '',
    visualizationXml: '',
    objectXml: '',
    manifestXml: '',
  };
  function normalizeXmlText(raw) {
    var s = String(raw || '');
    s = s.replace(/^\uFEFF?\s*/, '');
    s = s.replace(/^<\?xml[^>]*>\s*/i, '');
    return s.trim();
  }
  function startsWithRoot(s, rootTag) {
    return new RegExp('^\\s*<' + rootTag + '(?:\\s|>)', 'i').test(String(s || ''));
  }
  for (var i = 0; i < tags.length; i++) {
    var tag = tags[i];
    if (!tag || tag.code !== 87 || !tag.body || tag.body.length < 6) continue;
    var payload = tag.body.slice(6);
    var normalized = normalizeXmlText(bytesToLatin1Text(payload));
    if (!normalized || normalized.charAt(0) !== '<') continue;

    if (!out.objectDataXml && startsWithRoot(normalized, 'objectData')) { out.objectDataXml = normalized; continue; }
    if (!out.visualizationXml && startsWithRoot(normalized, 'visualizationData')) { out.visualizationXml = normalized; continue; }
    if (!out.objectXml && startsWithRoot(normalized, 'object')) { out.objectXml = normalized; continue; }
    if (!out.manifestXml && startsWithRoot(normalized, 'manifest')) { out.manifestXml = normalized; continue; }
    if (!out.assetsXml && startsWithRoot(normalized, 'assets')) { out.assetsXml = normalized; continue; }

    if (!out.objectDataXml) {
      var od = extractHabboXmlFragment(normalized, 'objectData');
      if (od) out.objectDataXml = od;
    }
    if (!out.visualizationXml) {
      var vz = extractHabboXmlFragment(normalized, 'visualizationData');
      if (vz) out.visualizationXml = vz;
    }
    if (!out.objectXml) {
      var ox = normalized.match(/<object\b[^>]*\/?>/i);
      if (ox) out.objectXml = ox[0];
    }
    if (!out.manifestXml) {
      var mf = extractHabboXmlFragment(normalized, 'manifest');
      if (mf) out.manifestXml = mf;
    }
  }
  habboTrace('xml-blocks objectData=' + (!!out.objectDataXml) + ' visualization=' + (!!out.visualizationXml) + ' object=' + (!!out.objectXml) + ' assets=' + (!!out.assetsXml) + ' manifest=' + (!!out.manifestXml));
  return out;
}

function parseHabboAssetDescriptor(name) {
  var raw = String(name || '');
  var info = {
    size: 0,
    direction: 0,
    frame: 0,
    layerId: '',
    kind: 'body'
  };
  var iconMatch = raw.match(/_icon(?:_([a-z0-9]+))?$/i);
  if (iconMatch) {
    info.layerId = 'icon';
    info.kind = 'icon';
    return info;
  }
  var m = raw.match(/_(\d+)_([a-z]+)_(\d+)_(\d+)$/i);
  if (m) {
    info.size = Number(m[1]) || 0;
    info.layerId = String(m[2] || '').toLowerCase();
    info.direction = Number(m[3]) || 0;
    info.frame = Number(m[4]) || 0;
    if (info.layerId === 'sd') info.kind = 'shadow';
    else info.kind = 'body';
    return info;
  }
  if (/_sd_/i.test(raw)) info.kind = 'shadow';
  return info;
}

function parseHabboVisualizationGraphics(xmlText) {
  var out = { sizes: {}, raw: String(xmlText || '') };
  var text = String(xmlText || '');
  if (!text) return out;
  var visRe = /<visualization\b([^>]*)>([\s\S]*?)<\/visualization>/ig;
  var visMatch;
  while ((visMatch = visRe.exec(text))) {
    var visAttrs = parseXmlAttributes(visMatch[1]);
    var size = Math.max(0, Number(visAttrs.size) || 0);
    var body = visMatch[2] || '';
    var vis = {
      size: size,
      layerCount: Math.max(0, Number(visAttrs.layerCount) || 0),
      angle: Number(visAttrs.angle) || 0,
      layers: {},
      directions: [],
      animations: {},
    };
    var layerRe = /<layer\b([^>]*)\/?>(?:<\/layer>)?/ig;
    var m;
    while ((m = layerRe.exec(body))) {
      var a = parseXmlAttributes(m[1]);
      var id = Number(a.id);
      if (!Number.isFinite(id)) continue;
      vis.layers[id] = {
        id: id,
        x: Number(a.x) || 0,
        y: Number(a.y) || 0,
        z: Number(a.z) || 0,
        alpha: a.alpha != null ? Number(a.alpha) : null,
        ink: a.ink || '',
        tag: a.tag || '',
        interactive: a.interactive === '1' || a.interactive === 'true',
      };
    }
    var dirRe = /<direction\b([^>]*)\/>/ig;
    while ((m = dirRe.exec(body))) {
      var da = parseXmlAttributes(m[1]);
      if (da.id != null) vis.directions.push(Number(da.id));
    }
    vis.directions = vis.directions.filter(function (v, i, arr) { return arr.indexOf(v) === i; }).sort(function (a, b) { return a - b; });
    var animRe = /<animation\b([^>]*)>([\s\S]*?)<\/animation>/ig;
    var animMatch;
    while ((animMatch = animRe.exec(body))) {
      var aa = parseXmlAttributes(animMatch[1]);
      var stateId = aa.id != null ? Number(aa.id) : (aa.state != null ? Number(aa.state) : 0);
      var animBody = animMatch[2] || '';
      var anim = { id: stateId, layers: {} };
      var alRe = /<animationLayer\b([^>]*)>([\s\S]*?)<\/animationLayer>/ig;
      var alMatch;
      while ((alMatch = alRe.exec(animBody))) {
        var ala = parseXmlAttributes(alMatch[1]);
        var layerId = Number(ala.id);
        if (!Number.isFinite(layerId)) continue;
        var frames = [];
        var fsRe = /<frame\b([^>]*)\/>/ig;
        var fMatch;
        while ((fMatch = fsRe.exec(alMatch[2] || ''))) {
          var fa = parseXmlAttributes(fMatch[1]);
          if (fa.id != null) frames.push(Number(fa.id));
        }
        anim.layers[layerId] = {
          id: layerId,
          frames: frames,
          frameRepeat: ala.frameRepeat != null ? Number(ala.frameRepeat) : 0,
          loopCount: ala.loopCount != null ? Number(ala.loopCount) : 0,
        };
      }
      vis.animations[String(stateId)] = anim;
    }
    out.sizes[String(size)] = vis;
  }
  return out;
}

function chooseHabboVisualization(meta, preferredSize) {
  var sizes = meta && meta.visualizationInfo && meta.visualizationInfo.sizes ? meta.visualizationInfo.sizes : null;
  if (!sizes) return null;
  var requested = String(Math.max(0, Number(preferredSize) || 0));
  if (sizes[requested]) return sizes[requested];
  var keys = Object.keys(sizes).map(function (k) { return Number(k); }).filter(function (n) { return Number.isFinite(n); }).sort(function (a, b) { return b - a; });
  if (!keys.length) return null;
  return sizes[String(keys[0])] || null;
}

function getHabboVisualizationState(meta) {
  return 0;
}

function getHabboLayerLetter(layerId, layerCount) {
  return layerId === layerCount ? 'sd' : String.fromCharCode(97 + layerId);
}

function getHabboAnimationFrameForLayer(vis, layerId, stateId) {
  var anims = vis && vis.animations ? vis.animations : null;
  if (!anims) return 0;
  var anim = anims[String(stateId)] || anims['0'] || null;
  if (!anim || !anim.layers) return 0;
  var layer = anim.layers[layerId];
  if (!layer || !layer.frames || !layer.frames.length) return 0;
  return Number(layer.frames[0]) || 0;
}

function chooseHabboAssetForLayer(meta, letter, direction, frame, preferredSize) {
  var all = (meta && meta.assets ? meta.assets : []).filter(function (asset) {
    return asset && String(asset.layerId || '') === String(letter || '');
  });
  if (!all.length) return null;
  function best(candidates) {
    if (!candidates.length) return null;
    candidates = candidates.slice().sort(function (a, b) {
      function score(asset) {
        var s = 0;
        if (Number(asset.direction || 0) === Number(direction || 0)) s += 100;
        else if (Number(asset.direction || 0) === 0) s += 50;
        if (Number(asset.frame || 0) === Number(frame || 0)) s += 20;
        else if (Number(asset.frame || 0) === 0) s += 10;
        if (Number(asset.size || 0) === Number(preferredSize || 0)) s += 5;
        if (asset.source) s += 1;
        return s;
      }
      var ds = score(b) - score(a);
      if (ds) return ds;
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
    return candidates[0] || null;
  }
  var bySize = preferredSize > 0 ? all.filter(function (a) { return Number(a.size || 0) === Number(preferredSize || 0); }) : all.slice();
  return best(bySize) || best(all);
}

function parseHabboSwfMetadataFromXmls(xmls) {
  var text = [xmls && xmls.assetsXml || '', xmls && xmls.objectDataXml || '', xmls && xmls.visualizationXml || '', xmls && xmls.objectXml || ''].join('\n');
  var out = {
    type: '',
    dimensions: { x: 1, y: 1, z: 1 },
    logicDirections: [],
    visualDirections: [],
    visualization: '',
    logic: '',
    assets: [],
    visualizationInfo: null,
    raw: {
      objectDataXml: xmls && xmls.objectDataXml || '',
      assetsXml: xmls && xmls.assetsXml || '',
      visualizationXml: xmls && xmls.visualizationXml || '',
      objectXml: xmls && xmls.objectXml || '',
      manifestXml: xmls && xmls.manifestXml || '',
      fullText: text,
    },
  };
  var objectDataXml = xmls && xmls.objectDataXml || '';
  var objectXml = xmls && xmls.objectXml || '';
  var assetsXml = xmls && xmls.assetsXml || '';
  var visualizationXml = xmls && xmls.visualizationXml || '';

  var objectXmlMatch = objectXml ? objectXml.match(/<object\b([^>]*)\/?>/i) : null;
  if (objectXmlMatch) {
    var objectAttrs = parseXmlAttributes(objectXmlMatch[1]);
    out.type = objectAttrs.type || out.type;
    out.visualization = objectAttrs.visualization || '';
    out.logic = objectAttrs.logic || '';
  }
  if (objectDataXml) {
    var headerMatch = objectDataXml.match(/<objectData\b([^>]*)>/i);
    if (headerMatch) {
      var dataAttrs = parseXmlAttributes(headerMatch[1]);
      out.type = dataAttrs.type || out.type;
    }
    var dimMatch = objectDataXml.match(/<dimensions\b([^>]*)\/>/i);
    if (dimMatch) {
      var dimAttrs = parseXmlAttributes(dimMatch[1]);
      out.dimensions = {
        x: Math.max(1, Number(dimAttrs.x) || 1),
        y: Math.max(1, Number(dimAttrs.y) || 1),
        z: Math.max(1, Number(dimAttrs.z) || 1),
      };
    }
    var dirMatch;
    var dirRe = /<direction\b([^>]*)\/>/ig;
    while ((dirMatch = dirRe.exec(objectDataXml))) {
      var dirAttrs = parseXmlAttributes(dirMatch[1]);
      if (dirAttrs.id != null) out.logicDirections.push(Number(dirAttrs.id));
    }
  }
  if (visualizationXml) {
    var visHeader = visualizationXml.match(/<visualizationData\b([^>]*)>/i);
    if (visHeader) {
      var visAttrs = parseXmlAttributes(visHeader[1]);
      if (!out.type) out.type = visAttrs.type || out.type;
    }
    out.visualizationInfo = parseHabboVisualizationGraphics(visualizationXml);
    try {
      var __visKeys = out.visualizationInfo && out.visualizationInfo.sizes ? Object.keys(out.visualizationInfo.sizes) : [];
      pushHabboDebug('visualization:parsed', { type: out.type || '', sizes: __visKeys, rawLength: visualizationXml.length || 0 });
      habboTrace('visualization:parsed type=' + String(out.type || '') + ' sizes=' + __visKeys.join(','));
    } catch (__visErr) {
      detailLog('visualization:parsed:error ' + (__visErr && __visErr.message ? __visErr.message : __visErr));
    }
  }
  if (assetsXml) {
    var assetMatch;
    var assetRe = /<asset\b([^>]*)\/>/ig;
    while ((assetMatch = assetRe.exec(assetsXml))) {
      var attrs = parseXmlAttributes(assetMatch[1]);
      if (!attrs.name) continue;
      var parsed = parseHabboAssetDescriptor(attrs.name);
      if (out.visualDirections.indexOf(parsed.direction) < 0) out.visualDirections.push(parsed.direction);
      out.assets.push({
        name: attrs.name,
        kind: parsed.kind,
        layerId: parsed.layerId,
        source: attrs.source || '',
        flipH: attrs.flipH === '1',
        direction: parsed.direction,
        frame: parsed.frame,
        size: parsed.size,
        x: Number(attrs.x) || 0,
        y: Number(attrs.y) || 0,
      });
    }
  }
  out.logicDirections = out.logicDirections.filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }).sort(function (a, b) { return a - b; });
  out.visualDirections = out.visualDirections.filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }).sort(function (a, b) { return a - b; });
  if (!out.type) {
    var full = text;
    var mType = full.match(/<objectData\b[^>]*\btype="([^"]+)"/i) || full.match(/<object\b[^>]*\btype="([^"]+)"/i);
    if (mType) out.type = mType[1];
  }
  if (!out.type) throw new Error('SWF 中未找到 objectData.type');
  if (!out.assets.length && assetsXml) {
    var fallbackAssetRe = /<asset\b([^>]*)\/?\>/ig;
    var fallbackMatch;
    while ((fallbackMatch = fallbackAssetRe.exec(assetsXml))) {
      var attrs = parseXmlAttributes(fallbackMatch[1]);
      if (!attrs.name) continue;
      var parsed2 = parseHabboAssetDescriptor(attrs.name);
      if (out.visualDirections.indexOf(parsed2.direction) < 0) out.visualDirections.push(parsed2.direction);
      out.assets.push({
        name: attrs.name,
        kind: parsed2.kind,
        layerId: parsed2.layerId,
        source: attrs.source || '',
        flipH: attrs.flipH === '1',
        direction: parsed2.direction,
        frame: parsed2.frame,
        size: parsed2.size,
        x: Number(attrs.x) || 0,
        y: Number(attrs.y) || 0,
      });
    }
  }
  if (!out.assets.length) throw new Error('SWF 中未找到 assets 图层定义');
  habboTrace('metadata type=' + out.type + ' dims=' + [out.dimensions.x, out.dimensions.y, out.dimensions.z].join('x') + ' logicDirs=' + out.logicDirections.join(',') + ' visualDirs=' + out.visualDirections.join(',') + ' assets=' + out.assets.length + ' assetSample=' + out.assets.slice(0, 12).map(function(a){ return a.name + '@(' + a.x + ',' + a.y + '):dir' + a.direction + ':size' + a.size + (a.flipH ? ':flip' : ''); }).join(' | '));
  return out;
}

function makeCanvas2D(width, height) {
  var canvas = document.createElement('canvas');
  canvas.width = Math.max(1, width | 0);
  canvas.height = Math.max(1, height | 0);
  return canvas;
}

async function decodeSwfLosslessBitmapTag(tagBody) {
  if (!tagBody || tagBody.length < 7) throw new Error('Lossless bitmap tag 数据过短');
  var characterId = tagBody[0] | (tagBody[1] << 8);
  var bitmapFormat = tagBody[2];
  var width = tagBody[3] | (tagBody[4] << 8);
  var height = tagBody[5] | (tagBody[6] << 8);
  var pos = 7;
  if (bitmapFormat === 3) {
    throw new Error('当前版本暂不支持 indexed color 的 bitmapFormat=3');
  }
  if (bitmapFormat !== 5) {
    throw new Error('当前版本只支持 Habbo 常见的 DefineBitsLossless2 format=5');
  }
  var inflated = await inflateZlibBytes(tagBody.slice(pos));
  var raw = inflated instanceof Uint8Array ? inflated : new Uint8Array(inflated);
  var canvas = makeCanvas2D(width, height);
  var ctx2d = canvas.getContext('2d');
  var imageData = ctx2d.createImageData(width, height);
  var dst = imageData.data;
  for (var src = 0, di = 0; src + 3 < raw.length && di + 3 < dst.length; src += 4, di += 4) {
    var a = raw[src];
    var r = raw[src + 1];
    var g = raw[src + 2];
    var b = raw[src + 3];
    dst[di] = r;
    dst[di + 1] = g;
    dst[di + 2] = b;
    dst[di + 3] = a;
  }
  ctx2d.putImageData(imageData, 0, 0);
  return {
    characterId: characterId,
    width: width,
    height: height,
    canvas: canvas,
    dataUrl: canvas.toDataURL('image/png')
  };
}

function chooseHabboPreferredVisualSize(meta) {
  var sizes = [];
  (meta.assets || []).forEach(function (asset) {
    if (!asset || asset.kind === 'icon') return;
    if (asset.size > 0 && sizes.indexOf(asset.size) < 0) sizes.push(asset.size);
  });
  if (sizes.indexOf(64) >= 0) return 64;
  if (!sizes.length) return 0;
  sizes.sort(function (a, b) { return b - a; });
  return sizes[0];
}

async function extractHabboBitmapAssetsFromTags(tags, symbolMap, type) {
  var out = {};
  for (var i = 0; i < tags.length; i++) {
    var tag = tags[i];
    if (!tag || tag.code !== 36) continue;
    var characterId = tag.body[0] | (tag.body[1] << 8);
    var className = symbolMap[characterId] || '';
    var assetName = getHabboAssetNameFromSymbolClass(className, type);
    var decoded = await decodeSwfLosslessBitmapTag(tag.body);
    habboTrace('bitmap characterId=' + characterId + ' class=' + className + ' asset=' + assetName + ' ' + decoded.width + 'x' + decoded.height);
    out[assetName] = {
      name: assetName,
      characterId: characterId,
      className: className,
      width: decoded.width,
      height: decoded.height,
      canvas: decoded.canvas,
      dataUrl: decoded.dataUrl
    };
  }
  habboTrace('bitmap-extract:count=' + Object.keys(out).length + ' sample=' + Object.keys(out).slice(0, 20).join(','));
  return out;
}

function resolveHabboLayerImage(bitmaps, asset) {
  if (!asset) return null;
  var sourceName = asset.source || asset.name;
  return bitmaps[sourceName] || bitmaps[asset.name] || null;
}

function pickHabboDirectionLayers(meta, bitmaps, direction, options) {
  options = options || {};
  var includeShadow = !!options.includeShadow;
  var preferredSize = options.preferredSize == null ? chooseHabboPreferredVisualSize(meta) : options.preferredSize;
  var targetDir = Number(direction) || 0;
  var skipReasons = [];
  var all = (meta.assets || []).filter(function (asset) {
    if (!asset) { skipReasons.push({ reason: 'null-asset' }); return false; }
    if (asset.kind === 'icon') { skipReasons.push({ name: asset.name, reason: 'icon' }); return false; }
    if (!includeShadow && asset.kind === 'shadow') { skipReasons.push({ name: asset.name, reason: 'shadow-excluded' }); return false; }
    var img = resolveHabboLayerImage(bitmaps, asset);
    if (!img) { skipReasons.push({ name: asset.name, reason: 'missing-bitmap', source: asset.source || '' }); return false; }
    return true;
  });
  pushHabboDebug('pickLayers:input', { type: meta.type || '', targetDir: targetDir, includeShadow: includeShadow, preferredSize: preferredSize, assetCount: (meta.assets || []).length, candidateCount: all.length, skipped: skipReasons.slice(0, 80) });
  var tryDirections = [targetDir];
  if (targetDir !== 0) tryDirections.push(0);
  for (var d = 0; d < tryDirections.length; d++) {
    var dir = tryDirections[d];
    var dirAssets = all.filter(function (asset) { return Number(asset.direction || 0) === dir; });
    if (!dirAssets.length) {
      pushHabboDebug('pickLayers:dir-empty', { type: meta.type || '', dir: dir, targetDir: targetDir });
      continue;
    }
    var sizeAssets = preferredSize > 0 ? dirAssets.filter(function (asset) { return Number(asset.size || 0) === preferredSize; }) : dirAssets.slice();
    if (!sizeAssets.length) {
      var largest = 0;
      dirAssets.forEach(function (asset) { largest = Math.max(largest, Number(asset.size || 0)); });
      sizeAssets = dirAssets.filter(function (asset) { return Number(asset.size || 0) === largest; });
      pushHabboDebug('pickLayers:fallback-size', { type: meta.type || '', dir: dir, requestedSize: preferredSize, fallbackSize: largest, dirAssets: dirAssets.map(function(a){ return { name:a.name, kind:a.kind, size:a.size, layerId:a.layerId }; }) });
    }
    var bodyAssets = sizeAssets.filter(function (asset) { return asset.kind === 'body'; });
    var layers = bodyAssets.length ? bodyAssets : sizeAssets.slice();
    if (!layers.length) continue;
    layers.sort(function (a, b) {
      var ak = a.kind === 'shadow' ? 0 : 1;
      var bk = b.kind === 'shadow' ? 0 : 1;
      if (ak !== bk) return ak - bk;
      if (a.layerId !== b.layerId) return String(a.layerId).localeCompare(String(b.layerId));
      return String(a.name).localeCompare(String(b.name));
    });
    pushHabboDebug('pickLayers:result', { type: meta.type || '', dir: dir, targetDir: targetDir, includeShadow: includeShadow, preferredSize: preferredSize, layers: layers.map(function (a) { return { name:a.name, kind:a.kind, size:a.size, x:a.x, y:a.y, layerId:a.layerId, source:a.source || '', flipH:!!a.flipH }; }) });
    habboTrace('pickLayers dir=' + dir + ' target=' + targetDir + ' includeShadow=' + includeShadow + ' preferredSize=' + preferredSize + ' picked=' + layers.map(function (a) { return a.name + ':' + a.kind + '@(' + a.x + ',' + a.y + ')' + (a.flipH ? ':flip' : '') + ':src=' + (a.source || a.name); }).join(' | '));
    return layers;
  }
  pushHabboDebug('pickLayers:none', { type: meta.type || '', targetDir: targetDir, includeShadow: includeShadow, preferredSize: preferredSize });
  habboTrace('pickLayers dir=' + targetDir + ' includeShadow=' + includeShadow + ' preferredSize=' + preferredSize + ' picked=NONE');
  return [];
}

function composeHabboDirectionSprite(meta, bitmaps, direction, options) {
  options = options || {};
  var layers = pickHabboDirectionLayers(meta, bitmaps, direction, options);
  if (!layers.length) return null;
  // 这里严肃参考 Scuti 的“room object container + texture trim”语义：
  // Scuti 运行时真正用到的是 extractor 产出的 frame trim + visualization layer offsets，
  // 而不是直接把 SWF assets.xml 里的 x/y 当成 top-left 来加到 container 上。
  // 对于我们当前“直接吃 SWF”的方案，必须先把 assets.xml 里的注册点 x/y 还原成
  // “图片左上角相对 room object origin 的偏移”。
  // Habbo 常见 floor furni 中，asset.x / asset.y 更接近 registration point（对象原点落在图片内部的像素坐标），
  // 所以 top-left 应该是 (-asset.x, -asset.y)，而不是 (+asset.x, +asset.y)。
  var placements = [];
  var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (var i = 0; i < layers.length; i++) {
    var asset = layers[i];
    var image = resolveHabboLayerImage(bitmaps, asset);
    if (!image) continue;
    var regX = Number(asset.x || 0);
    var regY = Number(asset.y || 0);
    var topLeftX = asset.flipH ? (regX - Number(image.width || 0)) : -regX;
    var topLeftY = -regY;
    placements.push({
      asset: asset,
      image: image,
      regX: regX,
      regY: regY,
      topLeftX: topLeftX,
      topLeftY: topLeftY,
    });
    minX = Math.min(minX, topLeftX);
    minY = Math.min(minY, topLeftY);
    maxX = Math.max(maxX, topLeftX + Number(image.width || 0));
    maxY = Math.max(maxY, topLeftY + Number(image.height || 0));
  }
  if (!placements.length || !Number.isFinite(minX) || !Number.isFinite(minY) || !Number.isFinite(maxX) || !Number.isFinite(maxY)) return null;
  var width = Math.max(1, Math.round(maxX - minX));
  var height = Math.max(1, Math.round(maxY - minY));
  var canvas = makeCanvas2D(width, height);
  var ctx2d = canvas.getContext('2d');
  for (var j = 0; j < placements.length; j++) {
    var placed = placements[j];
    var layer = placed.asset;
    var bitmap = placed.image;
    if (!bitmap || !bitmap.canvas) continue;
    var dx = Math.round(placed.topLeftX - minX);
    var dy = Math.round(placed.topLeftY - minY);
    ctx2d.save();
    if (layer.flipH) {
      ctx2d.translate(dx + bitmap.width, dy);
      ctx2d.scale(-1, 1);
      ctx2d.drawImage(bitmap.canvas, 0, 0);
    } else {
      ctx2d.drawImage(bitmap.canvas, dx, dy);
    }
    ctx2d.restore();
  }
  detailLog('habbo-compose: type=' + String(meta.type || 'habbo') + ' dir=' + String(direction) +
    ' bbox=(' + [Math.round(minX), Math.round(minY), Math.round(maxX), Math.round(maxY)].join(',') + ')' +
    ' size=' + width + 'x' + height +
    ' layers=' + placements.map(function (p) {
      return p.asset.name + '[' + p.image.width + 'x' + p.image.height + '] reg=(' + p.regX + ',' + p.regY + ') tl=(' + Math.round(p.topLeftX) + ',' + Math.round(p.topLeftY) + ') flip=' + (!!p.asset.flipH);
    }).join(' | '));
  return {
    image: canvas.toDataURL('image/png'),
    fileName: (meta.type || 'habbo') + '_dir' + direction + '.png',
    scale: 1,
    visualSize: Math.max(1, Number(options.preferredSize == null ? chooseHabboPreferredVisualSize(meta) : options.preferredSize) || 64),
    offsetPx: { x: Math.round(minX), y: Math.round(minY) },
    // 这里的 offsetPx 已经是“flatten 后整张图左上角相对 room object floor origin 的偏移”。
    anchorMode: 'scuti-floor-origin',
    sortMode: 'box_occlusion',
    flipX: false,
    width: width,
    height: height,
    debugPlacement: placements.map(function (p) {
      return {
        name: p.asset.name,
        kind: p.asset.kind,
        regX: p.regX,
        regY: p.regY,
        topLeftX: Math.round(p.topLeftX),
        topLeftY: Math.round(p.topLeftY),
        width: p.image.width,
        height: p.image.height,
        flipH: !!p.asset.flipH,
      };
    }),
    layersUsed: layers.map(function (layer) {
      return {
        name: layer.name,
        source: layer.source || '',
        kind: layer.kind,
        layerId: layer.layerId,
        size: layer.size,
        x: layer.x,
        y: layer.y,
        flipH: !!layer.flipH
      };
    })
  };
}

function buildHabboLayerDirectionsFromBitmaps(meta, bitmaps) {
  var preferredSize = chooseHabboPreferredVisualSize(meta);
  var vis = chooseHabboVisualization(meta, preferredSize);
  var directions = [];
  if (vis && vis.directions && vis.directions.length) directions = vis.directions.slice();
  if (!directions.length) directions = (meta.visualDirections && meta.visualDirections.length) ? meta.visualDirections.slice() : [0];
  directions = directions.filter(function (v, i, arr) { return arr.indexOf(v) === i; }).sort(function (a, b) { return a - b; });
  var baseDirection = directions.indexOf(0) >= 0 ? 0 : (directions[0] || 0);
  var altDirection = directions.indexOf(2) >= 0 ? 2 : (directions.length > 1 ? directions[1] : baseDirection);
  var activeState = getHabboVisualizationState(meta);

  function buildForDirection(direction) {
    var chosenVis = chooseHabboVisualization(meta, preferredSize);
    if (!chosenVis) {
      pushHabboDebug('buildLayers:none-visualization', { type: meta.type || '', dir: direction, preferredSize: preferredSize, visualizationSizes: meta && meta.visualizationInfo && meta.visualizationInfo.sizes ? Object.keys(meta.visualizationInfo.sizes) : [] });
      return null;
    }
    var actualDirection = chosenVis.directions.indexOf(direction) >= 0 ? direction : (chosenVis.directions.indexOf(0) >= 0 ? 0 : (chosenVis.directions[0] || direction));
    var built = [];
    for (var layerId = 0; layerId <= chosenVis.layerCount; layerId++) {
      var letter = getHabboLayerLetter(layerId, chosenVis.layerCount);
      var frameId = getHabboAnimationFrameForLayer(chosenVis, layerId, activeState);
      var asset = chooseHabboAssetForLayer(meta, letter, actualDirection, frameId, chosenVis.size || preferredSize);
      if (!asset && frameId !== 0) asset = chooseHabboAssetForLayer(meta, letter, actualDirection, 0, chosenVis.size || preferredSize);
      if (!asset && actualDirection !== 0) asset = chooseHabboAssetForLayer(meta, letter, 0, frameId, chosenVis.size || preferredSize);
      if (!asset) {
        pushHabboDebug('buildLayers:skip', { type: meta.type || '', dir: direction, actualDirection: actualDirection, layerId: layerId, letter: letter, frame: frameId, reason: 'missing-asset' });
        continue;
      }
      var image = resolveHabboLayerImage(bitmaps, asset);
      if (!image) {
        pushHabboDebug('buildLayers:skip', { type: meta.type || '', dir: direction, actualDirection: actualDirection, asset: asset.name, layerId: layerId, frame: frameId, reason: 'missing-image', source: asset.source || '' });
        continue;
      }
      var props = layerId === chosenVis.layerCount ? { x: 0, y: 0, z: 0, alpha: 51, ink: '' } : (chosenVis.layers[layerId] || { x: 0, y: 0, z: 0, alpha: null, ink: '' });
      var propX = Number(props.x) || 0;
      var propY = Number(props.y) || 0;
      var regX = Number(asset.x) || 0;
      var regY = Number(asset.y) || 0;
      var alpha = props.alpha == null ? (letter === 'sd' ? 0.2 : 1) : Math.max(0, Math.min(1, Number(props.alpha) / 255));
      var blend = String(props.ink || '').toUpperCase();
      // Scuti 语义里，layer 的 x/y 是贴图左上角相对 furniture container 原点的偏移；
      // 对镜像资源，左上角不是 -regX，而要先把图片宽度吃进去：regX - image.width。
      // 之前 layered/composite 路径一直把 flip 图层也当成 -regX，导致 mirrored part/body 被系统性甩错。
      var topLeftX = (asset.flipH ? (regX - Number(image.width || 0)) : (-regX)) + propX;
      var topLeftY = (-regY) + propY;
      var layerObj = {
        image: image.dataUrl,
        imageCanvas: image.canvas || null,
        fileName: asset.name + '.png',
        width: image.width,
        height: image.height,
        visualSize: Math.max(1, Number(asset.size) || chooseHabboPreferredVisualSize(meta) || 64),
        offsetPx: { x: topLeftX, y: topLeftY },
        regX: regX,
        regY: regY,
        propX: propX,
        propY: propY,
        offsetZ: Number(props.z) || 0,
        flipX: !!asset.flipH,
        kind: letter === 'sd' ? 'shadow' : (layerId === 0 ? 'body' : 'part'),
        layerId: asset.layerId,
        layerIndex: layerId,
        name: asset.name,
        source: asset.source || '',
        alpha: alpha,
        blend: blend,
        frameId: frameId,
        direction: actualDirection,
        zOrderHint: (letter === 'sd' ? -10000 : 0) + (Number(props.z) || 0),
      };
      pushHabboDebug('buildLayers:layer', { type: meta.type || '', dir: direction, actualDirection: actualDirection, asset: asset.name, layerId: layerId, kind: layerObj.kind, frame: frameId, size: asset.size, reg: { x: regX, y: regY }, props: { x: propX, y: propY, z: Number(props.z) || 0 }, offsetPx: layerObj.offsetPx, offsetZ: layerObj.offsetZ, alpha: alpha, blend: blend, flipX: layerObj.flipX, wh: { w: image.width, h: image.height }, source: asset.source || '' });
      built.push(layerObj);
    }
    built.sort(function (a, b) {
      if ((a.zOrderHint || 0) !== (b.zOrderHint || 0)) return (a.zOrderHint || 0) - (b.zOrderHint || 0);
      if ((a.layerIndex || 0) !== (b.layerIndex || 0)) return (a.layerIndex || 0) - (b.layerIndex || 0);
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
    pushHabboDebug('buildLayers:dir-done', { type: meta.type || '', dir: direction, actualDirection: actualDirection, count: built.length, layers: built.map(function(l){ return { name:l.name, kind:l.kind, layerIndex:l.layerIndex, frame:l.frameId, offsetPx:l.offsetPx, offsetZ:l.offsetZ, alpha:l.alpha, blend:l.blend, wh:{w:l.width,h:l.height}, flipX:l.flipX }; }) });
    return built;
  }
  var baseLayers = buildForDirection(baseDirection);
  if (!baseLayers || !baseLayers.length) { habboTrace('layerDirections:none baseDir=' + baseDirection); return null; }
  var altLayers = buildForDirection(altDirection) || baseLayers;
  habboTrace('layerDirections baseDir=' + baseDirection + ' altDir=' + altDirection + ' base=' + baseLayers.map(function (l) { return l.name + '@(' + l.offsetPx.x + ',' + l.offsetPx.y + ',' + l.offsetZ + ')/' + l.width + 'x' + l.height + (l.flipX ? ':flip' : '') + ':a=' + l.alpha + ':b=' + l.blend; }).join(' | ') + ' alt=' + altLayers.map(function (l) { return l.name + '@(' + l.offsetPx.x + ',' + l.offsetPx.y + ',' + l.offsetZ + ')/' + l.width + 'x' + l.height + (l.flipX ? ':flip' : '') + ':a=' + l.alpha + ':b=' + l.blend; }).join(' | '));
  return { '0': baseLayers, '1': altLayers };
}

function buildHabboSpriteDirectionsFromBitmaps(meta, bitmaps) {
  var baseDirection = meta.visualDirections.indexOf(0) >= 0 ? 0 : (meta.visualDirections.length ? meta.visualDirections[0] : 0);
  var altDirection = meta.visualDirections.indexOf(2) >= 0 ? 2 : (meta.visualDirections.length > 1 ? meta.visualDirections[1] : baseDirection);
  var baseSprite = composeHabboDirectionSprite(meta, bitmaps, baseDirection, { includeShadow: false });
  var altSprite = composeHabboDirectionSprite(meta, bitmaps, altDirection, { includeShadow: false }) || baseSprite;
  if (!baseSprite) { habboTrace('spriteDirections:none baseDir=' + baseDirection); return null; }
  habboTrace('spriteDirections baseDir=' + baseDirection + ' altDir=' + altDirection + ' base=' + baseSprite.width + 'x' + baseSprite.height + ' offset=(' + (baseSprite.offsetPx && baseSprite.offsetPx.x || 0) + ',' + (baseSprite.offsetPx && baseSprite.offsetPx.y || 0) + ') alt=' + ((altSprite||baseSprite).width) + 'x' + ((altSprite||baseSprite).height));
  return {
    '0': baseSprite,
    '1': altSprite || baseSprite
  };
}

function buildHabboFloorAnchor(meta) {
  // 这里给 proxy / boxes 用的仍然是 prefab 原点，不去人为挪 footprint。
  // 视觉层真正的 Scuti 对齐由 sprite.anchorMode = scuti-floor-origin 负责：
  // room object 先落到 origin tile 的 floor origin，再叠加 layer offset。
  return {
    x: 0,
    y: 0,
    z: 0
  };
}

async function parseHabboSwfRuntime(arrayBuffer) {
  habboTrace('runtime-parse:start inputBytes=' + ((arrayBuffer && (arrayBuffer.byteLength || arrayBuffer.length)) || 0));
  pushHabboDebug('runtime-parse:start', { inputBytes: ((arrayBuffer && (arrayBuffer.byteLength || arrayBuffer.length)) || 0) });
  var inflated = await inflateSwfBytes(arrayBuffer);
  var tags = parseSwfTags(inflated);
  var symbolMap = parseSwfSymbolClassMap(tags);
  var xmls = collectHabboXmlTextsFromTags(tags);
  var meta = parseHabboSwfMetadataFromXmls(xmls);
  var bitmaps = await extractHabboBitmapAssetsFromTags(tags, symbolMap, meta.type);
  if (!Object.keys(bitmaps).length) throw new Error('SWF 中未找到可解码的位图层');
  pushHabboDebug('runtime-parse:meta', { type: meta.type || '', dimensions: meta.dimensions || null, logicDirections: meta.logicDirections || [], visualDirections: meta.visualDirections || [], visualizationSizes: meta && meta.visualizationInfo && meta.visualizationInfo.sizes ? Object.keys(meta.visualizationInfo.sizes) : [], assetsCount: (meta.assets || []).length });
  detailLog('habbo-xml: type=' + String(meta.type || '') +
    ' assetsXmlRoot=' + ((xmls && xmls.assetsXml || '').slice(0, 24).replace(/\s+/g, ' ')) +
    ' assets=' + String((meta.assets || []).length) +
    ' firstAssets=' + (meta.assets || []).slice(0, 4).map(function (a) { return a.name + '@(' + a.x + ',' + a.y + ')'; }).join(' | '));
  var builtLayerDirs = buildHabboLayerDirectionsFromBitmaps(meta, bitmaps) || {};
  // 逐 layer 渲染已经足够；大件 furni 再额外 flatten 一次会显著拖慢导入，还会放大日志量。
  // 只有在 layer 构建失败时，才退回到扁平 sprite fallback。
  var builtSpriteDirs = Object.keys(builtLayerDirs).length ? {} : (buildHabboSpriteDirectionsFromBitmaps(meta, bitmaps) || {});
  pushHabboDebug('runtime-parse:done', { type: String(meta.type || ''), bitmaps: Object.keys(bitmaps).length, spriteDirs: Object.keys(builtSpriteDirs), layerDirs: Object.keys(builtLayerDirs), assets: (meta.assets || []).length });
  habboTrace('runtime-parse:done type=' + String(meta.type || '') + ' bitmaps=' + Object.keys(bitmaps).length + ' spriteDirs=' + Object.keys(builtSpriteDirs).join(',') + ' layerDirs=' + Object.keys(builtLayerDirs).join(',') + ' assets=' + (meta.assets || []).length);
  return {
    bytes: inflated,
    tags: tags,
    symbolMap: symbolMap,
    xmls: xmls,
    meta: meta,
    bitmaps: bitmaps,
    spriteDirections: builtSpriteDirs,
    habboLayerDirections: builtLayerDirs
  };
}

async function buildHabboPrefabDefinition(runtime, options) {
  options = options || {};
  var meta = runtime && runtime.meta ? runtime.meta : runtime;
  var type = String(meta.type || 'habbo_item');
  var safeType = type.replace(/[^a-zA-Z0-9_\-]/g, '_');
  var id = String(options.id || ('habbo_' + safeType));
  var name = String(options.name || ('Habbo ' + safeType));
  var base = options.base || '#b7d0d4';
  var spriteDirections = runtime && runtime.spriteDirections ? runtime.spriteDirections : null;
  var habboLayerDirections = runtime && runtime.habboLayerDirections ? runtime.habboLayerDirections : null;
  var directionGroups = {};
  (meta.assets || []).forEach(function (asset) {
    var key = String(asset.direction || 0);
    if (!directionGroups[key]) directionGroups[key] = [];
    directionGroups[key].push({
      name: asset.name,
      kind: asset.kind,
      layerId: asset.layerId,
      size: asset.size,
      source: asset.source || '',
      flipH: !!asset.flipH,
      offsetPx: { x: asset.x || 0, y: asset.y || 0 },
      zOrderHint: 0,
    });
  });
  var floorAnchor = buildHabboFloorAnchor(meta);
  var proxyDims = {
    x: Math.max(1, Math.round(Number(meta.dimensions && meta.dimensions.x) || 1)),
    y: Math.max(1, Math.round(Number(meta.dimensions && meta.dimensions.y) || 1)),
    z: Math.max(1, Math.round(Number(meta.dimensions && meta.dimensions.z) || 1)),
  };
  return {
    id: id,
    name: name,
    kind: 'habbo_import',
    asset: options.asset || (safeType + '.swf'),
    base: base,
    renderMode: (spriteDirections || habboLayerDirections) ? 'sprite_proxy' : 'hybrid',
    anchor: floorAnchor,
    voxels: makeRectVoxels(proxyDims.x, proxyDims.y, proxyDims.z, base),
    sprite: spriteDirections && spriteDirections['0'] ? Object.assign({}, spriteDirections['0']) : null,
    spriteDirections: spriteDirections,
    habboLayerDirections: habboLayerDirections,
    habboMeta: {
      sourceKind: 'habbo_swf',
      sourceName: options.asset || '',
      relativePath: normalizeHabboRelativePathClient(options.relativePath || options.asset || ''),
      type: type,
      dimensions: cloneJsonSafe(meta.dimensions),
      proxyDims: cloneJsonSafe(proxyDims),
      logicDirections: cloneJsonSafe(meta.logicDirections),
      visualDirections: cloneJsonSafe(meta.visualDirections),
      visualization: meta.visualization || '',
      logic: meta.logic || '',
      scutiReference: {
        roomAnchor: 'position-tile-center-not-footprint-center',
        spriteOrganization: 'direction -> extracted bitmap layers with offsets',
        sorting: 'proxy-first + sprite overlay',
        zoomSelection: 'prefer-size-64-then-largest'
      },
      layersByDirection: directionGroups,
      usesFlattenedFrame: false,
      notes: [
        '当前版会直接从 SWF 的 DefineBitsLossless2 位图 tag 重建 2D 图层，不再依赖外部 _frame.png。',
        '组织方式参考 Scuti：先读 objectData / visualization / assets，再按 direction + layer offsets 组装显示对象。',
        '当前渲染按 direction + layer 逐层绘制，包含 shadow/body/part；多格 floor furni 的锚点按 Scuti 的 room object 逻辑固定在放置 tile 的中心，而不是整个 footprint 的中心。',
        '如果某个 SWF 含有更复杂的动画/状态/特殊 visualization，这一版仍会先按 static floor furni 的方式处理。'
      ],
    },
  };
}

function findAutoPlacementForPrefab(prefab, rotation) {
  var cells = [];
  var centerX = Math.max(0, (settings.gridW - 1) / 2);
  var centerY = Math.max(0, (settings.gridH - 1) / 2);
  for (var y = 0; y < settings.gridH; y++) {
    for (var x = 0; x < settings.gridW; x++) {
      cells.push({ x: x, y: y, dist: Math.abs(x - centerX) + Math.abs(y - centerY) });
    }
  }
  cells.sort(function (a, b) {
    if (a.dist !== b.dist) return a.dist - b.dist;
    if (a.y !== b.y) return a.y - b.y;
    return a.x - b.x;
  });
  var variant = prefabVariant(prefab, rotation || 0);
  var fallback = null;
  for (var i = 0; i < cells.length; i++) {
    var c = cells[i];
    var candidate = computeCandidate(c.x, c.y, variant, null);
    if (!candidate || !candidate.valid || !candidate.origin) continue;
    if (candidate.origin.z === 0) return candidate;
    if (!fallback) fallback = candidate;
  }
  return fallback;
}

function prepareImportedPrefabForPlacement(prefab, options) {
  options = options || {};
  var protoIndex = prototypes.findIndex(function (p) { return p.id === prefab.id; });
  if (protoIndex < 0) throw new Error('Habbo prefab 导入成功，但没有注册到原型列表');
  editor.prototypeIndex = protoIndex;
  refreshPrefabSelectOptions();
  if (ui.prefabSelect) ui.prefabSelect.value = String(protoIndex);
  editor.mode = 'place';
  updateModeButtons();
  setSelectedInstance(null);
  updatePreview();
  if (typeof refreshInspectorPanels === 'function') refreshInspectorPanels();
  var sprite0 = prefab && prefab.spriteDirections && prefab.spriteDirections['0'] ? prefab.spriteDirections['0'] : (prefab ? prefab.sprite : null);
  var debugBits = [];
  if (prefab && prefab.habboMeta && prefab.habboMeta.dimensions) {
    var rawDims = prefab.habboMeta.dimensions;
    debugBits.push('rawDims=' + [rawDims.x, rawDims.y, rawDims.z].join('x'));
    if (prefab.habboMeta.proxyDims) debugBits.push('proxyDims=' + [prefab.habboMeta.proxyDims.x, prefab.habboMeta.proxyDims.y, prefab.habboMeta.proxyDims.z].join('x'));
  }
  if (sprite0) {
    debugBits.push('sprite0=' + (sprite0.width || '?') + 'x' + (sprite0.height || '?'));
    debugBits.push('offset=(' + ((sprite0.offsetPx && sprite0.offsetPx.x) || 0) + ',' + ((sprite0.offsetPx && sprite0.offsetPx.y) || 0) + ')');
    if (Array.isArray(sprite0.debugPlacement)) {
      debugBits.push('layers=' + sprite0.debugPlacement.map(function (p) { return p.name + '@reg(' + p.regX + ',' + p.regY + ')->tl(' + p.topLeftX + ',' + p.topLeftY + ')'; }).join('|'));
    }
  }
  pushHabboDebug('prefab-built', { id: prefab.id, name: prefab.name, anchor: prefab.anchor || null, proxy: { w: prefab.w, d: prefab.d, h: prefab.h }, voxels: ((prefab.voxels && prefab.voxels.length) || 0), layerDirs: Object.keys(prefab.habboLayerDirections || {}), spriteDirs: Object.keys(prefab.spriteDirections || {}), habboMeta: prefab.habboMeta || null });
  habboTrace('prefab-built id=' + prefab.id + ' name=' + prefab.name + ' anchor=' + JSON.stringify(prefab.anchor || null) + ' proxy=' + [prefab.w,prefab.d,prefab.h].join('x') + ' voxels=' + ((prefab.voxels && prefab.voxels.length) || 0) + ' layerDirs=' + Object.keys(prefab.habboLayerDirections || {}).join(',') + ' spriteDirs=' + Object.keys(prefab.spriteDirections || {}).join(','));
  pushLog('habbo-import: ready prefab=' + prefab.id + ' dims=' + prefab.w + 'x' + prefab.d + 'x' + prefab.h + ' mode=place autoInstance=false ' + debugBits.join(' '));
  return { prefab: prefab, prototypeIndex: protoIndex };
}

async function importHabboSwfToSceneFromBuffer(arrayBuffer, options) {
  options = options || {};
  habboTrace('importFromBuffer:start assetName=' + String(options.assetName || '') + ' displayName=' + String(options.displayName || ''));
  var runtime = await parseHabboSwfRuntime(arrayBuffer);
  var meta = runtime.meta;
  var prefabId = options.prefabId || ('habbo_' + meta.type);
  var relativePath = normalizeHabboRelativePathClient(options.relativePath || options.assetName || '');
  var prefabDef = await buildHabboPrefabDefinition(runtime, {
    id: prefabId,
    name: options.displayName || ('Habbo ' + meta.type),
    asset: relativePath || options.assetName || (meta.type + '.swf'),
    relativePath: relativePath,
  });
  var imported = importPrefabDefinition(prefabDef, {
    persist: false,
    source: (options.sourceKind === 'habbo-root' ? 'habbo-root:' : 'habbo-swf:') + (relativePath || options.assetName || meta.type),
    sourceKind: options.sourceKind || 'habbo-import',
    select: options.select !== false,
  });
  if (!imported) throw new Error('导入 prefab 失败');
  var prepared = options.prepareForPlacement === false ? { prefab: imported, prototypeIndex: prototypes.findIndex(function (p) { return p.id === imported.id; }) } : prepareImportedPrefabForPlacement(imported);
  habboTrace('importFromBuffer:done prefab=' + imported.id + ' type=' + meta.type + ' dims=' + [meta.dimensions.x, meta.dimensions.y, meta.dimensions.z].join('x') + ' preparedIndex=' + prepared.prototypeIndex);
  return { prefab: imported, prepared: prepared, meta: meta };
}

async function importHabboSwfFileToScene(file) {
  if (!file) throw new Error('未选择 SWF 文件');
  habboTrace('importFile:start name=' + file.name + ' size=' + file.size);
  var arrayBuffer = await file.arrayBuffer();
  var result = await importHabboSwfToSceneFromBuffer(arrayBuffer, {
    assetName: file.name,
    displayName: 'Habbo ' + file.name.replace(/\.swf$/i, ''),
    prefabId: 'habbo_' + file.name.replace(/\.swf$/i, '').replace(/[^a-zA-Z0-9_\-]/g, '_')
  });
  habboTrace('importFile:done name=' + file.name + ' prefab=' + result.prefab.id);
  return result;
}

async function importBundledHabboDemoToScene(sampleName) {
  var selected = String(sampleName || (ui && ui.habboSampleSelect && ui.habboSampleSelect.value) || 'nft_h26_silverelf.swf');
  var path = 'assets/habbo_import_samples/' + selected;
  habboTrace('importBundled:start sample=' + selected + ' path=' + path);
  var res = await fetch(path, { cache: 'no-store' });
  if (!res.ok) throw new Error('内置示例读取失败：' + res.status + ' / ' + selected);
  var arrayBuffer = await res.arrayBuffer();
  var result = await importHabboSwfToSceneFromBuffer(arrayBuffer, {
    assetName: selected,
    displayName: 'Habbo ' + selected.replace(/\.swf$/i, ''),
    prefabId: 'habbo_' + selected.replace(/\.swf$/i, '').replace(/[^a-zA-Z0-9_\-]/g, '_')
  });
  habboTrace('importBundled:done sample=' + selected + ' prefab=' + result.prefab.id);
  return result;
}


var legacyHabboRepairState = { running: false, queue: [], queued: new Set(), done: new Set(), failed: {} };

function isHabboSwfAssetName(value) {
  return /\.swf(?:$|[?#])/i.test(String(value || ''));
}

function isLegacyFlatHabboPrefab(prefab) {
  if (!prefab || !isHabboSwfAssetName(prefab.asset || (prefab.habboMeta && prefab.habboMeta.sourceName) || '')) return false;
  var looksHabbo = prefab.kind === 'habbo_import' || /^habbo_/i.test(String(prefab.id || '')) || !!prefab.habboMeta;
  if (!looksHabbo) return false;
  var hasLayers = !!(prefab.habboLayerDirections && Object.keys(prefab.habboLayerDirections).length);
  var hasFlat = !!((prefab.spriteDirections && Object.keys(prefab.spriteDirections).length) || (prefab.sprite && prefab.sprite.image));
  return !hasLayers && hasFlat;
}

function getHabboRepairCandidates(prefab) {
  var out = [];
  function addOne(raw) {
    var value = String(raw || '').trim();
    if (!value || out.indexOf(value) >= 0) return;
    out.push(value);
  }
  addOne(prefab && prefab.asset);
  if (prefab && prefab.habboMeta) {
    addOne(prefab.habboMeta.sourceName);
    addOne(prefab.habboMeta.sourceAsset);
    addOne(prefab.habboMeta.originalAsset);
  }
  var expanded = [];
  out.forEach(function (value) {
    if (expanded.indexOf(value) < 0) expanded.push(value);
    var file = value.split('/').pop();
    if (file && file !== value && expanded.indexOf(file) < 0) expanded.push(file);
    if (file && isHabboSwfAssetName(file)) {
      var samplePath = 'assets/habbo_import_samples/' + file;
      if (expanded.indexOf(samplePath) < 0) expanded.push(samplePath);
    }
  });
  return expanded.filter(function (value) { return isHabboSwfAssetName(value); });
}

async function fetchHabboRepairBuffer(prefab) {
  var candidates = getHabboRepairCandidates(prefab);
  var misses = [];
  for (var i = 0; i < candidates.length; i++) {
    var candidate = candidates[i];
    try {
      var res = await fetch(candidate, { cache: 'no-store' });
      if (res && res.ok) return { candidate: candidate, buffer: await res.arrayBuffer() };
      misses.push(candidate + ':http-' + (res ? res.status : 'no-response'));
    } catch (err) {
      misses.push(candidate + ':error-' + (err && err.message ? err.message : err));
    }
  }
  throw new Error('无法重新读取 SWF；candidates=' + candidates.join(',') + ' misses=' + misses.join(','));
}

async function repairLegacyHabboPrefab(prefabId, reason) {
  var prefab = getPrefabById(prefabId);
  if (!isLegacyFlatHabboPrefab(prefab)) return false;
  pushLog('habbo-repair:start prefab=' + prefab.id + ' reason=' + String(reason || 'unknown') + ' candidates=' + getHabboRepairCandidates(prefab).join(','));
  var fetched = await fetchHabboRepairBuffer(prefab);
  var runtime = await parseHabboSwfRuntime(fetched.buffer);
  var rebuiltDef = await buildHabboPrefabDefinition(runtime, {
    id: prefab.id,
    name: prefab.name || prefab.id,
    asset: prefab.asset || fetched.candidate,
    base: prefab.base || '#b7d0d4'
  });
  var merged = normalizePrefab(Object.assign({}, prefab, rebuiltDef, {
    id: prefab.id,
    key: prefab.key || '',
    name: prefab.name || rebuiltDef.name,
    asset: prefab.asset || rebuiltDef.asset,
    base: prefab.base || rebuiltDef.base,
    custom: !!prefab.custom
  }));
  merged.custom = !!prefab.custom;
  merged.assetManaged = !!prefab.assetManaged;
  var idx = prototypes.findIndex(function (p) { return p.id === prefab.id; });
  if (idx >= 0) prototypes[idx] = merged;
  refreshPrefabSelectOptions();
  if (ui.prefabSelect) ui.prefabSelect.value = String(editor.prototypeIndex);
  if (prefab.custom && !prefab.assetManaged) saveCustomPrefabsToLocalStorage();
  invalidateShadowGeometryCache('habbo-repair');
  if (editor.mode === 'place' || editor.mode === 'drag') updatePreview();
  pushLog('habbo-repair:success prefab=' + prefab.id + ' candidate=' + fetched.candidate + ' layerDirs=' + Object.keys(merged.habboLayerDirections || {}).join(',') + ' spriteDirs=' + Object.keys(merged.spriteDirections || {}).join(','));
  return true;
}

async function processLegacyHabboRepairQueue() {
  if (legacyHabboRepairState.running) return;
  legacyHabboRepairState.running = true;
  try {
    while (legacyHabboRepairState.queue.length) {
      var task = legacyHabboRepairState.queue.shift();
      legacyHabboRepairState.queued.delete(task.prefabId);
      try {
        var ok = await repairLegacyHabboPrefab(task.prefabId, task.reason);
        if (ok) legacyHabboRepairState.done.add(task.prefabId);
      } catch (err) {
        legacyHabboRepairState.failed[task.prefabId] = String(err && err.message ? err.message : err);
        pushLog('habbo-repair:error prefab=' + task.prefabId + ' reason=' + String(task.reason || 'unknown') + ' error=' + legacyHabboRepairState.failed[task.prefabId]);
      }
    }
  } finally {
    legacyHabboRepairState.running = false;
  }
}

function queueLegacyHabboPrefabRepair(prefabId, reason) {
  var id = String(prefabId || '');
  if (!id || legacyHabboRepairState.done.has(id) || legacyHabboRepairState.queued.has(id)) return false;
  var prefab = getPrefabById(id);
  if (!isLegacyFlatHabboPrefab(prefab)) return false;
  legacyHabboRepairState.queue.push({ prefabId: id, reason: reason || 'unknown' });
  legacyHabboRepairState.queued.add(id);
  Promise.resolve().then(processLegacyHabboRepairQueue);
  return true;
}

function scheduleLegacyHabboRepairs(reason) {
  for (var i = 0; i < prototypes.length; i++) {
    var prefab = prototypes[i];
    if (isLegacyFlatHabboPrefab(prefab)) queueLegacyHabboPrefabRepair(prefab.id, reason || 'scan');
  }
}

async function scanAssetPrefabs(force) {
  var st = ensureAssetPrefabScanState();
  assetManagedPrefabIds = st.ids;
  if (!isServerMode()) {
    st.lastError = 'not-server-mode';
    st.lastSummary = '未启用本地服务器模式';
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
    return false;
  }
  if (st.inFlight) {
    pushLog('prefab-assets: scan skipped inFlight=true');
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
    return false;
  }
  if (!force && Date.now() - (st.lastAt || 0) < 500) {
    pushLog('prefab-assets: scan skipped debounce');
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
    return false;
  }
  st.inFlight = true;
  st.lastError = '';
  if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
  pushLog(`prefab-assets: scan start force=${!!force} existingManaged=${st.ids.size}`);
  try {
    const res = await fetch(ASSET_PREFAB_INDEX_URL + '?t=' + Date.now(), { cache: 'no-store' });
    const data = await res.json();
    if (!res.ok || !data || !Array.isArray(data.items)) throw new Error('invalid prefab index');
    st.totalFiles = data.items.length;
    st.lastItems = data.items.map(function(item){ return { file: item.file, id: item.id || '', name: item.name || '', kind: item.kind || '' }; });
    st.ids.forEach(function(id){
      const idx = prototypes.findIndex(function(p){ return p.id === id && p.assetManaged; });
      if (idx >= 0) prototypes.splice(idx, 1);
    });
    st.ids.clear();
    let imported = 0;
    for (const item of data.items) {
      try {
        const resp = await fetch('assets/prefabs/' + encodeURIComponent(item.file) + '?t=' + (item.mtimeMs || Date.now()), { cache: 'no-store' });
        const def = await resp.json();
        const importedDef = importPrefabDefinition(def, { persist: false, source: 'assets:' + item.file, sourceKind: 'asset' });
        if (importedDef) {
          imported += 1;
          pushLog(`prefab-assets:file ok file=${item.file} id=${importedDef.id} name=${JSON.stringify(importedDef.name || '')}`);
        } else {
          pushLog(`prefab-assets:file skipped file=${item.file} id=${JSON.stringify(def && def.id || '')}`);
        }
      } catch (err) {
        pushLog(`prefab-assets:error file=${item.file} ${err?.message || err}`);
      }
    }
    refreshPrefabSelectOptions();
    st.importedCount = imported;
    st.lastAt = Date.now();
    lastAssetPrefabScanAt = st.lastAt;
    st.lastSummary = `扫描 ${data.items.length} 个文件，导入 ${imported} 个 prefab`;
    pushLog(`prefab-assets: scanned files=${data.items.length} imported=${imported} prototypeCount=${prototypes.length}`);
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
    return true;
  } catch (err) {
    st.lastError = String(err?.message || err);
    st.lastSummary = '扫描失败';
    pushLog(`prefab-assets:error ${st.lastError}`);
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
    return false;
  } finally {
    st.inFlight = false;
    assetPrefabScanInFlight = false;
    if (typeof refreshAssetScanStatus === 'function') refreshAssetScanStatus();
  }
}

function loadCustomPrefabsFromLocalStorage() {
  if (!sceneStorageAvailable()) return false;
  try {
    var raw = window.localStorage.getItem(LOCAL_PREFAB_STORAGE_KEY);
    if (!raw) return false;
    var defs = JSON.parse(raw);
    if (!Array.isArray(defs)) return false;
    defs.forEach(function (def) { importPrefabDefinition(def, { persist: false, source: 'localStorage' }); });
    scheduleLegacyHabboRepairs('localStorage-prefabs');
    pushLog(`prefab-storage: loaded ${defs.length} custom prefabs`);
    return defs.length > 0;
  } catch (err) {
    pushLog(`prefab-storage:error ${err?.message || err}`);
    return false;
  }
}

function refreshPrefabSelectOptions() {
  if (!ui.prefabSelect) return;
  ui.prefabSelect.innerHTML = '';
  prototypes.forEach(function (prefab, idx) {
    var variant = prefabVariant(prefab, 0);
    var opt = document.createElement('option');
    opt.value = String(idx);
    var voxelInfo = prefab.proxyFallbackUsed ? ('源代理=0，运行时回退=' + normalizedCountText(variant.voxels.length)) : ('代理=' + normalizedCountText(variant.voxels.length));
    opt.textContent = (prefab.key ? prefab.key + '. ' : '') + prefab.name + (prefab.custom ? ' [自定义]' : prefab.assetManaged ? ' [assets]' : '') + (prefab.sprite && prefab.sprite.image ? ' [sprite]' : '') + ' (' + variant.w + '×' + variant.d + '×' + variant.h + ' · ' + voxelInfo + ')';
    ui.prefabSelect.appendChild(opt);
  });
  ui.prefabSelect.value = String(clamp(editor ? editor.prototypeIndex : 0, 0, Math.max(0, prototypes.length - 1)));
}

var player = {
  x: 1.1,
  y: 1.1,
  r: 0.22,
  speed: 2.6,
  walk: 0,
  moving: false,
  dir: 'down',
};

var editor = {
  mode: 'view',
  prototypeIndex: 0,
  rotation: 0,
  draggingInstance: null,
  preview: null,
  hoverDeleteBox: null,
};

var inspectorState = {
  activeTab: 'world',
  selectedInstanceId: null,
};

function getSelectedInstance() {
  return inspectorState.selectedInstanceId ? findInstanceById(inspectorState.selectedInstanceId) : null;
}

function getSelectedPrefab() {
  var inst = getSelectedInstance();
  return inst ? getPrefabById(inst.prefabId) : null;
}

function clearSelectedInstance() {
  inspectorState.selectedInstanceId = null;
}

function setSelectedInstance(instanceId) {
  inspectorState.selectedInstanceId = instanceId || null;
}

function resetPlayer() {
  player.x = 1.1;
  player.y = 1.1;
  player.walk = 0;
  player.dir = 'down';
  player.moving = false;
}

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

function getPlayerProxyBox(nx = player.x, ny = player.y) {
  return {
    x: nx - settings.playerProxyW * 0.5,
    y: ny - settings.playerProxyD * 0.5,
    z: 0,
    w: settings.playerProxyW,
    d: settings.playerProxyD,
    h: settings.playerHeightCells,
  };
}

function getPlayerShadowCenter() {
  const box = getPlayerProxyBox();
  return { x: box.x + box.w * 0.5, y: box.y + box.d * 0.5, z: box.h * 0.5 };
}

function getPlayerGroundBounds() {
  const box = getPlayerProxyBox();
  const poly = [
    iso(box.x, box.y, 0),
    iso(box.x + box.w, box.y, 0),
    iso(box.x + box.w, box.y + box.d, 0),
    iso(box.x, box.y + box.d, 0),
  ];
  return polyBounds(poly);
}


// --- v1.3 render-performance caches ---
var FLOOR_LAYER_INTERACTION_MS = 28;
var SHADOW_LAYER_INTERACTION_MS = 28;
var STATIC_BOX_LAYER_INTERACTION_MS = 28;
var floorLayerCanvas = null;
var floorLayerCtx = null;
var floorLayerCache = { signature: '', lastBuiltAt: 0, dirty: true };
var staticShadowCanvas = null;
var staticShadowCtx = null;
var staticShadowCache = { signature: '', lastBuiltAt: 0, dirty: true };
var staticBoxRenderCache = {
  geometrySignature: '',
  lightingSignature: '',
  occupancy: null,
  renderables: [],
  lastBuiltAt: 0,
  dirtyGeometry: true,
  dirtyLighting: true,
};

function sigNum(v, digits = 3) {
  const n = Number(v || 0);
  const m = Math.pow(10, digits);
  return Math.round(n * m) / m;
}

function isInteractiveRenderPressure() {
  return !!(mouse.draggingView || lightState.dragAxis || player.moving || editor.mode === 'drag');
}

function serializeLightForLayer(light) {
  return {
    id: light.id,
    type: light.type,
    x: sigNum(light.x),
    y: sigNum(light.y),
    z: sigNum(light.z),
    radius: sigNum(light.radius),
    intensity: sigNum(light.intensity),
    color: light.color,
    angle: sigNum(light.angle),
    pitch: sigNum(light.pitch),
    spread: sigNum(light.spread),
    softness: sigNum(light.softness),
    size: sigNum(light.size),
  };
}

function floorLayerSignature() {
  return JSON.stringify({
    viewW: VIEW_W,
    viewH: VIEW_H,
    dpr: sigNum(dpr, 2),
    gridW: settings.gridW,
    gridH: settings.gridH,
    tileW: sigNum(settings.tileW),
    tileH: sigNum(settings.tileH),
    originX: sigNum(settings.originX),
    originY: sigNum(settings.originY),
    cameraX: sigNum(camera.x),
    cameraY: sigNum(camera.y),
    ambient: sigNum(settings.ambient),
    lights: lights.map(serializeLightForLayer),
  });
}

function staticShadowLayerSignature() {
  return JSON.stringify({
    viewW: VIEW_W,
    viewH: VIEW_H,
    dpr: sigNum(dpr, 2),
    tileW: sigNum(settings.tileW),
    tileH: sigNum(settings.tileH),
    originX: sigNum(settings.originX),
    originY: sigNum(settings.originY),
    cameraX: sigNum(camera.x),
    cameraY: sigNum(camera.y),
    boxes: boxesShadowSignature(),
    lights: lights.map(serializeLightForLayer),
    showShadows: !!lightState.showShadows,
    highContrastShadow: !!lightState.highContrastShadow,
    shadowDebugColor: lightState.shadowDebugColor,
    shadowAlpha: sigNum(lightState.shadowAlpha),
    shadowOpacityScale: sigNum(lightState.shadowOpacityScale),
  });
}

function staticBoxGeometrySignature() {
  return JSON.stringify({
    viewW: VIEW_W,
    viewH: VIEW_H,
    dpr: sigNum(dpr, 2),
    tileW: sigNum(settings.tileW),
    tileH: sigNum(settings.tileH),
    originX: sigNum(settings.originX),
    originY: sigNum(settings.originY),
    cameraX: sigNum(camera.x),
    cameraY: sigNum(camera.y),
    boxes: boxesShadowSignature(),
    xrayFaces: !!xrayFaces,
    showDebug: !!showDebug,
  });
}

function staticBoxLightingSignature() {
  return JSON.stringify({
    ambient: sigNum(settings.ambient),
    lights: lights.map(serializeLightForLayer),
  });
}

function markFloorLayerDirty(reason = 'unknown') {
  floorLayerCache.dirty = true;
  if (verboseLog) detailLog(`floor-layer: dirty reason=${reason}`);
}

function markStaticShadowLayerDirty(reason = 'unknown') {
  staticShadowCache.dirty = true;
  if (verboseLog) detailLog(`static-shadows: dirty reason=${reason}`);
}

function markStaticBoxLayerDirty(reason = 'unknown', geometry = false) {
  if (geometry) staticBoxRenderCache.dirtyGeometry = true;
  staticBoxRenderCache.dirtyLighting = true;
  if (verboseLog) detailLog(`static-boxes: dirty reason=${reason} geometry=${geometry}`);
}

function markRenderCachesDirty(reason = 'unknown') {
  markFloorLayerDirty(reason);
  markStaticShadowLayerDirty(reason);
  markStaticBoxLayerDirty(reason, true);
}


// ---- Habbo library selector fix 20260323B ----
habboLibraryState.summaryLoaded = false;
habboLibraryState.summaryLoading = false;
habboLibraryState.categoriesByType = habboLibraryState.categoriesByType || { room: [], wall: [] };
habboLibraryState.totalsByType = habboLibraryState.totalsByType || { room: 0, wall: 0 };
habboLibraryState.totalItems = habboLibraryState.totalItems || 0;
habboLibraryState.selectedItem = habboLibraryState.selectedItem || null;
habboLibraryState.queryKey = habboLibraryState.queryKey || '';
habboLibraryState.pageLoading = false;
habboLibraryState.debugText = habboLibraryState.debugText || '';
habboLibraryState.versionTag = '20260323P-ui-button-iconfix';
function habboLibraryLog(msg) { try { pushLog('[habbo-library] ' + msg); } catch (_) {} }
function setHabboLibraryDebugText(lines) { habboLibraryState.debugText = Array.isArray(lines) ? lines.filter(Boolean).join('\n') : String(lines || ''); }
function buildHabboLibraryQueryKey() { return JSON.stringify({ type: String(habboLibraryState.activeType || 'room'), category: String(habboLibraryState.activeCategory || 'all'), search: String(habboLibraryState.search || '').trim().toLowerCase(), page: parseInt(habboLibraryState.page || 1, 10) || 1, pageSize: parseInt(habboLibraryState.pageSize || 15, 10) || 15 }); }
function getHabboLibraryCategoriesForType(type) { var bucket = habboLibraryState.categoriesByType || {}; return Array.isArray(bucket[type]) ? bucket[type] : []; }
function getHabboLibraryFilteredItems() { return Array.isArray(habboLibraryState.items) ? habboLibraryState.items : []; }
function getSelectedHabboLibraryItem() { var selectedId = String(habboLibraryState.selectedAssetId || ''); var list = Array.isArray(habboLibraryState.items) ? habboLibraryState.items : []; for (var i = 0; i < list.length; i++) if (String(list[i].assetId) === selectedId) return list[i]; return list.length ? list[0] : null; }
function ensureHabboLibrarySelection() { var list = Array.isArray(habboLibraryState.items) ? habboLibraryState.items : []; if (!list.length) { habboLibraryState.selectedAssetId = ''; habboLibraryState.selectedItem = null; return null; } var current = getSelectedHabboLibraryItem(); if (!current) current = list[0]; habboLibraryState.selectedAssetId = String(current.assetId || ''); habboLibraryState.selectedItem = current; return current; }
async function fetchHabboLibrarySummary(force) { if (!habboRootSupported()) { habboLibraryState.summaryLoaded = false; habboLibraryState.loadError = '当前不是本地 server 模式，无法读取外部 Habbo 资源库。'; setHabboLibraryDebugText(['serverMode=false']); return habboLibraryState; } if (habboLibraryState.summaryLoading) return habboLibraryState; if (habboLibraryState.summaryLoaded && !force) return habboLibraryState; habboLibraryState.summaryLoading = true; habboLibraryLog('summary-fetch:start force=' + (!!force) + ' root=' + String((habboAssetRootState && habboAssetRootState.root) || '')); try { var res = await fetch(HABBO_LIBRARY_SUMMARY_API_URL + '?t=' + Date.now(), { cache: 'no-store' }); var data = await res.json(); if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status)); habboLibraryState.summaryLoaded = true; habboLibraryState.loaded = true; habboLibraryState.loadError = ''; habboLibraryState.libraryMode = String(data.libraryMode || ''); habboLibraryState.lastAt = Date.now(); habboLibraryState.totalsByType = { room: Number((data.totalsByType && data.totalsByType.room) || 0), wall: Number((data.totalsByType && data.totalsByType.wall) || 0) }; habboLibraryState.totalItems = Number(data.totalItems || 0); habboLibraryState.categoriesByType = { room: Array.isArray(data.categoriesRoom) ? data.categoriesRoom : [], wall: Array.isArray(data.categoriesWall) ? data.categoriesWall : [] }; if (habboLibraryState.activeCategory !== 'all') { var cats = getHabboLibraryCategoriesForType(habboLibraryState.activeType || 'room'); if (!cats.some(function (x) { return String(x.key) === String(habboLibraryState.activeCategory); })) habboLibraryState.activeCategory = 'all'; } setHabboLibraryDebugText(['build=' + habboLibraryState.versionTag, 'mode=' + String(data.libraryMode || ''), 'root=' + String(data.root || ''), 'configured=' + String(!!data.configured) + ' exists=' + String(!!data.exists), 'total=' + habboLibraryState.totalItems + ' room=' + habboLibraryState.totalsByType.room + ' wall=' + habboLibraryState.totalsByType.wall, 'roomCategories=' + getHabboLibraryCategoriesForType('room').length + ' wallCategories=' + getHabboLibraryCategoriesForType('wall').length]); habboLibraryLog('summary-fetch:done total=' + habboLibraryState.totalItems + ' room=' + habboLibraryState.totalsByType.room + ' wall=' + habboLibraryState.totalsByType.wall + ' roomCats=' + getHabboLibraryCategoriesForType('room').length + ' wallCats=' + getHabboLibraryCategoriesForType('wall').length); } catch (err) { habboLibraryState.summaryLoaded = false; habboLibraryState.loaded = false; habboLibraryState.loadError = String(err && err.message ? err.message : err); habboLibraryState.categoriesByType = { room: [], wall: [] }; habboLibraryState.totalsByType = { room: 0, wall: 0 }; habboLibraryState.totalItems = 0; setHabboLibraryDebugText(['summary-error=' + habboLibraryState.loadError]); habboLibraryLog('summary-fetch:error ' + habboLibraryState.loadError); } finally { habboLibraryState.summaryLoading = false; } return habboLibraryState; }
async function fetchHabboLibraryPage(force) { if (!habboRootSupported()) { habboLibraryState.loadError = '当前不是本地 server 模式，无法读取外部 Habbo 资源库。'; return habboLibraryState; } var key = buildHabboLibraryQueryKey(); if (habboLibraryState.pageLoading) return habboLibraryState; if (!force && habboLibraryState.queryKey === key && Array.isArray(habboLibraryState.items) && habboLibraryState.items.length) return habboLibraryState; habboLibraryState.pageLoading = true; habboLibraryState.loading = true; var params = new URLSearchParams({ type: String(habboLibraryState.activeType || 'room'), category: String(habboLibraryState.activeCategory || 'all'), search: String(habboLibraryState.search || ''), page: String(parseInt(habboLibraryState.page || 1, 10) || 1), pageSize: String(parseInt(habboLibraryState.pageSize || 15, 10) || 15) }); habboLibraryLog('page-fetch:start ' + params.toString()); try { var res = await fetch(HABBO_LIBRARY_PAGE_API_URL + '?' + params.toString() + '&t=' + Date.now(), { cache: 'no-store' }); var data = await res.json(); if (!res.ok || !data || data.ok === false) throw new Error((data && data.error) || ('HTTP ' + res.status)); var items = Array.isArray(data.items) ? data.items.map(function (item) { var swfRel = normalizeHabboRelativePathClient(item.swfRelativePath || item.relativePath || ''); var iconRel = normalizeHabboRelativePathClient(item.iconRelativePath || ''); return { assetId: String(item.assetId || swfRel || Math.random()), prefabId: String(item.prefabId || makeHabboPrefabIdFromRelativePath(swfRel)), displayName: String(item.displayName || item.name || stemFromPath(swfRel) || 'Habbo item'), classname: String(item.classname || stemFromPath(swfRel) || ''), type: String(item.type || 'room').toLowerCase(), category: String(item.category || 'other').toLowerCase(), furniLine: String(item.furniLine || item.furni_line || 'other').toLowerCase(), swfRelativePath: swfRel, iconRelativePath: iconRel, hasIcon: !!(item.hasIcon || iconRel), tags: Array.isArray(item.tags) ? item.tags : [] }; }).filter(function (item) { return !!item.swfRelativePath; }) : []; habboLibraryState.items = items; habboLibraryState.totalItems = Number(data.total || items.length || 0); habboLibraryState.page = Number(data.page || habboLibraryState.page || 1); habboLibraryState.totalPages = Number(data.totalPages || 1); habboLibraryState.queryKey = key; habboLibraryState.loadError = ''; ensureHabboLibrarySelection(); var baseLines = (habboLibraryState.debugText || '').split('\n').filter(Boolean).filter(function (line) { return line.indexOf('query=') !== 0 && line.indexOf('pageItems=') !== 0 && line.indexOf('first=') !== 0; }); baseLines.push('query=' + params.toString(), 'pageItems=' + items.length + ' total=' + habboLibraryState.totalItems + ' totalPages=' + habboLibraryState.totalPages, 'first=' + (items[0] ? (items[0].displayName + ' [' + items[0].swfRelativePath + ']') : 'none')); setHabboLibraryDebugText(baseLines); habboLibraryLog('page-fetch:done items=' + items.length + ' total=' + habboLibraryState.totalItems + ' totalPages=' + habboLibraryState.totalPages + ' first=' + (items[0] ? items[0].classname : 'none')); } catch (err) { habboLibraryState.items = []; habboLibraryState.loadError = String(err && err.message ? err.message : err); habboLibraryLog('page-fetch:error ' + habboLibraryState.loadError); } finally { habboLibraryState.pageLoading = false; habboLibraryState.loading = false; } return habboLibraryState; }
async function fetchHabboLibraryIndex(force) { await fetchHabboLibrarySummary(force); var browseMode = (String(habboLibraryState.search || '').trim() || String(habboLibraryState.activeCategory || 'all') !== 'all') ? 'items' : 'categories'; if (browseMode === 'categories') { habboLibraryState.items = []; habboLibraryState.totalPages = 1; habboLibraryState.queryKey = ''; return habboLibraryState; } return await fetchHabboLibraryPage(force); }
pushLog('[habbo-library] boot hook active on start.bat main entry build=' + habboLibraryState.versionTag + ' presetRoot=' + String((habboAssetRootState && habboAssetRootState.root) || ''));
