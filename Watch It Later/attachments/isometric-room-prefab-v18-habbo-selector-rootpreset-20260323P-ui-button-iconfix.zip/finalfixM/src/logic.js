// v1 split file generated from original monolithic app.js
// 注意：此文件为保持行为稳定的第一刀拆分，允许存在少量跨层函数。


function lightForward(light) {
var yaw = degToRad(light.angle || 0);
var pitch = degToRad(light.pitch || 55);
var cp = Math.cos(pitch);
var sp = Math.sin(pitch);
return normalize3({ x: Math.cos(yaw) * cp, y: Math.sin(yaw) * cp, z: -sp });
}

function lightIncoming(light) {
var f = lightForward(light);
return { x: -f.x, y: -f.y, z: -f.z };
}

function areaSampleOffsets(light) {
var size = Math.max(0.15, light.size || 1.2);
var s = size * 0.55;
var fastMode = shouldUseFastShadowSampling();
if (fastMode) {
  return [
    { x: 0, y: 0 },
    { x: s * 0.75, y: 0 },
    { x: -s * 0.75, y: 0 },
  ];
}

var offsets = [
  { x: 0, y: 0 },
  { x: s, y: 0 },
  { x: -s, y: 0 },
  { x: 0, y: s },
  { x: 0, y: -s },
];
if ((light.softness || 0) > 0.55 && !shouldUseMediumAreaSampling()) {
  offsets.push(
    { x: s * 0.7, y: s * 0.7 },
    { x: -s * 0.7, y: s * 0.7 },
    { x: s * 0.7, y: -s * 0.7 },
    { x: -s * 0.7, y: -s * 0.7 },
  );
}
return offsets;
}


function worldRadiusFromPixels(px) {
return px / Math.max(52, settings.tileW * 0.85);
}

function distanceAttenuation(light, point) {
var dx = point.x - light.x;
var dy = point.y - light.y;
var dz = point.z - light.z;
var dist = Math.hypot(dx, dy, dz);
var radiusWorld = worldRadiusFromPixels(light.radius || 240);
var t = clamp(1 - dist / Math.max(0.001, radiusWorld), 0, 1);
return t * t;
}

function spotlightFalloff(light, point) {
if (light.type !== 'spot') return 1;
var toPoint = normalize3({ x: point.x - light.x, y: point.y - light.y, z: point.z - light.z });
var forward = lightForward(light);
var cosTheta = dot3(toPoint, forward);
var outer = degToRad(Math.max(2, light.spread || 34) * 0.5);
var inner = outer * (1 - clamp((light.softness || 0.3) * 0.75, 0.02, 0.75));
var cosOuter = Math.cos(outer);
var cosInner = Math.cos(inner);
if (cosTheta <= cosOuter) return 0;
if (cosTheta >= cosInner) return 1;
var t = clamp((cosTheta - cosOuter) / Math.max(1e-5, cosInner - cosOuter), 0, 1);
return t * t * (3 - 2 * t);
}

function evaluateSingleLight(light, point, normal) {
normalizeLight(light);
var lightRgb = hexToRgb(light.color);

if (light.type === 'directional') {
  const L = lightIncoming(light);
  const lambert = Math.max(0, dot3(normal, L));
  return { raw: lambert * light.intensity, rgb: lightRgb };
}

var L = normalize3({ x: light.x - point.x, y: light.y - point.y, z: light.z - point.z });
var lambert = Math.max(0, dot3(normal, L));
var raw = lambert * distanceAttenuation(light, point) * light.intensity;
if (light.type === 'spot') raw *= spotlightFalloff(light, point);
return { raw, rgb: lightRgb };
}

function evaluateLight(light, point, normal) {
if (light.type !== 'area') return evaluateSingleLight(light, point, normal);
var offsets = areaSampleOffsets(light);
var raw = 0;
var rgbAccum = { r: 0, g: 0, b: 0 };
for (const o of offsets) {
  const sample = { ...light, type: 'point', x: light.x + o.x, y: light.y + o.y };
  const part = evaluateSingleLight(sample, point, normal);
  raw += part.raw;
  rgbAccum.r += part.rgb.r;
  rgbAccum.g += part.rgb.g;
  rgbAccum.b += part.rgb.b;
}
var n = offsets.length || 1;
return {
  raw: raw / n,
  rgb: { r: rgbAccum.r / n, g: rgbAccum.g / n, b: rgbAccum.b / n },
};
}

function spriteLightAt(point) {
var brightness = 0.35 + settings.ambient * 1.35;
var tintAccum = { r: 0, g: 0, b: 0 };
var weight = 0;
for (const light of lights) {
  const liftedPoint = { x: point.x, y: point.y, z: point.z + 0.3 };
  const evalUp = evaluateLight(light, liftedPoint, { x: 0, y: 0, z: 1 });
  const raw = evalUp.raw;
  brightness += raw * 1.05;
  tintAccum.r += evalUp.rgb.r * raw;
  tintAccum.g += evalUp.rgb.g * raw;
  tintAccum.b += evalUp.rgb.b * raw;
  weight += raw;
}
return {
  brightness: clamp(brightness, 0.28, 1.9),
  tint: weight > 0 ? { r: tintAccum.r / weight, g: tintAccum.g / weight, b: tintAccum.b / weight } : { r: 255, g: 255, b: 255 },
  weight,
};
}

function baseFaceColors(base) {
var rgb = hexToRgb(base);
return {
  top: mixColor(rgb, { r: 255, g: 255, b: 255 }, 0.14),
  east: mulColor(rgb, 0.92),
  south: mulColor(rgb, 0.75),
  line: 'rgba(0,0,0,.16)',
};
}

function litColor(baseRgb, center, normal) {
var accum = mulColor(baseRgb, 0.18 + settings.ambient * 0.9);
for (const light of lights) {
  const evald = evaluateLight(light, center, normal);
  const t = clamp(evald.raw, 0, 1.35);
  const warmed = mixColor(baseRgb, evald.rgb, clamp(t * 0.9, 0, 0.9));
  accum = addColor(accum, mulColor(warmed, t));
}
return accum;
}

function projectGroundPoint(light, point, samplePoint = null) {
if (light.type === 'directional') {
  const dir = lightForward(light);
  if (dir.z >= -0.02) return null;
  const t = point.z / (-dir.z);
  return { x: point.x + dir.x * t, y: point.y + dir.y * t, z: 0 };
}
var source = samplePoint || light;
var dz = source.z - point.z;
if (dz <= 0.05) return null;
var t = point.z / dz;
return { x: point.x + (point.x - source.x) * t, y: point.y + (point.y - source.y) * t, z: 0 };
}

function shadowAlphaForLight(light, receiverPoint) {
var globalAlpha = clamp(Number(lightState.shadowAlpha ?? 1), 0, 1);
var opacityScale = Math.max(0, Number(lightState.shadowOpacityScale ?? 1));
if (globalAlpha <= 0 || opacityScale <= 0 || !lightState.showShadows) return 0;

var alpha;
if (light.type === 'directional') alpha = clamp(0.05 + light.intensity * 0.07, 0.04, 0.16);
else if (light.type === 'spot') alpha = clamp((0.04 + light.intensity * 0.09) * (0.65 + spotlightFalloff(light, receiverPoint) * 0.7), 0.03, 0.2);
else if (light.type === 'area') alpha = clamp(0.03 + light.intensity * 0.05, 0.02, 0.11);
else alpha = clamp(0.05 + light.intensity * 0.08, 0.04, 0.18);

var scaled = clamp(alpha * opacityScale, 0, 1);
var capped = Math.min(lightState.highContrastShadow ? 0.95 : 0.7, scaled * globalAlpha);
return clamp(capped, 0, 1);
}

function shadowFillCss(alpha) {
var a = clamp(alpha, 0, 0.95);
if (lightState.highContrastShadow) {
  return rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), a);
}
return `rgba(0,0,0,${a})`;
}

function shadowStrokeCss(alpha) {
var a = clamp(alpha, 0, 0.95);
if (lightState.highContrastShadow) {
  return rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), Math.min(1, a + 0.22));
}
return `rgba(0,0,0,${Math.min(0.35, a + 0.08)})`;
}


function convexHull2(points) {
if (points.length <= 1) return points.slice();
var pts = points.slice().sort((a,b)=> a.x === b.x ? a.y - b.y : a.x - b.x);
var cross = (o,a,b) => (a.x-o.x)*(b.y-o.y) - (a.y-o.y)*(b.x-o.x);
var lower = [];
for (const p of pts) {
  while (lower.length >= 2 && cross(lower[lower.length-2], lower[lower.length-1], p) <= 0) lower.pop();
  lower.push(p);
}
var upper = [];
for (let i = pts.length - 1; i >= 0; i--) {
  const p = pts[i];
  while (upper.length >= 2 && cross(upper[upper.length-2], upper[upper.length-1], p) <= 0) upper.pop();
  upper.push(p);
}
lower.pop(); upper.pop();
return lower.concat(upper);
}

function boxShadowWorldPoints(box) {
return [
  { x: box.x, y: box.y, z: box.z },
  { x: box.x + box.w, y: box.y, z: box.z },
  { x: box.x + box.w, y: box.y + box.d, z: box.z },
  { x: box.x, y: box.y + box.d, z: box.z },
  { x: box.x, y: box.y, z: box.z + box.h },
  { x: box.x + box.w, y: box.y, z: box.z + box.h },
  { x: box.x + box.w, y: box.y + box.d, z: box.z + box.h },
  { x: box.x, y: box.y + box.d, z: box.z + box.h },
];
}

function drawProjectedShadow(worldPts, light, receiverPoint, debugTag = '') {
if (!lightState.showShadows) return;
normalizeLight(light);
var emitShadow = (projected, alpha) => {
  if (alpha <= 0.0001) return;
  if (!projected.length) return;
  const hull = convexHull2(projected.map(p => ({ x: p.x, y: p.y })));
  if (hull.length < 3) return;
  if (verboseLog && debugState.frame <= 6) {
    detailLog(`shadow:${debugTag || 'shape'} light=${light.name}/${light.type} hullN=${hull.length} alpha=${alpha.toFixed(3)} fill=${lightState.highContrastShadow ? lightState.shadowDebugColor : '#000000'} hull=${hull.map(p => `(${p.x.toFixed(2)},${p.y.toFixed(2)})`).join(' ')}`);
  }
  drawPoly(hull.map(p => iso(p.x, p.y, 0)), shadowFillCss(alpha), lightState.highContrastShadow ? shadowStrokeCss(alpha) : null);
};
if (light.type === 'area') {
  const offsets = areaSampleOffsets(light);
  const baseAlpha = shadowAlphaForLight(light, receiverPoint) / Math.max(1, offsets.length) * (1.2 + light.softness * 0.8);
  for (const o of offsets) {
    const sample = { ...light, x: light.x + o.x, y: light.y + o.y, z: light.z };
    const projected = worldPts.map(p => projectGroundPoint(light, p, sample)).filter(Boolean);
    emitShadow(projected, baseAlpha);
  }
  return;
}
var projected = worldPts.map(p => projectGroundPoint(light, p)).filter(Boolean);
var a = shadowAlphaForLight(light, receiverPoint);
emitShadow(projected, a);
}

function drawPlayerShadow() {
if (!SHOW_PLAYER) return;
if (!lightState.showShadows) return;

var proxy = getPlayerProxyBox();
var worldPts = boxShadowWorldPoints(proxy);
var center = getPlayerShadowCenter();
for (const light of lights) drawProjectedShadow(worldPts, light, center, 'player-proxy');

var bounds = getPlayerGroundBounds();
var foot = iso(player.x, player.y, 0);
var widthPx = Math.max(10, bounds.maxX - bounds.minX);
var heightPx = Math.max(6, bounds.maxY - bounds.minY);
var contactAlpha = clamp(0.12 + settings.ambient * 0.20, 0.10, 0.24);
for (const light of lights) {
  contactAlpha += clamp(evaluateLight(light, { x: player.x, y: player.y, z: 0.12 }, { x: 0, y: 0, z: 1 }).raw * 0.025, 0, 0.045);
}
ctx.save();
ctx.translate(foot.x, foot.y + 4);
ctx.scale(Math.max(0.75, widthPx / 26), Math.max(0.42, heightPx / 18));
ctx.fillStyle = `rgba(0,0,0,${clamp(contactAlpha, 0.10, 0.30)})`;
ctx.beginPath();
ctx.arc(0, 0, 13, 0, Math.PI * 2);
ctx.fill();
ctx.restore();

if (showDebug) {
  const pts = cubePoints(proxy.x, proxy.y, proxy.z, proxy.w, proxy.d, proxy.h);
  drawPoly([pts.p001, pts.p101, pts.p111, pts.p011], 'rgba(255,210,120,.05)', 'rgba(255,210,120,.82)');
  drawPoly([pts.p101, pts.p111, pts.p110, pts.p100], null, 'rgba(255,210,120,.55)');
  drawPoly([pts.p011, pts.p111, pts.p110, pts.p010], null, 'rgba(255,210,120,.55)');
}
}

function currentProto() {
var p = currentPrefab();
return prefabVariant(p, editor.rotation);
}

function iso(x, y, z = 0) {
return {
  x: settings.originX + camera.x + (x - y) * settings.tileW / 2,
  y: settings.originY + camera.y + (x + y) * settings.tileH / 2 - z * settings.tileH,
};
}

function screenToFloor(sx, sy) {
var dx = (sx - settings.originX - camera.x) / (settings.tileW / 2);
var dy = (sy - settings.originY - camera.y) / (settings.tileH / 2);
return { x: (dx + dy) / 2, y: (dy - dx) / 2 };
}

function shadeHex(hex, delta) {
var v = hex.replace('#', '');
var n = parseInt(v, 16);
var r = (n >> 16) + delta;
var g = ((n >> 8) & 255) + delta;
var b = (n & 255) + delta;
r = clamp(r, 0, 255); g = clamp(g, 0, 255); b = clamp(b, 0, 255);
return `rgb(${r},${g},${b})`;
}

function hexToRgb(hex) {
var v = hex.replace('#', '');
var n = parseInt(v, 16);
return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToCss(rgb, a = 1) {
return `rgba(${Math.round(rgb.r)}, ${Math.round(rgb.g)}, ${Math.round(rgb.b)}, ${a})`;
}

function lerp(a, b, t) { return a + (b - a) * t; }

function mixColor(rgb, target, t) {
return {
  r: lerp(rgb.r, target.r, t),
  g: lerp(rgb.g, target.g, t),
  b: lerp(rgb.b, target.b, t),
};
}

function mulColor(rgb, k) {
return {
  r: clamp(rgb.r * k, 0, 255),
  g: clamp(rgb.g * k, 0, 255),
  b: clamp(rgb.b * k, 0, 255),
};
}

function addColor(a, b) {
return {
  r: clamp(a.r + b.r, 0, 255),
  g: clamp(a.g + b.g, 0, 255),
  b: clamp(a.b + b.b, 0, 255),
};
}

function normalize3(v) {
var len = Math.hypot(v.x, v.y, v.z) || 1;
return { x: v.x / len, y: v.y / len, z: v.z / len };
}

function dot3(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

function drawLightGlow() {
if (!lightState.showGlow) return;
for (const light of lights) {
  normalizeLight(light);
  const p = iso(light.x, light.y, light.z);
  const rgb = hexToRgb(light.color);

  if (light.type === 'directional') {
    const incoming = lightIncoming(light);
    const g = ctx.createLinearGradient(
      VIEW_W * 0.5 - incoming.x * VIEW_W * 0.75,
      VIEW_H * 0.5 - incoming.y * VIEW_H * 0.55,
      VIEW_W * 0.5 + incoming.x * VIEW_W * 0.75,
      VIEW_H * 0.5 + incoming.y * VIEW_H * 0.55,
    );
    g.addColorStop(0, rgbToCss(rgb, clamp(light.intensity * 0.14, 0, 0.18)));
    g.addColorStop(0.55, rgbToCss(rgb, 0.03));
    g.addColorStop(1, rgbToCss(rgb, 0));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    continue;
  }

  if (light.type === 'area') {
    const size = 12 + (light.size || 1) * 10;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.fillStyle = rgbToCss(rgb, clamp(0.18 * light.intensity, 0, 0.3));
    ctx.strokeStyle = rgbToCss(rgb, 0.65);
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.rect(-size, -size * 0.55, size * 2, size * 1.1);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  const glow = ctx.createRadialGradient(p.x, p.y, 6, p.x, p.y, light.radius);
  glow.addColorStop(0, rgbToCss(rgb, clamp(0.18 * light.intensity, 0, 0.32)));
  glow.addColorStop(0.35, rgbToCss(rgb, clamp(0.08 * light.intensity, 0, 0.22)));
  glow.addColorStop(1, rgbToCss(rgb, 0));
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
}
}


var shadowGeomCache = {
signature: '',
components: [],
occupancy: new Map(),
totalVoxels: 0,
totalFaces: 0,
};
var shadowMaskCanvas = null;
var shadowMaskCtx = null;

function boxesShadowSignature() {
return boxes
  .slice()
  .sort((a, b) => a.id - b.id)
  .map(b => [b.id, b.x, b.y, b.z, b.w, b.d, b.h].join(':'))
  .join('|');
}

function shadowVoxelKey(x, y, z) {
return `${x}|${y}|${z}`;
}

function shadowFaceKey(face) {
var p = face.pts[0];
return `${face.kind}|${p.x}|${p.y}|${p.z}`;
}

function buildShadowComponents() {
var signature = boxesShadowSignature();
if (shadowGeomCache.signature === signature && shadowGeomCache.components.length) {
  if (verboseLog && debugState.frame <= 3) {
    detailLog(`shadow-components: cache-hit components=${shadowGeomCache.components.length} voxels=${shadowGeomCache.totalVoxels} faces=${shadowGeomCache.totalFaces}`);
  }
  return shadowGeomCache.components;
}

var occupancy = new Map();
for (const box of boxes) {
  const x0 = Math.round(box.x), x1 = Math.round(box.x + box.w);
  const y0 = Math.round(box.y), y1 = Math.round(box.y + box.d);
  const z0 = Math.round(box.z), z1 = Math.round(box.z + box.h);
  for (let x = x0; x < x1; x++) {
    for (let y = y0; y < y1; y++) {
      for (let z = z0; z < z1; z++) {
        const key = shadowVoxelKey(x, y, z);
        if (!occupancy.has(key)) occupancy.set(key, { x, y, z, boxIds: [box.id] });
        else occupancy.get(key).boxIds.push(box.id);
      }
    }
  }
}

var dirs = [
  { dx: 1, dy: 0, dz: 0 },
  { dx: -1, dy: 0, dz: 0 },
  { dx: 0, dy: 1, dz: 0 },
  { dx: 0, dy: -1, dz: 0 },
  { dx: 0, dy: 0, dz: 1 },
  { dx: 0, dy: 0, dz: -1 },
];

var visited = new Set();
var components = [];
for (const cell of occupancy.values()) {
  const startKey = shadowVoxelKey(cell.x, cell.y, cell.z);
  if (visited.has(startKey)) continue;
  const queue = [cell];
  visited.add(startKey);
  const cells = [];
  const boxIdSet = new Set();
  let minX = Infinity, minY = Infinity, minZ = Infinity, maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  while (queue.length) {
    const cur = queue.pop();
    cells.push(cur);
    for (const id of cur.boxIds || []) boxIdSet.add(id);
    minX = Math.min(minX, cur.x); minY = Math.min(minY, cur.y); minZ = Math.min(minZ, cur.z);
    maxX = Math.max(maxX, cur.x + 1); maxY = Math.max(maxY, cur.y + 1); maxZ = Math.max(maxZ, cur.z + 1);
    for (const d of dirs) {
      const nk = shadowVoxelKey(cur.x + d.dx, cur.y + d.dy, cur.z + d.dz);
      if (!occupancy.has(nk) || visited.has(nk)) continue;
      visited.add(nk);
      queue.push(occupancy.get(nk));
    }
  }

  const faceMap = new Map();
  const pushFace = (kind, pts, normal, voxel) => {
    const face = { kind, pts, normal, voxel };
    faceMap.set(shadowFaceKey(face), face);
  };

  for (const v of cells) {
    const x = v.x, y = v.y, z = v.z;
    if (!occupancy.has(shadowVoxelKey(x, y, z + 1))) {
      pushFace('top', [
        { x, y, z: z + 1 },
        { x: x + 1, y, z: z + 1 },
        { x: x + 1, y: y + 1, z: z + 1 },
        { x, y: y + 1, z: z + 1 },
      ], { x: 0, y: 0, z: 1 }, v);
    }
    if (!occupancy.has(shadowVoxelKey(x + 1, y, z))) {
      pushFace('xp', [
        { x: x + 1, y, z },
        { x: x + 1, y: y + 1, z },
        { x: x + 1, y: y + 1, z: z + 1 },
        { x: x + 1, y, z: z + 1 },
      ], { x: 1, y: 0, z: 0 }, v);
    }
    if (!occupancy.has(shadowVoxelKey(x - 1, y, z))) {
      pushFace('xn', [
        { x, y, z },
        { x, y, z: z + 1 },
        { x, y: y + 1, z: z + 1 },
        { x, y: y + 1, z },
      ], { x: -1, y: 0, z: 0 }, v);
    }
    if (!occupancy.has(shadowVoxelKey(x, y + 1, z))) {
      pushFace('yp', [
        { x, y: y + 1, z },
        { x: x + 1, y: y + 1, z },
        { x: x + 1, y: y + 1, z: z + 1 },
        { x, y: y + 1, z: z + 1 },
      ], { x: 0, y: 1, z: 0 }, v);
    }
    if (!occupancy.has(shadowVoxelKey(x, y - 1, z))) {
      pushFace('yn', [
        { x, y, z },
        { x, y, z: z + 1 },
        { x: x + 1, y, z: z + 1 },
        { x: x + 1, y, z },
      ], { x: 0, y: -1, z: 0 }, v);
    }
  }

  const faces = [...faceMap.values()];
  const component = {
    kind: 'component',
    cells,
    boxIds: [...boxIdSet].sort((a, b) => a - b),
    faces,
    bounds: { minX, minY, minZ, maxX, maxY, maxZ },
    center: { x: (minX + maxX) * 0.5, y: (minY + maxY) * 0.5, z: (minZ + maxZ) * 0.5 },
    debugTag: `comp(${[...boxIdSet].sort((a, b) => a - b).map(id => `#${id}`).join(',')})`,
  };
  components.push(component);
}

shadowGeomCache.signature = signature;
shadowGeomCache.components = components;
shadowGeomCache.occupancy = occupancy;
shadowGeomCache.totalVoxels = occupancy.size;
shadowGeomCache.totalFaces = components.reduce((sum, c) => sum + c.faces.length, 0);

detailLog(`shadow-components: rebuilt components=${components.length} voxels=${occupancy.size} faces=${shadowGeomCache.totalFaces}`);
if (verboseLog || debugState.frame <= 2) {
  components.forEach((comp, idx) => {
    detailLog(`shadow-component[${idx}] boxes=${comp.boxIds.join(',')} voxels=${comp.cells.length} faces=${comp.faces.length} bounds=(${comp.bounds.minX},${comp.bounds.minY},${comp.bounds.minZ})->(${comp.bounds.maxX},${comp.bounds.maxY},${comp.bounds.maxZ})`);
  });
}
return components;
}

function invalidateShadowGeometryCache(reason = 'unknown') {
shadowGeomCache.signature = '';
shadowGeomCache.components = [];
shadowGeomCache.occupancy = new Map();
shadowGeomCache.totalVoxels = 0;
shadowGeomCache.totalFaces = 0;
detailLog(`shadow-components: invalidated reason=${reason}`);
}

function ensureShadowMaskCanvas() {
if (!shadowMaskCanvas) {
  shadowMaskCanvas = document.createElement('canvas');
  shadowMaskCtx = shadowMaskCanvas.getContext('2d');
}
if (shadowMaskCanvas.width !== Math.round(VIEW_W * dpr) || shadowMaskCanvas.height !== Math.round(VIEW_H * dpr)) {
  shadowMaskCanvas.width = Math.round(VIEW_W * dpr);
  shadowMaskCanvas.height = Math.round(VIEW_H * dpr);
  shadowMaskCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  shadowMaskCtx.imageSmoothingEnabled = true;
  detailLog(`shadow-mask: resize backing=${shadowMaskCanvas.width}x${shadowMaskCanvas.height}`);
}
return shadowMaskCtx;
}

function clearShadowMask() {
var mctx = ensureShadowMaskCanvas();
mctx.clearRect(0, 0, VIEW_W, VIEW_H);
return mctx;
}

function drawMaskPoly(mctx, points, fill, stroke = null, width = 1) {
if (!points || points.length < 3) return;
mctx.beginPath();
mctx.moveTo(points[0].x, points[0].y);
for (let i = 1; i < points.length; i++) mctx.lineTo(points[i].x, points[i].y);
mctx.closePath();
if (fill) {
  mctx.fillStyle = fill;
  mctx.fill();
}
if (stroke) {
  mctx.strokeStyle = stroke;
  mctx.lineWidth = width;
  mctx.stroke();
}
}

function lightSamplePolygonAlpha(light, receiverPoint) {
return shadowAlphaForLight(light, receiverPoint || { x: settings.gridW * 0.5, y: settings.gridH * 0.5, z: 0 });
}

function projectFaceToGround(facePts, light, samplePoint = null) {
var projected = [];
for (const p of facePts) {
  const gp = projectGroundPoint(light, p, samplePoint);
  if (!gp) return null;
  projected.push(gp);
}
return projected;
}

function faceReceivesLight(face, light, samplePoint = null) {
if (light.type === 'directional') {
  const incoming = lightIncoming(light);
  return dot3(face.normal, incoming) > 1e-4;
}
var source = samplePoint || light;
var c = {
  x: (face.pts[0].x + face.pts[1].x + face.pts[2].x + face.pts[3].x) * 0.25,
  y: (face.pts[0].y + face.pts[1].y + face.pts[2].y + face.pts[3].y) * 0.25,
  z: (face.pts[0].z + face.pts[1].z + face.pts[2].z + face.pts[3].z) * 0.25,
};
var L = normalize3({ x: source.x - c.x, y: source.y - c.y, z: source.z - c.z });
if (light.type === 'spot' && spotlightFalloff(light, c) <= 1e-4) return false;
return dot3(face.normal, L) > 1e-4;
}


function segmentIntersectsAABB(start, end, min, max) {
var dir = { x: end.x - start.x, y: end.y - start.y, z: end.z - start.z };
var tmin = 0;
var tmax = 1;
for (const axis of ['x', 'y', 'z']) {
  const s = start[axis];
  const d = dir[axis];
  const mn = min[axis];
  const mx = max[axis];
  if (Math.abs(d) < 1e-8) {
    if (s <= mn || s >= mx) return false;
    continue;
  }
  let t1 = (mn - s) / d;
  let t2 = (mx - s) / d;
  if (t1 > t2) t1, t2 = t2, t1
  tmin = Math.max(tmin, t1);
  tmax = Math.min(tmax, t2);
  if (tmax <= tmin) return false;
}
return tmax > 1e-5 && tmin < 1 - 1e-5;
}

function segmentIntersectsAABB(start, end, min, max) {
var dir = { x: end.x - start.x, y: end.y - start.y, z: end.z - start.z };
var tmin = 0;
var tmax = 1;
for (const axis of ['x', 'y', 'z']) {
  const s = start[axis];
  const d = dir[axis];
  const mn = min[axis];
  const mx = max[axis];
  if (Math.abs(d) < 1e-8) {
    if (s <= mn || s >= mx) return false;
    continue;
  }
  let t1 = (mn - s) / d;
  let t2 = (mx - s) / d;
  if (t1 > t2) {
    const tmp = t1; t1 = t2; t2 = tmp;
  }
  tmin = Math.max(tmin, t1);
  tmax = Math.min(tmax, t2);
  if (tmax <= tmin) return false;
}
return tmax > 1e-5 && tmin < 1 - 1e-5;
}

function shadowRayTargetForLight(light, receiverPoint, samplePoint = null) {
if (light.type === 'directional') {
  const incoming = lightIncoming(light);
  const far = Math.max(settings.gridW, settings.gridH) * 4 + 32;
  return {
    x: receiverPoint.x + incoming.x * far,
    y: receiverPoint.y + incoming.y * far,
    z: Math.max(0.08, receiverPoint.z + incoming.z * far),
  };
}
var src = samplePoint || light;
return {
  x: src.x,
  y: src.y,
  z: Math.max(0.08, src.z),
};
}

function pointInShadowByOccupancy(receiverPoint, light, samplePoint, components) {
var start = { x: receiverPoint.x, y: receiverPoint.y, z: 0.02 };
var end = shadowRayTargetForLight(light, receiverPoint, samplePoint);
if (end.z <= start.z + 1e-4) end.z = start.z + 0.08;

for (const comp of components) {
  const b = comp.bounds;
  const min = { x: b.minX, y: b.minY, z: b.minZ };
  const max = { x: b.maxX, y: b.maxY, z: b.maxZ };
  if (!segmentIntersectsAABB(start, end, min, max)) continue;
  for (const cell of comp.cells) {
    if (segmentIntersectsAABB(start, end, { x: cell.x, y: cell.y, z: cell.z }, { x: cell.x + 1, y: cell.y + 1, z: cell.z + 1 })) {
      return { hit: true, boxIds: comp.boxIds, cell };
    }
  }
}
return { hit: false };
}

function computeFloorScreenBounds() {
var pts = [
  iso(0, 0, 0),
  iso(settings.gridW, 0, 0),
  iso(settings.gridW, settings.gridH, 0),
  iso(0, settings.gridH, 0),
];
var xs = pts.map(p => p.x);
var ys = pts.map(p => p.y);
return {
  minX: Math.max(0, Math.floor(Math.min(...xs)) - 2),
  maxX: Math.min(VIEW_W, Math.ceil(Math.max(...xs)) + 2),
  minY: Math.max(0, Math.floor(Math.min(...ys)) - 2),
  maxY: Math.min(VIEW_H, Math.ceil(Math.max(...ys)) + 2),
};
}

function drawShadowMaskForLightSample(components, light, sampleIndex, sampleCount, samplePoint = null, sampleAlpha = 0) {
if (sampleAlpha <= 0.0001 || !components.length) return;
var mctx = clearShadowMask();
var bounds = computeFloorScreenBounds();
var step = lightState.highContrastShadow ? 2 : 3;
var lowW = Math.max(1, Math.ceil((bounds.maxX - bounds.minX) / step));
var lowH = Math.max(1, Math.ceil((bounds.maxY - bounds.minY) / step));
var lowCanvas = document.createElement('canvas');
lowCanvas.width = lowW;
lowCanvas.height = lowH;
var lctx = lowCanvas.getContext('2d', { willReadFrequently: true });
var img = lctx.createImageData(lowW, lowH);
var data = img.data;
var fillRgb = lightState.highContrastShadow ? hexToRgb(lightState.shadowDebugColor || '#ff2a6d') : { r: 0, g: 0, b: 0 };

var tested = 0;
var hits = 0;
var skippedOut = 0;
var broadHits = 0;
var lastHit = null;

for (let j = 0; j < lowH; j++) {
  for (let i = 0; i < lowW; i++) {
    const sx = bounds.minX + (i + 0.5) * step;
    const sy = bounds.minY + (j + 0.5) * step;
    const w = screenToFloor(sx, sy);
    if (w.x < 0 || w.y < 0 || w.x > settings.gridW || w.y > settings.gridH) {
      skippedOut += 1;
      continue;
    }
    tested += 1;
    const hitInfo = pointInShadowByOccupancy({ x: w.x, y: w.y, z: 0 }, light, samplePoint, components);
    if (!hitInfo.hit) continue;
    broadHits += 1;
    hits += 1;
    lastHit = hitInfo;
    const idx = (j * lowW + i) * 4;
    data[idx] = fillRgb.r;
    data[idx + 1] = fillRgb.g;
    data[idx + 2] = fillRgb.b;
    data[idx + 3] = 255;
  }
}

lctx.putImageData(img, 0, 0);
mctx.save();
mctx.imageSmoothingEnabled = true;
mctx.drawImage(lowCanvas, bounds.minX, bounds.minY, lowW * step, lowH * step);
if (lightState.highContrastShadow && hits > 0) {
  mctx.strokeStyle = shadowStrokeCss(sampleAlpha);
  mctx.lineWidth = 0.75;
  mctx.strokeRect(bounds.minX, bounds.minY, lowW * step, lowH * step);
}
mctx.restore();

ctx.save();
ctx.globalAlpha = clamp(sampleAlpha, 0, 1);
ctx.drawImage(shadowMaskCanvas, 0, 0, VIEW_W, VIEW_H);
ctx.restore();

if (verboseLog || debugState.frame <= 4) {
  const hitTag = lastHit ? ` hitCell=(${lastHit.cell.x},${lastHit.cell.y},${lastHit.cell.z}) boxes=${lastHit.boxIds.join(',')}` : '';
  detailLog(`shadow-raymask: light=${light.name}/${light.type} sample=${sampleIndex + 1}/${sampleCount} tested=${tested} hits=${hits} skippedOut=${skippedOut} step=${step} alpha=${sampleAlpha.toFixed(3)}${hitTag}`);
}
}

function drawComponentShadows() {
if (!lightState.showShadows) return;
var components = buildShadowComponents();
if (!components.length) return;
for (const light of lights) {
  normalizeLight(light);
  if (light.type === 'area') {
    const offsets = areaSampleOffsets(light);
    const receiverRef = components[0]?.center || { x: settings.gridW * 0.5, y: settings.gridH * 0.5, z: 0 };
    const baseAlpha = lightSamplePolygonAlpha(light, receiverRef) / Math.max(1, offsets.length) * (1.1 + light.softness * 0.7);
    offsets.forEach((o, idx) => {
      const sample = { ...light, x: light.x + o.x, y: light.y + o.y, z: light.z };
      drawShadowMaskForLightSample(components, light, idx, offsets.length, sample, baseAlpha);
    });
    continue;
  }
  const receiverRef = components[0]?.center || { x: settings.gridW * 0.5, y: settings.gridH * 0.5, z: 0 };
  const alpha = lightSamplePolygonAlpha(light, receiverRef);
  drawShadowMaskForLightSample(components, light, 0, 1, null, alpha);
}
}

function drawLightShadows() {
if (!lightState.showShadows) return;
drawComponentShadows();
drawPlayerShadow();
}

function drawLightBulb(light, active = false) {
var p = iso(light.x, light.y, light.z);
var stem = iso(light.x, light.y, Math.max(0, light.z + 0.48));
var rgb = hexToRgb(light.color);

ctx.strokeStyle = active ? 'rgba(255,255,255,.82)' : 'rgba(255,255,255,.34)';
ctx.lineWidth = active ? 2.2 : 1.4;
ctx.beginPath(); ctx.moveTo(stem.x, stem.y); ctx.lineTo(p.x, p.y); ctx.stroke();

var halo = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, active ? 26 : 17);
halo.addColorStop(0, rgbToCss(rgb, active ? 0.92 : 0.68));
halo.addColorStop(1, rgbToCss(rgb, 0));
ctx.fillStyle = halo;
ctx.beginPath(); ctx.arc(p.x, p.y, active ? 26 : 17, 0, Math.PI * 2); ctx.fill();

ctx.fillStyle = rgbToCss(rgb, 1);
ctx.beginPath(); ctx.arc(p.x, p.y, active ? 7 : 5, 0, Math.PI * 2); ctx.fill();

if (active) {
  ctx.strokeStyle = 'rgba(255,255,255,.85)';
  ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.arc(p.x, p.y, 10.5, 0, Math.PI * 2); ctx.stroke();
}
}

function drawLightAxes() {
if (!lightState.showAxes) return;
var axes = [
  { axis: 'x', color: '#ff5f6d', label: 'X' },
  { axis: 'y', color: '#59d98e', label: 'Y' },
  { axis: 'z', color: '#6fb1ff', label: 'Z' },
];
for (const { axis, color, label } of axes) {
  const { base, target } = axisHandle(axis);
  const hovered = lightState.hoverAxis === axis || lightState.dragAxis === axis;
  ctx.strokeStyle = hovered ? color : color + 'cc';
  ctx.lineWidth = hovered ? 4 : 3;
  ctx.beginPath(); ctx.moveTo(base.x, base.y); ctx.lineTo(target.x, target.y); ctx.stroke();
  ctx.fillStyle = hovered ? color : color + 'dd';
  ctx.beginPath(); ctx.arc(target.x, target.y, hovered ? 9 : 7, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 12px system-ui';
  ctx.fillText(label, target.x + 9, target.y - 8);
}
}

function degToRad(v) { return v * Math.PI / 180; }

function lightForward(light) {
var yaw = degToRad(light.angle || 0);
var pitch = degToRad(light.pitch || 55);
var cp = Math.cos(pitch);
var sp = Math.sin(pitch);
return normalize3({ x: Math.cos(yaw) * cp, y: Math.sin(yaw) * cp, z: -sp });
}

function lightIncoming(light) {
var f = lightForward(light);
return { x: -f.x, y: -f.y, z: -f.z };
}

function areaSampleOffsets(light) {
var size = Math.max(0.15, light.size || 1.2);
var s = size * 0.55;
var fastMode = shouldUseFastShadowSampling();
if (fastMode) {
  return [
    { x: 0, y: 0 },
    { x: s * 0.75, y: 0 },
    { x: -s * 0.75, y: 0 },
  ];
}

var offsets = [
  { x: 0, y: 0 },
  { x: s, y: 0 },
  { x: -s, y: 0 },
  { x: 0, y: s },
  { x: 0, y: -s },
];
if ((light.softness || 0) > 0.55 && !shouldUseMediumAreaSampling()) {
  offsets.push(
    { x: s * 0.7, y: s * 0.7 },
    { x: -s * 0.7, y: s * 0.7 },
    { x: s * 0.7, y: -s * 0.7 },
    { x: -s * 0.7, y: -s * 0.7 },
  );
}
return offsets;
}


function worldRadiusFromPixels(px) {
return px / Math.max(52, settings.tileW * 0.85);
}

function distanceAttenuation(light, point) {
var dx = point.x - light.x;
var dy = point.y - light.y;
var dz = point.z - light.z;
var dist = Math.hypot(dx, dy, dz);
var radiusWorld = worldRadiusFromPixels(light.radius || 240);
var t = clamp(1 - dist / Math.max(0.001, radiusWorld), 0, 1);
return t * t;
}

function spotlightFalloff(light, point) {
if (light.type !== 'spot') return 1;
var toPoint = normalize3({ x: point.x - light.x, y: point.y - light.y, z: point.z - light.z });
var forward = lightForward(light);
var cosTheta = dot3(toPoint, forward);
var outer = degToRad(Math.max(2, light.spread || 34) * 0.5);
var inner = outer * (1 - clamp((light.softness || 0.3) * 0.75, 0.02, 0.75));
var cosOuter = Math.cos(outer);
var cosInner = Math.cos(inner);
if (cosTheta <= cosOuter) return 0;
if (cosTheta >= cosInner) return 1;
var t = clamp((cosTheta - cosOuter) / Math.max(1e-5, cosInner - cosOuter), 0, 1);
return t * t * (3 - 2 * t);
}

function evaluateSingleLight(light, point, normal) {
normalizeLight(light);
var lightRgb = hexToRgb(light.color);

if (light.type === 'directional') {
  const L = lightIncoming(light);
  const lambert = Math.max(0, dot3(normal, L));
  return { raw: lambert * light.intensity, rgb: lightRgb };
}

var L = normalize3({ x: light.x - point.x, y: light.y - point.y, z: light.z - point.z });
var lambert = Math.max(0, dot3(normal, L));
var raw = lambert * distanceAttenuation(light, point) * light.intensity;
if (light.type === 'spot') raw *= spotlightFalloff(light, point);
return { raw, rgb: lightRgb };
}

function evaluateLight(light, point, normal) {
if (light.type !== 'area') return evaluateSingleLight(light, point, normal);
var offsets = areaSampleOffsets(light);
var raw = 0;
var rgbAccum = { r: 0, g: 0, b: 0 };
for (const o of offsets) {
  const sample = { ...light, type: 'point', x: light.x + o.x, y: light.y + o.y };
  const part = evaluateSingleLight(sample, point, normal);
  raw += part.raw;
  rgbAccum.r += part.rgb.r;
  rgbAccum.g += part.rgb.g;
  rgbAccum.b += part.rgb.b;
}
var n = offsets.length || 1;
return {
  raw: raw / n,
  rgb: { r: rgbAccum.r / n, g: rgbAccum.g / n, b: rgbAccum.b / n },
};
}

function spriteLightAt(point) {
var brightness = 0.35 + settings.ambient * 1.35;
var tintAccum = { r: 0, g: 0, b: 0 };
var weight = 0;
for (const light of lights) {
  const liftedPoint = { x: point.x, y: point.y, z: point.z + 0.3 };
  const evalUp = evaluateLight(light, liftedPoint, { x: 0, y: 0, z: 1 });
  const raw = evalUp.raw;
  brightness += raw * 1.05;
  tintAccum.r += evalUp.rgb.r * raw;
  tintAccum.g += evalUp.rgb.g * raw;
  tintAccum.b += evalUp.rgb.b * raw;
  weight += raw;
}
return {
  brightness: clamp(brightness, 0.28, 1.9),
  tint: weight > 0 ? { r: tintAccum.r / weight, g: tintAccum.g / weight, b: tintAccum.b / weight } : { r: 255, g: 255, b: 255 },
  weight,
};
}

function baseFaceColors(base) {
var rgb = hexToRgb(base);
return {
  top: mixColor(rgb, { r: 255, g: 255, b: 255 }, 0.14),
  east: mulColor(rgb, 0.92),
  south: mulColor(rgb, 0.75),
  line: 'rgba(0,0,0,.16)',
};
}

function litColor(baseRgb, center, normal) {
var accum = mulColor(baseRgb, 0.18 + settings.ambient * 0.9);
for (const light of lights) {
  const evald = evaluateLight(light, center, normal);
  const t = clamp(evald.raw, 0, 1.35);
  const warmed = mixColor(baseRgb, evald.rgb, clamp(t * 0.9, 0, 0.9));
  accum = addColor(accum, mulColor(warmed, t));
}
return accum;
}

function projectGroundPoint(light, point, samplePoint = null) {
if (light.type === 'directional') {
  const dir = lightForward(light);
  if (dir.z >= -0.02) return null;
  const t = point.z / (-dir.z);
  return { x: point.x + dir.x * t, y: point.y + dir.y * t, z: 0 };
}
var source = samplePoint || light;
var dz = source.z - point.z;
if (dz <= 0.05) return null;
var t = point.z / dz;
return { x: point.x + (point.x - source.x) * t, y: point.y + (point.y - source.y) * t, z: 0 };
}

function shadowAlphaForLight(light, receiverPoint) {
var globalAlpha = clamp(Number(lightState.shadowAlpha ?? 1), 0, 1);
var opacityScale = Math.max(0, Number(lightState.shadowOpacityScale ?? 1));
if (globalAlpha <= 0 || opacityScale <= 0 || !lightState.showShadows) return 0;

var alpha;
if (light.type === 'directional') alpha = clamp(0.05 + light.intensity * 0.07, 0.04, 0.16);
else if (light.type === 'spot') alpha = clamp((0.04 + light.intensity * 0.09) * (0.65 + spotlightFalloff(light, receiverPoint) * 0.7), 0.03, 0.2);
else if (light.type === 'area') alpha = clamp(0.03 + light.intensity * 0.05, 0.02, 0.11);
else alpha = clamp(0.05 + light.intensity * 0.08, 0.04, 0.18);

var scaled = clamp(alpha * opacityScale, 0, 1);
var capped = Math.min(lightState.highContrastShadow ? 0.95 : 0.7, scaled * globalAlpha);
return clamp(capped, 0, 1);
}

function shadowFillCss(alpha) {
var a = clamp(alpha, 0, 0.95);
if (lightState.highContrastShadow) {
  return rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), a);
}
return `rgba(0,0,0,${a})`;
}

function shadowStrokeCss(alpha) {
var a = clamp(alpha, 0, 0.95);
if (lightState.highContrastShadow) {
  return rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), Math.min(1, a + 0.22));
}
return `rgba(0,0,0,${Math.min(0.35, a + 0.08)})`;
}


function convexHull2(points) {
if (points.length <= 1) return points.slice();
var pts = points.slice().sort((a,b)=> a.x === b.x ? a.y - b.y : a.x - b.x);
var cross = (o,a,b) => (a.x-o.x)*(b.y-o.y) - (a.y-o.y)*(b.x-o.x);
var lower = [];
for (const p of pts) {
  while (lower.length >= 2 && cross(lower[lower.length-2], lower[lower.length-1], p) <= 0) lower.pop();
  lower.push(p);
}
var upper = [];
for (let i = pts.length - 1; i >= 0; i--) {
  const p = pts[i];
  while (upper.length >= 2 && cross(upper[upper.length-2], upper[upper.length-1], p) <= 0) upper.pop();
  upper.push(p);
}
lower.pop(); upper.pop();
return lower.concat(upper);
}

function boxShadowWorldPoints(box) {
return [
  { x: box.x, y: box.y, z: box.z },
  { x: box.x + box.w, y: box.y, z: box.z },
  { x: box.x + box.w, y: box.y + box.d, z: box.z },
  { x: box.x, y: box.y + box.d, z: box.z },
  { x: box.x, y: box.y, z: box.z + box.h },
  { x: box.x + box.w, y: box.y, z: box.z + box.h },
  { x: box.x + box.w, y: box.y + box.d, z: box.z + box.h },
  { x: box.x, y: box.y + box.d, z: box.z + box.h },
];
}

function drawProjectedShadow(worldPts, light, receiverPoint, debugTag = '') {
if (!lightState.showShadows) return;
normalizeLight(light);
var emitShadow = (projected, alpha) => {
  if (alpha <= 0.0001) return;
  if (!projected.length) return;
  const hull = convexHull2(projected.map(p => ({ x: p.x, y: p.y })));
  if (hull.length < 3) return;
  if (verboseLog && debugState.frame <= 6) {
    detailLog(`shadow:${debugTag || 'shape'} light=${light.name}/${light.type} hullN=${hull.length} alpha=${alpha.toFixed(3)} fill=${lightState.highContrastShadow ? lightState.shadowDebugColor : '#000000'} hull=${hull.map(p => `(${p.x.toFixed(2)},${p.y.toFixed(2)})`).join(' ')}`);
  }
  drawPoly(hull.map(p => iso(p.x, p.y, 0)), shadowFillCss(alpha), lightState.highContrastShadow ? shadowStrokeCss(alpha) : null);
};
if (light.type === 'area') {
  const offsets = areaSampleOffsets(light);
  const baseAlpha = shadowAlphaForLight(light, receiverPoint) / Math.max(1, offsets.length) * (1.2 + light.softness * 0.8);
  for (const o of offsets) {
    const sample = { ...light, x: light.x + o.x, y: light.y + o.y, z: light.z };
    const projected = worldPts.map(p => projectGroundPoint(light, p, sample)).filter(Boolean);
    emitShadow(projected, baseAlpha);
  }
  return;
}
var projected = worldPts.map(p => projectGroundPoint(light, p)).filter(Boolean);
var a = shadowAlphaForLight(light, receiverPoint);
emitShadow(projected, a);
}

function drawPlayerShadow() {
if (!SHOW_PLAYER) return;
if (!lightState.showShadows) return;

var proxy = getPlayerProxyBox();
var worldPts = boxShadowWorldPoints(proxy);
var center = getPlayerShadowCenter();
for (const light of lights) drawProjectedShadow(worldPts, light, center, 'player-proxy');

var bounds = getPlayerGroundBounds();
var foot = iso(player.x, player.y, 0);
var widthPx = Math.max(10, bounds.maxX - bounds.minX);
var heightPx = Math.max(6, bounds.maxY - bounds.minY);
var contactAlpha = clamp(0.12 + settings.ambient * 0.20, 0.10, 0.24);
for (const light of lights) {
  contactAlpha += clamp(evaluateLight(light, { x: player.x, y: player.y, z: 0.12 }, { x: 0, y: 0, z: 1 }).raw * 0.025, 0, 0.045);
}
ctx.save();
ctx.translate(foot.x, foot.y + 4);
ctx.scale(Math.max(0.75, widthPx / 26), Math.max(0.42, heightPx / 18));
ctx.fillStyle = `rgba(0,0,0,${clamp(contactAlpha, 0.10, 0.30)})`;
ctx.beginPath();
ctx.arc(0, 0, 13, 0, Math.PI * 2);
ctx.fill();
ctx.restore();

if (showDebug) {
  const pts = cubePoints(proxy.x, proxy.y, proxy.z, proxy.w, proxy.d, proxy.h);
  drawPoly([pts.p001, pts.p101, pts.p111, pts.p011], 'rgba(255,210,120,.05)', 'rgba(255,210,120,.82)');
  drawPoly([pts.p101, pts.p111, pts.p110, pts.p100], null, 'rgba(255,210,120,.55)');
  drawPoly([pts.p011, pts.p111, pts.p110, pts.p010], null, 'rgba(255,210,120,.55)');
}
}

function currentProto() {
var p = currentPrefab();
return prefabVariant(p, editor.rotation);
}

function iso(x, y, z = 0) {
return {
  x: settings.originX + camera.x + (x - y) * settings.tileW / 2,
  y: settings.originY + camera.y + (x + y) * settings.tileH / 2 - z * settings.tileH,
};
}

function screenToFloor(sx, sy) {
var dx = (sx - settings.originX - camera.x) / (settings.tileW / 2);
var dy = (sy - settings.originY - camera.y) / (settings.tileH / 2);
return { x: (dx + dy) / 2, y: (dy - dx) / 2 };
}

function shadeHex(hex, delta) {
var v = hex.replace('#', '');
var n = parseInt(v, 16);
var r = (n >> 16) + delta;
var g = ((n >> 8) & 255) + delta;
var b = (n & 255) + delta;
r = clamp(r, 0, 255); g = clamp(g, 0, 255); b = clamp(b, 0, 255);
return `rgb(${r},${g},${b})`;
}

function hexToRgb(hex) {
var v = hex.replace('#', '');
var n = parseInt(v, 16);
return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToCss(rgb, a = 1) {
return `rgba(${Math.round(rgb.r)}, ${Math.round(rgb.g)}, ${Math.round(rgb.b)}, ${a})`;
}

function lerp(a, b, t) { return a + (b - a) * t; }

function mixColor(rgb, target, t) {
return {
  r: lerp(rgb.r, target.r, t),
  g: lerp(rgb.g, target.g, t),
  b: lerp(rgb.b, target.b, t),
};
}

function mulColor(rgb, k) {
return {
  r: clamp(rgb.r * k, 0, 255),
  g: clamp(rgb.g * k, 0, 255),
  b: clamp(rgb.b * k, 0, 255),
};
}

function addColor(a, b) {
return {
  r: clamp(a.r + b.r, 0, 255),
  g: clamp(a.g + b.g, 0, 255),
  b: clamp(a.b + b.b, 0, 255),
};
}

function normalize3(v) {
var len = Math.hypot(v.x, v.y, v.z) || 1;
return { x: v.x / len, y: v.y / len, z: v.z / len };
}

function dot3(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

function drawLightGlow() {
if (!lightState.showGlow) return;
for (const light of lights) {
  normalizeLight(light);
  const p = iso(light.x, light.y, light.z);
  const rgb = hexToRgb(light.color);

  if (light.type === 'directional') {
    const incoming = lightIncoming(light);
    const g = ctx.createLinearGradient(
      VIEW_W * 0.5 - incoming.x * VIEW_W * 0.75,
      VIEW_H * 0.5 - incoming.y * VIEW_H * 0.55,
      VIEW_W * 0.5 + incoming.x * VIEW_W * 0.75,
      VIEW_H * 0.5 + incoming.y * VIEW_H * 0.55,
    );
    g.addColorStop(0, rgbToCss(rgb, clamp(light.intensity * 0.14, 0, 0.18)));
    g.addColorStop(0.55, rgbToCss(rgb, 0.03));
    g.addColorStop(1, rgbToCss(rgb, 0));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    continue;
  }

  if (light.type === 'area') {
    const size = 12 + (light.size || 1) * 10;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.fillStyle = rgbToCss(rgb, clamp(0.18 * light.intensity, 0, 0.3));
    ctx.strokeStyle = rgbToCss(rgb, 0.65);
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.rect(-size, -size * 0.55, size * 2, size * 1.1);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  const glow = ctx.createRadialGradient(p.x, p.y, 6, p.x, p.y, light.radius);
  glow.addColorStop(0, rgbToCss(rgb, clamp(0.18 * light.intensity, 0, 0.32)));
  glow.addColorStop(0.35, rgbToCss(rgb, clamp(0.08 * light.intensity, 0, 0.22)));
  glow.addColorStop(1, rgbToCss(rgb, 0));
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
}
}

function buildShadowCasters() {
var groups = new Map();
for (const box of boxes) {
  const key = `${box.x}|${box.y}|${box.w}|${box.d}`;
  if (!groups.has(key)) groups.set(key, []);
  groups.get(key).push(box);
}

var casters = [];
for (const stack of groups.values()) {
  if (stack.length === 1) {
    const box = stack[0];
    casters.push({
      kind: 'box',
      box,
      worldPts: boxShadowWorldPoints(box),
      center: { x: box.x + box.w * 0.5, y: box.y + box.d * 0.5, z: box.z + box.h * 0.5 },
      debugTag: `box#${box.id}`,
    });
    continue;
  }

  stack.sort((a, b) => a.z - b.z);
  const baseZ = Math.min(...stack.map(b => b.z));
  const topZ = Math.max(...stack.map(b => b.z + b.h));
  const ref = stack[0];
  const merged = { x: ref.x, y: ref.y, z: baseZ, w: ref.w, d: ref.d, h: topZ - baseZ };
  casters.push({
    kind: 'stack',
    boxes: stack.slice(),
    worldPts: boxShadowWorldPoints(merged),
    center: { x: merged.x + merged.w * 0.5, y: merged.y + merged.d * 0.5, z: merged.z + merged.h * 0.5 },
    debugTag: `stack(${stack.map(b => `#${b.id}`).join(',')})`,
  });
}
return casters;
}

function shadowLightVectorAtPoint(light, point, samplePoint = null) {
normalizeLight(light);
if (light.type === 'directional') return normalize3(lightIncoming(light));
var src = samplePoint || light;
return normalize3({ x: src.x - point.x, y: src.y - point.y, z: src.z - point.z });
}

function projectGroundPointStable(light, point, samplePoint = null) {
if (light.type === 'directional') {
  const dir = lightForward(light);
  if (dir.z >= -0.02) return null;
  const t = point.z / (-dir.z);
  return { x: point.x + dir.x * t, y: point.y + dir.y * t, z: 0 };
}
var src0 = samplePoint || light;
var src = { x: src0.x, y: src0.y, z: Math.max(src0.z, point.z + 0.35) };
var dz = src.z - point.z;
if (dz <= 1e-4) return null;
var t = point.z / dz;
return { x: point.x + (point.x - src.x) * t, y: point.y + (point.y - src.y) * t, z: 0 };
}

function faceCenter(face) {
var n = face.pts.length || 1;
var x = 0, y = 0, z = 0;
for (const p of face.pts) {
  x += p.x; y += p.y; z += p.z;
}
return { x: x / n, y: y / n, z: z / n };
}

function collectShadowFacePolys(component, light, samplePoint = null) {
var polys = [];
for (const face of component.faces || []) {
  const center = faceCenter(face);
  const toLight = shadowLightVectorAtPoint(light, center, samplePoint);
  const facing = dot3(face.normal, toLight);
  if (facing <= 0.02) continue;
  const projected = face.pts.map(pt => projectGroundPointStable(light, pt, samplePoint)).filter(Boolean);
  if (projected.length < 3) continue;
  polys.push(projected);
}
return polys;
}


var shadowPolyUnionCanvas = null;
var shadowPolyUnionCtx = null;

function ensureShadowPolyUnionCanvas() {
if (!shadowPolyUnionCanvas) {
  shadowPolyUnionCanvas = document.createElement('canvas');
  shadowPolyUnionCtx = shadowPolyUnionCanvas.getContext('2d');
}
if (shadowPolyUnionCanvas.width !== VIEW_W || shadowPolyUnionCanvas.height !== VIEW_H) {
  shadowPolyUnionCanvas.width = VIEW_W;
  shadowPolyUnionCanvas.height = VIEW_H;
}
return shadowPolyUnionCtx;
}

function drawProjectedComponentShadow(component, light) {
if (!lightState.showShadows) return;
normalizeLight(light);
var receiverPoint = component.center || { x: settings.gridW * 0.5, y: settings.gridH * 0.5, z: 0 };

var emitPolys = (polys, alpha, tag = '') => {
  if (alpha <= 0.0001 || !polys.length) return;

  const unionCtx = ensureShadowPolyUnionCanvas();
  unionCtx.clearRect(0, 0, VIEW_W, VIEW_H);
  unionCtx.globalCompositeOperation = 'source-over';
  unionCtx.fillStyle = lightState.highContrastShadow
    ? rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), 1)
    : 'rgba(0,0,0,1)';

  const screenPolys = [];
  for (const poly of polys) {
    const scr = poly.map(p => iso(p.x, p.y, 0));
    if (scr.length < 3) continue;
    screenPolys.push(scr);
    unionCtx.beginPath();
    unionCtx.moveTo(scr[0].x, scr[0].y);
    for (let i = 1; i < scr.length; i++) unionCtx.lineTo(scr[i].x, scr[i].y);
    unionCtx.closePath();
    unionCtx.fill();
  }
  if (!screenPolys.length) return;

  ctx.save();
  ctx.globalAlpha = clamp(alpha, 0, 0.95);
  ctx.drawImage(shadowPolyUnionCanvas, 0, 0);
  ctx.restore();

  if (lightState.highContrastShadow) {
    ctx.save();
    ctx.strokeStyle = shadowStrokeCss(alpha);
    ctx.lineWidth = 0.7;
    for (const scr of screenPolys) {
      ctx.beginPath();
      ctx.moveTo(scr[0].x, scr[0].y);
      for (let i = 1; i < scr.length; i++) ctx.lineTo(scr[i].x, scr[i].y);
      ctx.closePath();
      ctx.stroke();
    }
    ctx.restore();
  }

  if (verboseLog && debugState.frame <= 6) {
    detailLog(`shadow-comp:${component.debugTag || tag || 'component'} light=${light.name}/${light.type} polys=${screenPolys.length} alpha=${alpha.toFixed(3)} union=offscreen`);
  }
};

if (light.type === 'area') {
  const offsets = areaSampleOffsets(light);
  const baseAlpha = shadowAlphaForLight(light, receiverPoint) / Math.max(1, offsets.length) * (1.05 + light.softness * 0.65);
  offsets.forEach((o) => {
    const sample = { ...light, x: light.x + o.x, y: light.y + o.y, z: light.z };
    const polys = collectShadowFacePolys(component, light, sample);
    emitPolys(polys, baseAlpha, component.debugTag);
  });
  return;
}

var polys = collectShadowFacePolys(component, light, null);
emitPolys(polys, shadowAlphaForLight(light, receiverPoint), component.debugTag);
}

function drawLightShadows() {
if (!lightState.showShadows) return;
var components = buildShadowComponents();
for (const comp of components) {
  if (verboseLog && debugState.frame <= 3) {
    detailLog(`shadow-component ${comp.debugTag} faces=${comp.faces.length} cells=${comp.cells.length}`);
  }
  for (const light of lights) drawProjectedComponentShadow(comp, light);
}
drawPlayerShadow();
}


// --- v1.3 static-shadow-layer override ---
function invalidateShadowGeometryCache(reason = 'unknown') {
  shadowGeomCache.signature = '';
  shadowGeomCache.components = [];
  shadowGeomCache.occupancy = new Map();
  shadowGeomCache.totalVoxels = 0;
  shadowGeomCache.totalFaces = 0;
  markStaticShadowLayerDirty(`shadow-geom:${reason}`);
  detailLog(`shadow-components: invalidated reason=${reason}`);
}

function ensureStaticShadowLayerCanvas() {
  if (!staticShadowCanvas) {
    staticShadowCanvas = document.createElement('canvas');
    staticShadowCtx = staticShadowCanvas.getContext('2d');
  }
  var backingW = Math.round(VIEW_W * dpr);
  var backingH = Math.round(VIEW_H * dpr);
  if (staticShadowCanvas.width !== backingW || staticShadowCanvas.height !== backingH) {
    staticShadowCanvas.width = backingW;
    staticShadowCanvas.height = backingH;
    staticShadowCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    staticShadowCtx.imageSmoothingEnabled = true;
    staticShadowCache.dirty = true;
  }
  return staticShadowCtx;
}

function drawProjectedComponentShadow(component, light, targetCtx = ctx) {
  if (!lightState.showShadows) return;
  normalizeLight(light);
  var receiverPoint = component.center || { x: settings.gridW * 0.5, y: settings.gridH * 0.5, z: 0 };

  var emitPolys = (polys, alpha, tag = '') => {
    if (alpha <= 0.0001 || !polys.length) return;

    const unionCtx = ensureShadowPolyUnionCanvas();
    unionCtx.clearRect(0, 0, VIEW_W, VIEW_H);
    unionCtx.globalCompositeOperation = 'source-over';
    unionCtx.fillStyle = lightState.highContrastShadow
      ? rgbToCss(hexToRgb(lightState.shadowDebugColor || '#ff2a6d'), 1)
      : 'rgba(0,0,0,1)';

    const screenPolys = [];
    for (const poly of polys) {
      const scr = poly.map(p => iso(p.x, p.y, 0));
      if (scr.length < 3) continue;
      screenPolys.push(scr);
      unionCtx.beginPath();
      unionCtx.moveTo(scr[0].x, scr[0].y);
      for (let i = 1; i < scr.length; i++) unionCtx.lineTo(scr[i].x, scr[i].y);
      unionCtx.closePath();
      unionCtx.fill();
    }
    if (!screenPolys.length) return;

    targetCtx.save();
    targetCtx.globalAlpha = clamp(alpha, 0, 0.95);
    targetCtx.drawImage(shadowPolyUnionCanvas, 0, 0, VIEW_W, VIEW_H);
    targetCtx.restore();

    if (lightState.highContrastShadow) {
      targetCtx.save();
      targetCtx.strokeStyle = shadowStrokeCss(alpha);
      targetCtx.lineWidth = 0.7;
      for (const scr of screenPolys) {
        targetCtx.beginPath();
        targetCtx.moveTo(scr[0].x, scr[0].y);
        for (let i = 1; i < scr.length; i++) targetCtx.lineTo(scr[i].x, scr[i].y);
        targetCtx.closePath();
        targetCtx.stroke();
      }
      targetCtx.restore();
    }

    if (verboseLog && debugState.frame <= 6) {
      detailLog(`shadow-comp:${component.debugTag || tag || 'component'} light=${light.name}/${light.type} polys=${screenPolys.length} alpha=${alpha.toFixed(3)} target=${targetCtx === ctx ? 'main' : 'cache'}`);
    }
  };

  if (light.type === 'area') {
    const offsets = areaSampleOffsets(light);
    const baseAlpha = shadowAlphaForLight(light, receiverPoint) / Math.max(1, offsets.length) * (1.05 + light.softness * 0.65);
    offsets.forEach((o) => {
      const sample = { ...light, x: light.x + o.x, y: light.y + o.y, z: light.z };
      const polys = collectShadowFacePolys(component, light, sample);
      emitPolys(polys, baseAlpha, component.debugTag);
    });
    return;
  }

  var polys = collectShadowFacePolys(component, light, null);
  emitPolys(polys, shadowAlphaForLight(light, receiverPoint), component.debugTag);
}

function rebuildStaticShadowLayerIfNeeded(force = false) {
  if (!lightState.showShadows) return;

  var sig = staticShadowLayerSignature();
  var needsRebuild = force || staticShadowCache.dirty || staticShadowCache.signature !== sig || !staticShadowCanvas;
  if (!needsRebuild) return;

  var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  if (!force && isInteractiveRenderPressure() && staticShadowCache.signature && (now - staticShadowCache.lastBuiltAt) < SHADOW_LAYER_INTERACTION_MS) {
    return;
  }

  var targetCtx = ensureStaticShadowLayerCanvas();
  targetCtx.clearRect(0, 0, VIEW_W, VIEW_H);
  var components = buildShadowComponents();
  for (const comp of components) {
    for (const light of lights) drawProjectedComponentShadow(comp, light, targetCtx);
  }
  staticShadowCache.signature = sig;
  staticShadowCache.lastBuiltAt = now;
  staticShadowCache.dirty = false;
  noteLayerRebuild('static-shadow', `interactive=${isInteractiveRenderPressure()} comps=${components.length} lights=${lights.length}`);
}

function drawLightShadows() {
  if (!lightState.showShadows) return;
  rebuildStaticShadowLayerIfNeeded();
  if (staticShadowCanvas) ctx.drawImage(staticShadowCanvas, 0, 0, VIEW_W, VIEW_H);
  drawPlayerShadow();
}
